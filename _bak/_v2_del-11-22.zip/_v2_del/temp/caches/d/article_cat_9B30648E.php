<?php exit;?>a:3:{s:8:"template";a:6:{i:0;s:56:"/home/sites/newyizhanglian/themes/yzl_v1/article_cat.dwt";i:1;s:64:"/home/sites/newyizhanglian/themes/yzl_v1/library/page_header.lbi";i:2;s:74:"/home/sites/newyizhanglian/themes/yzl_v1/library/article_category_tree.lbi";i:3;s:60:"/home/sites/newyizhanglian/themes/yzl_v1/library/ur_here.lbi";i:4;s:70:"/home/sites/newyizhanglian/themes/yzl_v1/library/pages_article_cat.lbi";i:5;s:64:"/home/sites/newyizhanglian/themes/yzl_v1/library/page_footer.lbi";}s:7:"expires";i:1385104613;s:8:"maketime";i:1385101013;}<!DOCTYPE HTML>
<html lang="en-US">
<head>
<base href="http://new.yizhanglian.com/" />
  <meta charset="UTF-8">
  <meta name="Keywords" content="品牌下载品牌下载" />
  <meta name="Description" content="品牌下载品牌下载品牌下载" />
  
  <title>品牌下载_走进易张脸_易张脸官网</title>
  
  
  
  <link rel="shortcut icon" href="favicon.ico" />
  <link rel="icon" href="animated_favicon.gif" type="image/gif" />
  <link href="themes/yzl_v1/style.css" rel="stylesheet" type="text/css" />
  <script type="text/javascript" src="js/common.js"></script><script type="text/javascript" src="js/index.js"></script></head>
<body>
<script src="themes/yzl_v1/js/jquery-1.10.2.min.js" type="text/javascript"></script>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<div id="head">
    <div class="vitta"></div>
    <div class="head_box">
        <div class="top">
            <div class="logo"><a href="index.php"><img src="themes/yzl_v1/images/logo.jpg" width="303" height="76"></a></div>
            <div class="right">
              <script type="text/javascript" src="js/transport1.js"></script><script type="text/javascript" src="js/utils.js"></script>                <div class="right_top_box"> <span  class="loading">554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca</span>
                    <span class="collect_box"><a href="user.php">用户中心</a><a href="#">订购帮助</a><a class="shop_cart" href="#">我的购物车</a></span>
                    
                    <script>
                    
                    <!--
                    function checkSearchForm()
                    {
                        if(document.getElementById('keyword').value)
                        {
                            return true;
                        }
                        else
                        {
                            alert("请输入搜索关键词！");
                            return false;
                        }
                    }
                    -->
                    
                    </script> 
                    <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()" class="f_r"  style="_position:relative; top:5px;">
                      <div class="search">
                          <input name="keywords" type="text" id="keyword" value="" />
                          <input type="submit" class="btn" value="" class="go" style="cursor:pointer;" />
                      </div>
                    </form>
                    
                </div>
                <div class="right_bottom_box"> <span class="first_aid"><a href="#">皮肤急救中心</a></span>
                    <div id="lang" class="ranklist">
                        <p><a class="tg0">畅销排行</a></p>
                        <p><a class="tg1">畅销排行</a></p>
                        <ul>
                            <li class="last"><a href="#">眼部护理</a></li>
                            <li><a href="http://www.baidu.com/">养肤面贴膜</a></li>
                            <li><a href="http://www.g.cn/">养肤水</a></li>
                            <li><a href="#">精华液</a></li>
                            <li><a href="#"> 养肤面霜</a></li>
                            <li><a href="#">面膜泥/冻膜 </a></li>
                            <li ><a href="http://www.baidu.com/">养肤洁面乳</a></li>
                            
                        </ul>
                    </div>
                    <script src="themes/yzl_v1/js/best_sale.js" type="text/javascript"></script>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="nav_one">
    <ul class="nav_one_box">
         
        <li>
            <a href="page/9">花本养肤</a>
            <div class="nav_one_container">
                <span class="line"></span>
                <div class="nav_item" id="nav_item_bg_1">
                    <ul class="left">
                        <li ><a href="/page/10">花神之说</a></li>
                        <li><a href="/page/11">传承千年</a></li>
                    </ul>
                    <div class="right">
                        <h1>花神不老颜，<br>掀起以花养颜千年历史。</h1>
                        <P>以天然珍稀花卉作为护肤上品，一直是古今中外宫廷贵族口口相传的驻颜秘笈。借由花神之说，易张脸深度挖掘花本养颜悠久历史，缔造天然花本精粹护肤的奢华传奇…</P>
                    </div>
                </div>
            </div>
        </li>
         
        <li>
            <a href="page/myjt">美颜讲堂</a>
            <div class="nav_one_container">
                <span class="line"></span>
                <div class="nav_item" id="nav_item_bg_2">
                    <ul class="left">
                        <li ><a href="#">肤质解析堂</a></li>
                        <li><a href="#">养肤常识堂</a></li>
                        <li><a href="#">花本养肤堂</a></li>
                    </ul>
                    <div class="right">
                        <h1>" 花养颜娇颜如花 "</h1>
                        <P>以天然珍稀花卉作为护肤上品，一直是古今中外宫廷贵族口口相传的驻颜秘笈。借由花神之说，易张脸深度挖掘花本养颜悠久历史，缔造天然花本精粹护肤的奢华传奇…</P>
                    </div>
                </div>
            </div>
        </li>
         
        <li>
            <a href="page/13">易颜之法</a>
            <div class="nav_one_container nav_one_container_last">
                <span class="line2"></span>
                <div class="nav_item" id="nav_item_bg_3">
                    <ul class="left">
                        <li ><a href="#">公司介绍</a></li>
                        <li><a href="#">科研实力</a></li>
                        <li><a href="#">生产工艺</a></li>
                    </ul>
                    <div class="right">
                        <h1>自然、安全、化繁为简</h1>
                        <P>以天然珍稀花卉作为护肤上品，一直是古今中外宫廷贵族口口相传的驻颜秘笈。借由花神之说，易张脸深度挖掘花本养颜悠久历史，缔造天然花本精粹护肤的奢华传奇…</P>
                    </div>
                </div>
            </div>
        </li>
         
        <li class="no_bg">
            <a href="page/14">美自天然</a>
            <div class="nav_one_container nav_one_container_last">
                <span class="line2"></span>
                <div class="nav_item" id="nav_item_bg_4">
                    <ul class="left">
                        <li ><a href="#">公司介绍</a></li>
                        <li><a href="#">科研实力</a></li>
                        <li><a href="#">生产工艺</a></li>
                    </ul>
                    <div class="right">
                        <h1>自然、安全、化繁为简</h1>
                        <P>以天然珍稀花卉作为护肤上品，一直是古今中外宫廷贵族口口相传的驻颜秘笈。借由花神之说，易张脸深度挖掘花本养颜悠久历史，缔造天然花本精粹护肤的奢华传奇…</P>
                    </div>
                </div>
            </div>
        </li>
            </ul>
    
</div>
<script>
    $(function() {
        $(".nav_one_box > li ").hover(function(){
            $(this).find(".nav_one_container").attr({style:"display:block"});
        },function(){
            $(this).find(".nav_one_container").css("display","none");
        });
        $(".nav_item .left > li ").hover(function(){
            $(this).addClass("current");
        },function(){
            $(this).removeClass("current");
        });
    });
</script>
<div id="nav_two">
    <ul>
        <li><a href="#">品牌宣言</a></li>
        <li><a href="#">清洁控油</a></li>
        <li><a href="#">补水锁湿</a></li>
        <li><a href="#">美白提亮</a></li>
        <li><a href="#">抗敏修复</a></li>
        <li><a href="#">逆颜紧致</a></li>
        <li class="selectbox">
            <form>
                <div class="hide_box">
                    <select>
                        <option value="name">活动专区</option>
                        <option value="content">活动专区</option>
                    </select>
                </div>
            </form>
        </li>
    </ul>
</div>
<div class="inner_banner"></div>
<div class="inner_content">
    <div class="innernews_left">
        
                <div class="innernews_left_box">
        <h1>走进易张脸</h1>
    <ul class="innernews_list">
                <li><a href="page/news">公司新闻</a></li>
                <li><a href="page/brand_download">品牌下载</a></li>
                <li><a href="page/join_us">招纳贤才</a></li>
                <li class="no_border"><a href="page/contact_us">联系我们</a></li>
            </ul>
    </div>
                
    </div>
    <div class="innernews_right">
        <h3 class="bread_crumbs"><a href=".">首页</a> <code>&gt;</code> <a href="page/culture">走进易张脸</a> <code>&gt;</code> <a href="page/brand_download">品牌下载</a></h3>        <div class="companynew_list">
            <h1 class="wall_paper">&nbsp;</h1>
<ul class="wall-box">
    <li><img src="images/wallpaper-pic1.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li class="no-margin"><img src="images/wallpaper-pic2.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li><img src="images/wallpaper-pic1.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li class="no-margin"><img src="images/wallpaper-pic2.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li><img src="images/wallpaper-pic1.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li class="no-margin"><img src="images/wallpaper-pic2.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
</ul>            <div class="job-list">
                                <dl><dt><a href="article-20.html" title="下载2">下载2</a></dt><dd>重庆</dd></dl>
                                <dl><dt><a href="article-15.html" title="下载品牌1">下载品牌1</a></dt><dd>重庆</dd></dl>
                            </div>
            
<form name="selectPageForm" action="/article_cat.php" method="get">
<div class="page_up"><span>共2条记录，分1页显示，每页7条</span>[
              <a href="" class="red">1</a>
          ] 
  </div>
  </div>
</form>
<script type="Text/Javascript" language="JavaScript">
<!--
function selectPage(sel)
{
  sel.form.submit();
}
//-->
</script>
        </div>
    </div>
</div>
</div>
   
<script src="themes/yzl_v1/js/slides.jquery.js"></script>
<script src="themes/yzl_v1/js/play.min.js"></script>
<div id="foot_inner">
    <div class="foot">
        <ul class="foot_box">
            <li><img src="themes/yzl_v1/images/tel.jpg" width="124" height="35"></li>
            <li>
                <ul class="foot_nav">
                                        <li><a href="page/news">公司新闻</a></li>
                                        <li><a href="page/5/">品牌下载</a></li>
                                        <li><a href="page/join_us/">招纳贤才</a></li>
                                        <li><a href="page/contact_us/">联系我们</a></li>
                                    </ul>
                <p>渝ICP证030173号 ©2013 重庆欧菲诗化妆品有限公司 版权所有</p>
            </li>
            <div class="pop_box">
                <div class="web_shop" style="display: none;">
                    <div class="web_shop_left">
                        <h1>欢迎进入易张脸官方旗舰店铺</h1>
                        <div class="web_shop_box" id="slidesSkincare">
                            <!-- <span class="left_arrows"><img src="themes/yzl_v1/images/web-city-allowsleft.jpg" width="27" height="36"></span> -->
                            <div class="slides_container">
                                <ul class="slide brands">
                                    <li><a href="#"><img src="themes/yzl_v1/images/taobao_wall.jpg" width="192" height="77"></a>
                                        <p><a href="#">天猫商城-易张脸官方旗舰店</a></p>
                                    </li>
                                    <li><a href="#"><img src="themes/yzl_v1/images/taobao_wall.jpg" width="192" height="77"></a>
                                        <p><a href="#">天猫商城-易张脸官方旗舰店</a></p>
                                    </li>
                                    <li><a href="#"><img src="themes/yzl_v1/images/taobao_wall.jpg" width="192" height="77"></a>
                                        <p><a href="#">天猫商城-易张脸官方旗舰店</a></p>
                                    </li>
                                </ul>
                                <ul class="slide brands">
                                    <li><a href="#"><img src="themes/yzl_v1/images/taobao_wall.jpg" width="192" height="77"></a>
                                        <p><a href="#">1111</a></p>
                                    </li>
                                    <li><a href="#"><img src="themes/yzl_v1/images/taobao_wall.jpg" width="192" height="77"></a>
                                        <p><a href="#">2222天猫商城-易张脸官方旗舰店</a></p>
                                    </li>
                                    <li><a href="#"><img src="themes/yzl_v1/images/taobao_wall.jpg" width="192" height="77"></a>
                                        <p><a href="#">333天猫商城-易张脸官方旗舰店</a></p>
                                    </li>
                                </ul>
                                <ul class="slide brands">
                                    <li><a href="#"><img src="themes/yzl_v1/images/taobao_wall.jpg" width="192" height="77"></a>
                                        <p><a href="#">444天猫商城-易张脸官方旗舰店</a></p>
                                    </li>
                                    <li><a href="#"><img src="themes/yzl_v1/images/taobao_wall.jpg" width="192" height="77"></a>
                                        <p><a href="#">555天猫商城-易张脸官方旗舰店</a></p>
                                    </li>
                                    <li><a href="#"><img src="themes/yzl_v1/images/taobao_wall.jpg" width="192" height="77"></a>
                                        <p><a href="#">666天猫商城-易张脸官方旗舰店</a></p>
                                    </li>
                                </ul>
                            </div>
                            <div class="arrow prev skinPrev"><a class="bgpng" href="javascript:void(0);"><img src="themes/yzl_v1/images/web-city-allowsleft.jpg" width="27" height="36"></a></div>
                            <div class="arrow next skinNext"><a class="bgpng" href="javascript:void(0);"><img src="themes/yzl_v1/images/web-city-allowsleft-02.jpg" width="27" height="36"></a></div>    
                            <!-- <span class="right_arrows"><img src="themes/yzl_v1/images/web-city-allowsleft-02.jpg" width="27" height="36"></span> -->
                        </div>
                    </div>
                    <div class="web_shop_right">
                        <h1><strong>欢迎扫描二维码</strong><span><a href="#">MORE&gt;</a></span></h1>
                        <div class="web_code_box fxplay">
                            <div class="web_show_code play-box">
                                <div class="play-item">
                                    <img src="themes/yzl_v1/images/web-code.jpg" width="72" height="72">
                                    <a href="#">天猫商城-易张脸官方旗舰店</a>
                                </div>
                                 <div class="play-item">
                                   <img src="themes/yzl_v1/images/web-code.jpg" width="72" height="72">
                                    <a href="#">222</a>
                                </div>
                                <div class="play-item">
                                    <img src="themes/yzl_v1/images/web-code.jpg" width="72" height="72">
                                    <a href="#">333</a>
                                </div>
                            </div>
                            <div id="playNo"></div>
                            <!-- <ul class="web_spot"> -->
                                <!-- <li><a href="#"></a></li>
                                <li><a href="#"><img src="themes/yzl_v1/images/web_yellow.jpg" width="9" height="9"></a></li>
                                <li><a href="#"><img src="themes/yzl_v1/images/web_yellow.jpg" width="9" height="9"></a></li> -->
                            <!-- </ul> -->
                        </div>
                        <script>
                            //
                            $(function() {
                                $(".web_spot li").hover(function(){
                                    //alert(1111);
                                },function(){
                                    //alert(222222);
                                });
                            });
                            //网店轮播
                            $(function() {       
                              $('#slidesSkincare').slides({
                                prev: 'skinPrev',
                                next: 'skinNext',
                                generatePagination: false
                              });
                            });
                            //二维码轮播区域设置
                            $('.fxplay').fxuiPlay({
                                qq:1144042682,          //作者QQ号
                                prev:$('#prev'),     //上一张
                                next:$('#next'),     //下一张
                                no:$('#playNo'),     //是否开启数字
                                auto:false,           //是否自动播放
                                autotime:3000,       //自动播放间隔
                                effect:0,            //特效类型 0：渐变；1：变小 ;2:左右; 3:上下;
                                efftime:400,         //渐变时间
                                ismobi:false,         //如果手机端请传ture,会开启划动的操作。
                                evt:'click'          //click(默认)和hover/mouserover
                            });
                        </script>
                    </div>
                </div>
            </div>
            <li class="online_wall">
                <p><a class="pointer" href="javascript:;">网上商城  Online wall</a><span><a href="javascript:;" class="pointer"><img src="themes/yzl_v1/images/arrow.jpg" width="13" height="13"></a></span> </p>
                <ul class="part">
                    <li><a href="#"><img src="themes/yzl_v1/images/club.jpg" width="147" height="35"></a></li>
                    <li><a href="#"><img src="themes/yzl_v1/images/webo.jpg" width="115" height="35"></a></li>
                </ul>
            </li>
            <script>
                $(function() {
                    $('.online_wall a.pointer').click(function() {
                        $('.web_shop').slideToggle();
                    });
                });
            </script>
        </ul>
    </div>
</div>
</body>
</html>
