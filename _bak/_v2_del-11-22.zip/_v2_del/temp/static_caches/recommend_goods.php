<?php
$data = array (
  'best' => 
  array (
  ),
  'new' => 
  array (
  ),
  'hot' => 
  array (
  ),
  'brand' => 
  array (
  ),
);
?>