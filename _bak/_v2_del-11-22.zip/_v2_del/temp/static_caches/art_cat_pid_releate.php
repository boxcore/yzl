<?php
$data = array (
  0 => 
  array (
    'cat_id' => '1',
    'cat_name' => '走进易张脸',
    'cat_type' => '1',
    'keywords' => '走进易张脸 k',
    'cat_desc' => '走进易张脸 d',
    'cat_detail' => '',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '0',
    'mark' => '',
    'define_url' => 'culture',
    'has_children' => '4',
    'aricle_num' => '4',
  ),
  1 => 
  array (
    'cat_id' => '2',
    'cat_name' => '帮助中心',
    'cat_type' => '1',
    'keywords' => 'k 帮助中心',
    'cat_desc' => 'd 帮助中心',
    'cat_detail' => NULL,
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '0',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  2 => 
  array (
    'cat_id' => '3',
    'cat_name' => '又是分类',
    'cat_type' => '1',
    'keywords' => '淡淡的',
    'cat_desc' => '订单',
    'cat_detail' => '<p>&nbsp;dcdvdfcdcdcdcdc</p>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '0',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  3 => 
  array (
    'cat_id' => '8',
    'cat_name' => '测试分类',
    'cat_type' => '1',
    'keywords' => '的地方',
    'cat_desc' => '打发打发打发',
    'cat_detail' => '<p>&nbsp;sdcdfdfdfdfdfdfdddfdfdfdfadfadfadfd<strong>fdfdfdfdfdfd</strong>f dfa<u>dfadfa</u>dfa</p>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '0',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  4 => 
  array (
    'cat_id' => '9',
    'cat_name' => '花本养肤',
    'cat_type' => '1',
    'keywords' => '分隔符',
    'cat_desc' => '发广告',
    'cat_detail' => '<h1 class="from_flowers">&nbsp;</h1>
<div class="flower_language">
<h2>花神不老颜，掀起以花养颜千年历史</h2>
<div class="language_box">花姑即花神，原名黄令微。作为承载代表百花之美的神仙，在得道之前一生种花，令人称道的不仅仅是她在养花之道上的造诣，更是她在80高龄却有着少女容貌&hellip;&hellip;花养颜，颜如花，花姑能年过八旬依然形若少女，与之常年与花为伍，近花爱花不无关系。</div>
<div class="spring"><img src="images/spring.jpg" width="244" height="49" alt="" /></div>
</div>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '0',
    'mark' => '',
    'define_url' => '',
    'has_children' => '2',
    'aricle_num' => '0',
  ),
  5 => 
  array (
    'cat_id' => '12',
    'cat_name' => '美颜讲堂',
    'cat_type' => '1',
    'keywords' => '',
    'cat_desc' => '',
    'cat_detail' => '<h1 class="the_flower"></h1>
            <ul class="the_flower_box">
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/Jasmine.png" width="341" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/lily_flower.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/rose.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/sakura.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/peony.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/Bodhi.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/Lavender.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/peach.png" width="341" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/Snow-lotus.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/orchid.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/Marigold.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/Chamomile.png" width="167" height="341"></a></li>
                <li><span class="one"></span><span class="two"></span><span class="three"></span><span class="four"></span><a href="#"><img src="images/Lotus.png" width="341" height="341"></a></li>
            </ul>
        ',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '0',
    'mark' => '',
    'define_url' => 'myjt',
    'has_children' => '3',
    'aricle_num' => '0',
  ),
  6 => 
  array (
    'cat_id' => '13',
    'cat_name' => '易颜之法',
    'cat_type' => '1',
    'keywords' => '',
    'cat_desc' => '',
    'cat_detail' => '<p>&nbsp;淡淡的</p>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '0',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  7 => 
  array (
    'cat_id' => '14',
    'cat_name' => '美自天然',
    'cat_type' => '1',
    'keywords' => '',
    'cat_desc' => '',
    'cat_detail' => '<p>&nbsp;订单</p>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '0',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  8 => 
  array (
    'cat_id' => '4',
    'cat_name' => '公司新闻',
    'cat_type' => '1',
    'keywords' => '淡淡的',
    'cat_desc' => '的发发',
    'cat_detail' => '',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '1',
    'mark' => '',
    'define_url' => 'news',
    'has_children' => '0',
    'aricle_num' => '4',
  ),
  9 => 
  array (
    'cat_id' => '5',
    'cat_name' => '品牌下载',
    'cat_type' => '1',
    'keywords' => '品牌下载品牌下载',
    'cat_desc' => '品牌下载品牌下载品牌下载',
    'cat_detail' => '<h1 class="wall_paper">&nbsp;</h1>
<ul class="wall-box">
    <li><img src="images/wallpaper-pic1.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li class="no-margin"><img src="images/wallpaper-pic2.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li><img src="images/wallpaper-pic1.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li class="no-margin"><img src="images/wallpaper-pic2.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li><img src="images/wallpaper-pic1.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
    <li class="no-margin"><img src="images/wallpaper-pic2.jpg" width="300" height="197" alt="" />
    <div class="wall-text">
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    <p><a href="#">1024x768</a></p>
    </div>
    </li>
</ul>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '1',
    'mark' => '',
    'define_url' => 'brand_download',
    'has_children' => '0',
    'aricle_num' => '2',
  ),
  10 => 
  array (
    'cat_id' => '6',
    'cat_name' => '招纳贤才',
    'cat_type' => '1',
    'keywords' => '招纳贤才招纳贤才',
    'cat_desc' => '招纳贤才招纳贤才',
    'cat_detail' => '<h1 class="join_us">&nbsp;</h1>
<div class="job-right-box">
<div class="job-text">请将你的简历发至邮箱：<span>2010718254@qq.com </span>联系电话：<span>18723780368</span><br />
<p>请注意每人只能投一个职位，多投将视为无效简历；<br />
请提供有效的联系电话、手机号码等联系方式，以便于通知面试；<br />
请准时参加面试，因故不能按时参加，请电话通知我们；</p>
<p>公司地址：<span>重庆市北部新区栖霞路18号融创金贸时代广场1栋15F</span></p>
</div>
</div>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '1',
    'mark' => '',
    'define_url' => 'join_us',
    'has_children' => '0',
    'aricle_num' => '13',
  ),
  11 => 
  array (
    'cat_id' => '7',
    'cat_name' => '联系我们',
    'cat_type' => '1',
    'keywords' => '联系我们联系我们',
    'cat_desc' => '联系我们联系我们联系我们',
    'cat_detail' => '<h1 class="contact_us">&nbsp;</h1>
<div class="hotline_box">
<div class="left">
<h1><img src="images/add.jpg" width="111" height="35" alt="" /></h1>
<p class="hotline_add">重庆易张脸化妆品有限公司</p>
<p class="hotline_add"><span>地址: 重庆市北部新区栖霞路18号融创金茂时代1栋15层<br />
邮编：400015 </span></p>
</div>
<div class="right"><a href="#"><img src="images/hot-tel.jpg" width="281" height="142" alt="" /></a></div>
</div>
<div class="map"><img src="images/map.jpg" width="702" height="456" alt="" /></div>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '1',
    'mark' => '',
    'define_url' => 'contact_us',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  12 => 
  array (
    'cat_id' => '10',
    'cat_name' => '花神之说',
    'cat_type' => '1',
    'keywords' => '',
    'cat_desc' => '',
    'cat_detail' => '<h1 class="from_flowers"></h1>
            <div class="flower_language">
                <h2>花神不老颜，掀起以花养颜千年历史</h2>
                <div class="language_box"> 花姑即花神，原名黄令微。作为承载代表百花之美的神仙，在得道之前一生种花，令人称道的不仅仅是她在养花之道上的造诣，更是她在80高龄却有着少女容貌……花养颜，颜如花，花姑能年过八旬依然形若少女，与之常年与花为伍，近花爱花不无关系。 </div>
                <div class="spring"><img src="images/spring.jpg" width="244" height="49"></div>
            </div>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '9',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  13 => 
  array (
    'cat_id' => '11',
    'cat_name' => '传承千年',
    'cat_type' => '1',
    'keywords' => '',
    'cat_desc' => '',
    'cat_detail' => '<h1 class="millennium"></h1>
            <div class="millennium_box">
                <div class="tittle"><img src="images/Millennium_tittle.jpg" width="220" height="523"></div>
                <div class="text"><img src="images/Millennium_text.jpg" width="355" height="383"></div>
            </div>',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '9',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  14 => 
  array (
    'cat_id' => '15',
    'cat_name' => '肤质解析堂',
    'cat_type' => '1',
    'keywords' => '',
    'cat_desc' => '',
    'cat_detail' => '',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '12',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  15 => 
  array (
    'cat_id' => '16',
    'cat_name' => '养肤常识堂',
    'cat_type' => '1',
    'keywords' => '',
    'cat_desc' => '',
    'cat_detail' => '',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '12',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
  16 => 
  array (
    'cat_id' => '17',
    'cat_name' => '花本养肤堂',
    'cat_type' => '1',
    'keywords' => '',
    'cat_desc' => '',
    'cat_detail' => '',
    'sort_order' => '50',
    'show_in_nav' => '0',
    'parent_id' => '12',
    'mark' => '',
    'define_url' => '',
    'has_children' => '0',
    'aricle_num' => '0',
  ),
);
?>