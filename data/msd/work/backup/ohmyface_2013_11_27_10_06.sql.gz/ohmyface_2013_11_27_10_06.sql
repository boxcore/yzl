-- Status:90:4765:MP_0:ohmyface:php:1.24.4:1127-bak:5.0.77-log:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|yzl_account_log|0|1024|2013-11-26 16:21:56|MyISAM
-- TABLE|yzl_ad|0|1024|2013-11-26 16:21:56|MyISAM
-- TABLE|yzl_ad_custom|0|1024|2013-11-26 16:21:56|MyISAM
-- TABLE|yzl_ad_position|0|1024|2013-11-26 16:21:56|MyISAM
-- TABLE|yzl_admin_action|109|5524|2013-11-26 16:21:57|MyISAM
-- TABLE|yzl_admin_log|375|36104|2013-11-27 09:53:53|MyISAM
-- TABLE|yzl_admin_message|0|1024|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_admin_user|2|5112|2013-11-27 10:06:12|MyISAM
-- TABLE|yzl_adsense|0|1024|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_affiliate_log|0|1024|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_agency|0|1024|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_area_region|9|2111|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_article|17|36048|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_article_cat|20|18416|2013-11-27 10:06:12|MyISAM
-- TABLE|yzl_article_file|0|1024|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_article_wallpaper|38|9428|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_attribute|9|3636|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_auction_log|1|3091|2013-11-26 16:21:58|MyISAM
-- TABLE|yzl_auto_manage|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_back_goods|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_back_order|4|4916|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_bonus_type|4|2284|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_booking_goods|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_brand|1|7192|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_card|1|2132|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_cart|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_cat_recommend|14|2146|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_category|20|8120|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_collect_goods|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_comment|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_crons|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_delivery_goods|9|4612|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_delivery_order|6|5328|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_email_list|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_email_sendlist|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_error_log|0|1024|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_exchange_goods|2|2068|2013-11-26 16:21:59|MyISAM
-- TABLE|yzl_favourable_activity|1|6216|2013-11-26 16:22:00|MyISAM
-- TABLE|yzl_feedback|0|1024|2013-11-26 16:22:00|MyISAM
-- TABLE|yzl_friend_link|0|1024|2013-11-26 16:22:00|MyISAM
-- TABLE|yzl_goods|9|24404|2013-11-27 09:53:21|MyISAM
-- TABLE|yzl_goods_activity|7|7560|2013-11-26 16:22:00|MyISAM
-- TABLE|yzl_goods_article|27|2264|2013-11-26 16:22:00|MyISAM
-- TABLE|yzl_goods_attr|36|5108|2013-11-26 16:22:00|MyISAM
-- TABLE|yzl_goods_cat|6|2090|2013-11-26 16:22:00|MyISAM
-- TABLE|yzl_goods_gallery|64|15492|2013-11-26 16:22:00|MyISAM
-- TABLE|yzl_goods_type|1|2068|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_group_goods|6|2126|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_keywords|43|4052|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_link_goods|10|2138|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_mail_templates|14|9148|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_member_price|4|3124|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_nav|11|4576|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_order_action|31|4096|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_order_goods|1|4188|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_order_info|1|12532|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_pack|1|2156|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_package_goods|6|2126|2013-11-26 16:22:01|MyISAM
-- TABLE|yzl_pay_log|18|2318|2013-11-26 16:22:02|MyISAM
-- TABLE|yzl_payment|3|3532|2013-11-26 16:22:02|MyISAM
-- TABLE|yzl_plugins|0|1024|2013-11-26 16:22:02|MyISAM
-- TABLE|yzl_products|14|2328|2013-11-26 16:22:02|MyISAM
-- TABLE|yzl_reg_extend_info|0|1024|2013-11-26 16:22:02|MyISAM
-- TABLE|yzl_reg_fields|7|2196|2013-11-26 16:22:02|MyISAM
-- TABLE|yzl_region|3408|182296|2013-11-26 16:22:04|MyISAM
-- TABLE|yzl_role|0|1024|2013-11-26 16:22:05|MyISAM
-- TABLE|yzl_searchengine|0|1024|2013-11-26 16:22:05|MyISAM
-- TABLE|yzl_sessions|10|1669880||MEMORY
-- TABLE|yzl_sessions_data|7|7220|2013-11-27 09:49:44|MyISAM
-- TABLE|yzl_shipping|7|3924|2013-11-26 16:22:05|MyISAM
-- TABLE|yzl_shipping_area|4|4240|2013-11-26 16:22:05|MyISAM
-- TABLE|yzl_shop_config|177|20220|2013-11-27 10:06:12|MyISAM
-- TABLE|yzl_snatch_log|2|3106|2013-11-26 16:22:06|MyISAM
-- TABLE|yzl_stats|140|16680|2013-11-27 09:55:51|MyISAM
-- TABLE|yzl_suppliers|2|2136|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_tag|0|1024|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_template|0|1024|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_topic|2|2820|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_user_account|0|1024|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_user_address|2|3204|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_user_bonus|9|3288|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_user_feed|0|1024|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_user_rank|3|2112|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_users|9|7208|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_virtual_card|13|5916|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_volume_price|5|2108|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_vote|0|1024|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_vote_log|0|1024|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_vote_option|3|3136|2013-11-26 16:22:07|MyISAM
-- TABLE|yzl_wholesale|0|1024|2013-11-26 16:22:07|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2013-11-27 10:06

--
-- Create Table `yzl_account_log`
--

DROP TABLE IF EXISTS `yzl_account_log`;
CREATE TABLE `yzl_account_log` (
  `log_id` mediumint(8) unsigned NOT NULL auto_increment,
  `user_id` mediumint(8) unsigned NOT NULL,
  `user_money` decimal(10,2) NOT NULL,
  `frozen_money` decimal(10,2) NOT NULL,
  `rank_points` mediumint(9) NOT NULL,
  `pay_points` mediumint(9) NOT NULL,
  `change_time` int(10) unsigned NOT NULL,
  `change_desc` varchar(255) NOT NULL,
  `change_type` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  (`log_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_account_log`
--

/*!40000 ALTER TABLE `yzl_account_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_account_log` ENABLE KEYS */;


--
-- Create Table `yzl_ad`
--

DROP TABLE IF EXISTS `yzl_ad`;
CREATE TABLE `yzl_ad` (
  `ad_id` smallint(5) unsigned NOT NULL auto_increment,
  `position_id` smallint(5) unsigned NOT NULL default '0',
  `media_type` tinyint(3) unsigned NOT NULL default '0',
  `ad_name` varchar(60) NOT NULL default '',
  `ad_link` varchar(255) NOT NULL default '',
  `ad_code` text NOT NULL,
  `start_time` int(11) NOT NULL default '0',
  `end_time` int(11) NOT NULL default '0',
  `link_man` varchar(60) NOT NULL default '',
  `link_email` varchar(60) NOT NULL default '',
  `link_phone` varchar(60) NOT NULL default '',
  `click_count` mediumint(8) unsigned NOT NULL default '0',
  `enabled` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`ad_id`),
  KEY `position_id` (`position_id`),
  KEY `enabled` (`enabled`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_ad`
--

/*!40000 ALTER TABLE `yzl_ad` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_ad` ENABLE KEYS */;


--
-- Create Table `yzl_ad_custom`
--

DROP TABLE IF EXISTS `yzl_ad_custom`;
CREATE TABLE `yzl_ad_custom` (
  `ad_id` mediumint(8) unsigned NOT NULL auto_increment,
  `ad_type` tinyint(1) unsigned NOT NULL default '1',
  `ad_name` varchar(60) default NULL,
  `add_time` int(10) unsigned NOT NULL default '0',
  `content` mediumtext,
  `url` varchar(255) default NULL,
  `ad_status` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ad_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_ad_custom`
--

/*!40000 ALTER TABLE `yzl_ad_custom` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_ad_custom` ENABLE KEYS */;


--
-- Create Table `yzl_ad_position`
--

DROP TABLE IF EXISTS `yzl_ad_position`;
CREATE TABLE `yzl_ad_position` (
  `position_id` tinyint(3) unsigned NOT NULL auto_increment,
  `position_name` varchar(60) NOT NULL default '',
  `ad_width` smallint(5) unsigned NOT NULL default '0',
  `ad_height` smallint(5) unsigned NOT NULL default '0',
  `position_desc` varchar(255) NOT NULL default '',
  `position_style` text NOT NULL,
  PRIMARY KEY  (`position_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_ad_position`
--

/*!40000 ALTER TABLE `yzl_ad_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_ad_position` ENABLE KEYS */;


--
-- Create Table `yzl_admin_action`
--

DROP TABLE IF EXISTS `yzl_admin_action`;
CREATE TABLE `yzl_admin_action` (
  `action_id` tinyint(3) unsigned NOT NULL auto_increment,
  `parent_id` tinyint(3) unsigned NOT NULL default '0',
  `action_code` varchar(20) NOT NULL default '',
  `relevance` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`action_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=136 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_admin_action`
--

/*!40000 ALTER TABLE `yzl_admin_action` DISABLE KEYS */;
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('1','0','goods','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('2','0','cms_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('3','0','users_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('4','0','priv_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('5','0','sys_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('6','0','order_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('7','0','promotion','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('8','0','email','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('9','0','templates_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('10','0','db_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('11','0','sms_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('21','1','goods_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('22','1','remove_back','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('23','1','cat_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('24','1','cat_drop','cat_manage');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('25','1','attr_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('26','1','brand_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('27','1','comment_priv','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('84','1','tag_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('30','2','article_cat','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('31','2','article_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('32','2','shopinfo_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('33','2','shophelp_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('34','2','vote_priv','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('35','7','topic_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('74','4','template_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('73','3','feedback_priv','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('38','3','integrate_users','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('39','3','sync_users','integrate_users');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('40','3','users_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('41','3','users_drop','users_manage');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('42','3','user_rank','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('85','3','surplus_manage','account_manage');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('43','4','admin_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('44','4','admin_drop','admin_manage');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('45','4','allot_priv','admin_manage');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('46','4','logs_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('47','4','logs_drop','logs_manage');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('48','5','shop_config','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('49','5','ship_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('50','5','payment','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('51','5','shiparea_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('52','5','area_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('53','6','order_os_edit','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('54','6','order_ps_edit','order_os_edit');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('55','6','order_ss_edit','order_os_edit');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('56','6','order_edit','order_os_edit');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('57','6','order_view','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('58','6','order_view_finished','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('59','6','repay_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('60','6','booking','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('61','6','sale_order_stats','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('62','6','client_flow_stats','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('78','7','snatch_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('83','7','ad_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('80','7','gift_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('81','7','card_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('70','1','goods_type','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('82','7','pack','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('79','7','bonus_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('75','5','friendlink','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('76','5','db_backup','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('77','5','db_renew','db_backup');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('86','4','agency_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('87','3','account_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('88','5','flash_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('89','5','navigator','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('90','7','auction','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('91','7','group_by','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('92','7','favourable','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('93','7','whole_sale','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('94','1','goods_auto','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('95','2','article_auto','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('96','5','cron','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('97','5','affiliate','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('98','5','affiliate_ck','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('99','8','attention_list','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('100','8','email_list','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('101','8','magazine_list','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('102','8','view_sendlist','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('103','1','virualcard','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('104','7','package_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('105','1','picture_batch','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('106','1','goods_export','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('107','1','goods_batch','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('108','1','gen_goods_script','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('109','5','sitemap','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('110','5','file_priv','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('111','5','file_check','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('112','9','template_select','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('113','9','template_setup','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('114','9','library_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('115','9','lang_edit','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('116','9','backup_setting','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('117','9','mail_template','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('118','10','db_backup','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('119','10','db_renew','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('120','10','db_optimize','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('121','10','sql_query','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('122','10','convert','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('124','11','sms_send','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('128','7','exchange_goods','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('129','6','delivery_view','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('130','6','back_view','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('131','5','reg_fields','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('132','5','shop_authorized','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('133','5','webcollect_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('134','4','suppliers_manage','');
INSERT INTO `yzl_admin_action` (`action_id`,`parent_id`,`action_code`,`relevance`) VALUES ('135','4','role_manage','');
/*!40000 ALTER TABLE `yzl_admin_action` ENABLE KEYS */;


--
-- Create Table `yzl_admin_log`
--

DROP TABLE IF EXISTS `yzl_admin_log`;
CREATE TABLE `yzl_admin_log` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `log_time` int(10) unsigned NOT NULL default '0',
  `user_id` tinyint(3) unsigned NOT NULL default '0',
  `log_info` varchar(255) NOT NULL default '',
  `ip_address` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`log_id`),
  KEY `log_time` (`log_time`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=949 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_admin_log`
--

/*!40000 ALTER TABLE `yzl_admin_log` DISABLE KEYS */;
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('574','1381275543','1','删除操作日志: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('575','1381276273','1','编辑商店设置: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('576','1381294327','1','添加文章分类: 肤质解析堂','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('577','1381294348','1','添加文章分类: 养肤常识堂','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('578','1381294363','1','添加文章分类: 花本养肤堂','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('579','1381368698','1','添加会员注册项: 姓名','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('580','1381443537','1','编辑文章分类: 测试分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('581','1381443614','1','添加文章分类: 下载测试分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('582','1381443661','1','编辑文章分类: 品牌下载','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('583','1381444082','1','添加文章分类: 视频广告','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('584','1381444107','1','添加文章分类: 桌面壁纸','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('585','1381444360','1','添加文章: 美女壁纸一','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('586','1381444443','1','编辑文章: 美女壁纸一','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('587','1381708770','1','添加文章: test','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('588','1381733858','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('589','1381733980','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('590','1381734077','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('591','1381734128','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('592','1381734148','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('593','1381734178','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('594','1381734185','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('595','1381734403','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('596','1381734410','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('597','1381734941','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('598','1381734969','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('599','1381736808','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('600','1381736836','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('601','1381736845','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('602','1381736853','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('603','1381736906','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('604','1381737015','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('605','1381737071','1','添加文章: tets111','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('606','1381737175','1','添加文章: 都纷纷发','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('607','1381737369','1','添加文章: 都纷纷发','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('608','1381737521','1','添加文章: 都纷纷发','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('609','1381737532','1','添加文章: 都纷纷发','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('610','1381737793','1','添加文章: 都纷纷发','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('611','1381737844','1','添加文章: 都纷纷发','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('612','1381738093','1','批量还原商品: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('613','1381738409','1','添加文章: 东风发放','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('614','1381738453','1','添加文章: 东风发放','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('615','1381738473','1','添加文章: 东风发放','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('616','1381738543','1','添加文章: 测试壁纸图片上传','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('617','1381739112','1','添加文章: 测试壁纸图片上传','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('618','1381739478','1','添加文章: 测试壁纸图片上传','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('619','1381740403','1','添加文章: 测试的博客文章啊','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('620','1381740460','1','添加文章: 发饿啊发额法尔法恶法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('621','1381741534','1','添加文章: fefafaefaefaefd','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('622','1381741763','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('623','1381741768','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('624','1381741774','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('625','1381741787','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('626','1381741788','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('627','1381741804','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('628','1381741835','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('629','1381741866','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('630','1381741925','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('631','1381742113','1','添加文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('632','1381744590','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('633','1381744605','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('634','1381744622','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('635','1381744679','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('636','1381744965','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('637','1381745037','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('638','1381745161','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('639','1381745209','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('640','1381745232','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('641','1381745271','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('642','1381745316','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('643','1381745724','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法33','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('644','1381746515','1','编辑文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('645','1381747126','1','删除文章: zsdvafjzh分析师硅灰石粉电话噶的说法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('646','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('647','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('648','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('649','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('650','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('651','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('652','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('653','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('654','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('655','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('656','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('657','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('658','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('659','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('660','1381747135','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('661','1381748095','1','编辑文章分类: 视频广告','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('662','1381748348','1','添加文章: 【视频广告】广告一','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('663','1381748391','1','添加文章: 【广告二】','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('664','1382296235','1','编辑商店设置: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('665','1382296675','1','删除商品分类: 电池','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('666','1382296680','1','删除商品分类: 3G手机','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('667','1382296682','1','删除商品分类: 双模手机','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('668','1382296694','1','删除商品分类: CDMA手机','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('669','1382296699','1','删除商品分类: 联通手机充值卡','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('670','1382296702','1','删除商品分类: 移动手机充值卡','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('671','1382309723','1','添加文章: 图片2','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('672','1382310089','1','编辑文章: 图片2','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('673','1382310129','1','编辑文章: 图片2','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('674','1382310383','1','编辑文章: 图片2','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('675','1382314758','1','添加文章: 图片3','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('676','1382315262','1','编辑商店设置: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('677','1382315515','1','添加文章: 壁纸4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('678','1382316614','1','添加文章: 图片5','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('679','1382317362','1','编辑文章: 图片2','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('680','1382317404','1','编辑文章: 壁纸4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('681','1382317502','1','编辑文章: 图片3','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('682','1382317524','1','添加文章: 壁纸6','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('683','1382317538','1','添加文章: 二分法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('684','1382317552','1','编辑文章: 二分法','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('685','1382317566','1','添加文章: 飞发发额发额地方','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('686','1382317582','1','添加文章: 发啊额为','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('687','1382317596','1','添加文章: 发违法的法儿V发','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('688','1382318135','1','编辑商店设置: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('689','1382318257','1','编辑文章分类: 桌面壁纸','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('690','1382318634','1','编辑文章: 美女壁纸一','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('691','1382318655','1','删除文章: 美女壁纸一','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('692','1382319935','1','添加文章: 是都纷纷发','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('693','1382319952','1','删除文章: 是都纷纷发','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('694','1382320024','1','添加文章: 多发额发发呆','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('695','1382320031','1','添加文章: 多发额发发呆','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('696','1382320229','1','删除文章: 多发额发发呆','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('697','1382320254','1','删除文章: 多发额发发呆','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('698','1382375335','1','编辑文章分类: 公司新闻','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('699','1382375843','1','编辑文章分类: 招纳贤才','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('700','1382375939','1','编辑文章分类: 招纳贤才','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('701','1382375955','1','编辑文章分类: 招纳贤才','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('702','1382376551','1','编辑文章分类: 易享·花养颜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('703','1382376570','1','添加文章分类: 线上商城','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('704','1382376595','1','编辑文章分类: 线上商城','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('705','1382376620','1','添加文章分类: 线下商城','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('706','1382376632','1','添加文章分类: 授权代理','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('707','1382376691','1','编辑文章分类: 线上商城','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('708','1382377891','1','添加文章分类: 订购帮助','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('709','1382378249','1','添加文章分类: 手机专享','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('710','1382884083','1','编辑商品: 荷花清颜水肌睡眠面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('711','1382884235','1','编辑商品: 荷花清颜水肌睡眠面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('712','1382884344','1','编辑商品: 牡丹紧致逆颜蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('713','1382884434','1','编辑商品: 牡丹紧致逆颜蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('714','1382884452','1','编辑商品: 牡丹紧致逆颜蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('715','1382884467','1','删除商品类型: 书','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('716','1382884469','1','删除商品类型: 音乐','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('717','1382884471','1','删除商品类型: 电影','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('718','1382884473','1','删除商品类型: 手机','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('719','1382884475','1','删除商品类型: 笔记本电脑','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('720','1382884477','1','删除商品类型: 数码相机','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('721','1382884479','1','删除商品类型: 数码摄像机','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('722','1382884482','1','删除商品类型: 精品手机','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('723','1382884501','1','删除商品分类: 耳机','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('724','1382884516','1','删除商品分类: 充电器','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('725','1382884523','1','删除商品分类: 读卡器和内存卡','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('726','1382884529','1','删除商品分类: 手机配件','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('727','1382884598','1','编辑商品: 牡丹紧致逆颜蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('728','1382884662','1','编辑商品: 百合控油保湿蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('729','1382884711','1','编辑商品: 菩提花塑颜V脸蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('730','1382884781','1','编辑商品: 茉莉焕颜柔肤蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('731','1382884878','1','编辑商品: 玫瑰美白补水蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('732','1382884966','1','编辑商品: 玫瑰美白补水蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('733','1382884981','1','回收商品: 小灵通/固话50元充值卡','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('734','1382884988','1','删除商品: 小灵通/固话50元充值卡','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('735','1382885053','1','编辑商品: 牡丹紧致逆颜蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('736','1382885106','1','编辑夺宝奇兵: 夺宝奇兵之夏新N7','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('737','1382885133','1','编辑夺宝奇兵: 你回复的速度','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('738','1382885188','1','批量删除拍卖活动: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('739','1382897053','1','编辑文章分类: 下载测试分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('740','1382897625','1','编辑文章分类: 花本养肤堂','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('741','1384889323','1','编辑会员注册项: MSN','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('742','1384982391','1','删除友情链接: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('743','1384982392','1','删除友情链接: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('744','1384982394','1','删除友情链接: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('745','1384984149','1','编辑文章分类: 系统分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('746','1384984657','1','添加文章分类: 系统帮助','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('747','1384984738','1','编辑文章分类: 系统帮助','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('748','1384984966','1','添加文章: 常见问题','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('749','1384984970','1','编辑文章: 常见问题','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('750','1384986485','1','编辑文章: 常见问题','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('751','1384986564','1','编辑文章: 常见问题','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('752','1384986570','1','编辑文章: 常见问题','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('753','1384987231','1','添加文章: 联系我们','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('754','1384987407','1','添加文章: 网站地图','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('755','1384987655','1','添加文章: 隐私条款','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('756','1384989236','1','添加属性: 肌肤需求','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('757','1384989288','1','编辑商品: 荷花清颜水肌睡眠面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('758','1384989394','1','编辑属性: 肌肤需求','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('759','1384989706','1','添加属性: 品牌系列','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('760','1384989718','1','编辑商品: 荷花清颜水肌睡眠面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('761','1384992282','1','添加文章分类: 测试普通分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('762','1384992307','1','添加文章: 测试的问啊大是大非','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('763','1384992565','1','编辑文章分类: 测试普通分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('764','1384992576','1','编辑文章分类: 测试普通分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('765','1384992583','1','编辑文章分类: 测试普通分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('766','1384992601','1','编辑文章分类: 测试普通分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('767','1384992607','1','编辑文章分类: 测试普通分类','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('768','1384992890','1','编辑文章: 测试的问啊大是大非','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('769','1384993283','1','编辑文章: 测试的问啊大是大非','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('770','1384993474','1','编辑文章分类: 养颜学堂','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('771','1384993577','1','编辑文章分类: 花本功效堂','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('772','1384993693','1','添加文章: 玫瑰','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('773','1384995453','1','编辑文章分类: 花本功效堂','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('774','1384997795','1','添加文章: 洋甘菊','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('775','1384997813','1','添加文章: 雪莲','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('776','1384997841','1','添加文章: 雪莲2','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('777','1384997850','1','添加文章: 雪莲3','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('778','1384997859','1','添加文章: 雪莲4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('779','1385001163','1','编辑文章: 雪莲4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('780','1385001168','1','编辑文章: 雪莲4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('781','1385001193','1','编辑文章: 雪莲4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('782','1385001231','1','编辑文章: 雪莲4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('783','1385001597','1','编辑文章: 雪莲4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('784','1385009649','1','编辑文章: 雪莲4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('785','1385009734','1','添加文章: 测试上传的文章','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('786','1385009795','1','编辑文章: 测试上传的文章','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('787','1385009864','1','编辑文章: 测试上传的文章','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('788','1385019169','1','添加文章: 发送到发送到','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('789','1385019333','1','添加文章: 测试添加的商品','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('790','1385022544','1','编辑文章: 测试添加的商品','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('791','1385022610','1','编辑文章: 测试添加的商品','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('792','1385022686','1','编辑文章: 测试添加的商品','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('793','1385023244','1','删除文章: 测试添加的商品','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('794','1385023270','1','编辑文章: 发送到发送到','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('795','1385023287','1','编辑文章: 发送到发送到','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('796','1385023297','1','删除文章: 发送到发送到','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('797','1385023328','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('798','1385023328','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('799','1385023328','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('800','1385023328','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('801','1385023623','1','编辑文章: 玫瑰','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('802','1385026334','1','编辑文章: 洋甘菊','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('803','1385026348','1','编辑文章: 雪莲','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('804','1385027479','1','编辑文章: 雪莲','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('805','1385027576','1','编辑文章: 雪莲','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('806','1385027582','1','编辑文章: 雪莲','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('807','1385027677','1','编辑文章: 洋甘菊','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('808','1385027729','1','编辑文章: 玫瑰','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('809','1385027943','1','编辑文章: 雪莲','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('810','1385029825','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('811','1385029831','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('812','1385029835','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('813','1385030593','1','编辑文章分类: 线上商城','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('814','1385030673','1','编辑文章分类: 线下商城','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('815','1385031211','1','编辑文章分类: 臻享好礼','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('816','1385031221','1','编辑文章分类: 臻享好礼','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('817','1385031818','1','添加文章: 臻享好礼1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('818','1385031829','1','添加文章: 臻享好礼2','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('819','1385031840','1','添加文章: 臻享好礼3','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('820','1385031848','1','添加文章: 臻享好礼4','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('821','1385031854','1','添加文章: 臻享好礼5','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('822','1385031860','1','添加文章: 臻享好礼6','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('823','1385031865','1','添加文章: 臻享好礼7','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('824','1385031871','1','添加文章: 臻享好礼8','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('825','1385031876','1','添加文章: 臻享好礼9','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('826','1385033844','1','编辑文章: 臻享好礼9','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('827','1385033875','1','编辑文章: 臻享好礼9','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('828','1385033932','1','编辑文章: 臻享好礼9','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('829','1385034099','1','编辑文章分类: 臻享好礼','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('830','1385038151','1','删除商品分类: GSM手机','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('831','1385038161','1','删除商品分类: 小灵通/固话充值卡','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('832','1385038163','1','删除商品分类: 充值卡','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('833','1385038168','1','删除商品分类: 手机类型','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('834','1385039051','1','编辑商品分类: 养肤洁面乳','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('835','1385039074','1','编辑商品分类: 养肤洁面乳','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('836','1385039083','1','编辑商品分类: 养肤洁面乳','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('837','1385040612','1','编辑商品分类: 养肤洁面乳','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('838','1385040856','1','编辑属性: 肌肤需求','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('839','1385040881','1','编辑商品分类: 养肤洁面乳','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('840','1385040901','1','编辑商品: 牡丹紧致逆颜蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('841','1385040926','1','编辑商品: 百合控油保湿蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('842','1385052379','1','编辑商品分类: 养肤洁面乳','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('843','1385052487','1','编辑商品分类: 养肤洁面乳','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('844','1385052817','1','编辑属性: 肌肤需求','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('845','1385052850','1','编辑商品分类: 养肤洁面乳','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('846','1385052878','1','编辑商品: 牡丹紧致逆颜蚕丝面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('847','1385053057','1','编辑商品分类: 养肤洁面乳','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('848','1385053397','1','添加商品分类: 产品类型','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('849','1385058423','1','添加商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('850','1385058437','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('851','1385058573','1','编辑商品: 荷花清颜水肌睡眠面膜','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('852','1385058770','1','编辑属性: 养肤成分','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('853','1385059570','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('854','1385059619','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('855','1385059955','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('856','1385060363','1','编辑属性: 产品规格/容量','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('857','1385060365','1','编辑属性: 产地','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('858','1385060367','1','编辑属性: 所属类别','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('859','1385060368','1','编辑属性: 使用部位','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('860','1385060370','1','编辑属性: 适合肤质','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('861','1385060371','1','编辑属性: 适用人群','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('862','1385060373','1','编辑属性: 品牌系列','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('863','1385060375','1','编辑属性: 肌肤需求','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('864','1385060391','1','编辑属性: 养肤成分','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('865','1385061004','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('866','1385062453','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('867','1385062462','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('868','1385063352','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('869','1385063415','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('870','1385063437','1','编辑商品: 测试商品1','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('871','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('872','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('873','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('874','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('875','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('876','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('877','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('878','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('879','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('880','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('881','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('882','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('883','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('884','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('885','1385399358','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('886','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('887','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('888','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('889','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('890','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('891','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('892','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('893','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('894','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('895','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('896','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('897','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('898','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('899','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('900','1385399369','1','删除文章: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('901','1385399379','1','删除文章: 品牌新闻','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('902','1385399389','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('903','1385399391','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('904','1385399396','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('905','1385399398','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('906','1385399401','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('907','1385399403','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('908','1385399406','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('909','1385399468','1','删除文章: test','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('910','1385399475','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('911','1385399533','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('912','1385399840','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('913','1385399850','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('914','1385399864','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('915','1385399868','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('916','1385399878','1','删除商品分类: ','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('917','1385403686','1','编辑权限管理: zqh','113.204.104.154');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('918','1385415270','4','回收商品: 荷花清颜水肌睡眠面膜','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('919','1385415274','4','回收商品: 牡丹紧致逆颜蚕丝面膜','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('920','1385415276','4','回收商品: 茉莉焕颜柔肤蚕丝面膜','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('921','1385415278','4','回收商品: 菩提花塑颜V脸蚕丝面膜','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('922','1385415281','4','回收商品: 百合控油保湿蚕丝面膜','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('923','1385415283','4','回收商品: 牡丹紧致逆颜蚕丝面膜','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('924','1385415286','4','回收商品: 玫瑰美白补水蚕丝面膜','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('925','1385415289','4','回收商品: 牡丹紧致逆颜蚕丝面膜','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('926','1385422736','4','编辑文章分类: 养颜古方','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('927','1385422944','4','编辑文章分类: 肤质解析堂','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('928','1385425196','1','编辑文章: 隐私条款','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('929','1385425242','1','编辑文章: 隐私条款','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('930','1385425321','1','编辑文章: 网站地图','127.0.0.1');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('931','1385425673','4','编辑文章分类: 养肤常识堂','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('932','1385425906','4','编辑文章分类: 养肤常识堂','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('933','1385486318','1','编辑文章分类: 养颜学堂','113.204.104.154');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('934','1385487298','4','编辑文章分类: 养颜古方','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('935','1385487341','4','编辑文章分类: 养颜古方','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('936','1385487349','1','编辑商店设置: ','113.204.104.154');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('937','1385487383','4','编辑文章分类: 花本专家','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('938','1385487414','4','编辑文章分类: 科研实力','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('939','1385487424','1','编辑商店设置: ','113.204.104.154');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('940','1385487599','1','编辑商店设置: ','113.204.104.154');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('941','1385487820','4','编辑文章分类: 生成流程','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('942','1385488050','1','编辑商店设置: ','113.204.104.154');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('943','1385488300','4','删除商品分类: ','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('944','1385488303','1','编辑商店设置: ','113.204.104.154');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('945','1385488351','4','编辑文章分类: 养颜古方','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('946','1385488378','4','编辑文章分类: 花本专家','113.204.224.110');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('947','1385488381','1','编辑商店设置: ','113.204.104.154');
INSERT INTO `yzl_admin_log` (`log_id`,`log_time`,`user_id`,`log_info`,`ip_address`) VALUES ('948','1385488433','1','编辑商店设置: ','113.204.104.154');
/*!40000 ALTER TABLE `yzl_admin_log` ENABLE KEYS */;


--
-- Create Table `yzl_admin_message`
--

DROP TABLE IF EXISTS `yzl_admin_message`;
CREATE TABLE `yzl_admin_message` (
  `message_id` smallint(5) unsigned NOT NULL auto_increment,
  `sender_id` tinyint(3) unsigned NOT NULL default '0',
  `receiver_id` tinyint(3) unsigned NOT NULL default '0',
  `sent_time` int(11) unsigned NOT NULL default '0',
  `read_time` int(11) unsigned NOT NULL default '0',
  `readed` tinyint(1) unsigned NOT NULL default '0',
  `deleted` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(150) NOT NULL default '',
  `message` text NOT NULL,
  PRIMARY KEY  (`message_id`),
  KEY `sender_id` (`sender_id`,`receiver_id`),
  KEY `receiver_id` (`receiver_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_admin_message`
--

/*!40000 ALTER TABLE `yzl_admin_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_admin_message` ENABLE KEYS */;


--
-- Create Table `yzl_admin_user`
--

DROP TABLE IF EXISTS `yzl_admin_user`;
CREATE TABLE `yzl_admin_user` (
  `user_id` smallint(5) unsigned NOT NULL auto_increment,
  `user_name` varchar(60) NOT NULL default '',
  `email` varchar(60) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `ec_salt` varchar(10) default NULL,
  `add_time` int(11) NOT NULL default '0',
  `last_login` int(11) NOT NULL default '0',
  `last_ip` varchar(15) NOT NULL default '',
  `action_list` text NOT NULL,
  `nav_list` text NOT NULL,
  `lang_type` varchar(50) NOT NULL default '',
  `agency_id` smallint(5) unsigned NOT NULL,
  `suppliers_id` smallint(5) unsigned default '0',
  `todolist` longtext,
  `role_id` smallint(5) default NULL,
  PRIMARY KEY  (`user_id`),
  KEY `user_name` (`user_name`),
  KEY `agency_id` (`agency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_admin_user`
--

/*!40000 ALTER TABLE `yzl_admin_user` DISABLE KEYS */;
INSERT INTO `yzl_admin_user` (`user_id`,`user_name`,`email`,`password`,`ec_salt`,`add_time`,`last_login`,`last_ip`,`action_list`,`nav_list`,`lang_type`,`agency_id`,`suppliers_id`,`todolist`,`role_id`) VALUES ('1','admin','admin@admin.com','c9d1cfa480937208fde83be029123737','9645','1379897300','1385486288','113.204.104.154','all','商品列表|goods.php?act=list,订单列表|order.php?act=list,用户评论|comment_manage.php?act=list,会员列表|users.php?act=list,商店设置|shop_config.php?act=list_edit','','0','0','',NULL);
INSERT INTO `yzl_admin_user` (`user_id`,`user_name`,`email`,`password`,`ec_salt`,`add_time`,`last_login`,`last_ip`,`action_list`,`nav_list`,`lang_type`,`agency_id`,`suppliers_id`,`todolist`,`role_id`) VALUES ('4','zqh','402007248@qq.com','12d5af2d556f2f9d95cd3d160480e443','9624','1385403601','1385485284','113.204.224.110','goods_manage,remove_back,cat_manage,cat_drop,attr_manage,brand_manage,comment_priv,tag_manage,goods_type,goods_auto,picture_batch,goods_export,goods_batch,gen_goods_script,article_cat,article_manage,shopinfo_manage,shophelp_manage,vote_priv,article_auto,shop_config,ship_manage,payment,shiparea_manage,area_manage,friendlink,flash_manage,navigator,cron,affiliate,affiliate_ck,sitemap,file_priv,file_check,reg_fields,shop_authorized,webcollect_manage,ad_manage','商品列表|goods.php?act=list,订单列表|order.php?act=list,用户评论|comment_manage.php?act=list,会员列表|users.php?act=list,商店设置|shop_config.php?act=list_edit','','0','0',NULL,'0');
/*!40000 ALTER TABLE `yzl_admin_user` ENABLE KEYS */;


--
-- Create Table `yzl_adsense`
--

DROP TABLE IF EXISTS `yzl_adsense`;
CREATE TABLE `yzl_adsense` (
  `from_ad` smallint(5) NOT NULL default '0',
  `referer` varchar(255) NOT NULL default '',
  `clicks` int(10) unsigned NOT NULL default '0',
  KEY `from_ad` (`from_ad`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_adsense`
--

/*!40000 ALTER TABLE `yzl_adsense` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_adsense` ENABLE KEYS */;


--
-- Create Table `yzl_affiliate_log`
--

DROP TABLE IF EXISTS `yzl_affiliate_log`;
CREATE TABLE `yzl_affiliate_log` (
  `log_id` mediumint(8) NOT NULL auto_increment,
  `order_id` mediumint(8) NOT NULL,
  `time` int(10) NOT NULL,
  `user_id` mediumint(8) NOT NULL,
  `user_name` varchar(60) default NULL,
  `money` decimal(10,2) NOT NULL default '0.00',
  `point` int(10) NOT NULL default '0',
  `separate_type` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_affiliate_log`
--

/*!40000 ALTER TABLE `yzl_affiliate_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_affiliate_log` ENABLE KEYS */;


--
-- Create Table `yzl_agency`
--

DROP TABLE IF EXISTS `yzl_agency`;
CREATE TABLE `yzl_agency` (
  `agency_id` smallint(5) unsigned NOT NULL auto_increment,
  `agency_name` varchar(255) NOT NULL,
  `agency_desc` text NOT NULL,
  PRIMARY KEY  (`agency_id`),
  KEY `agency_name` (`agency_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_agency`
--

/*!40000 ALTER TABLE `yzl_agency` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_agency` ENABLE KEYS */;


--
-- Create Table `yzl_area_region`
--

DROP TABLE IF EXISTS `yzl_area_region`;
CREATE TABLE `yzl_area_region` (
  `shipping_area_id` smallint(5) unsigned NOT NULL default '0',
  `region_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`shipping_area_id`,`region_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_area_region`
--

/*!40000 ALTER TABLE `yzl_area_region` DISABLE KEYS */;
INSERT INTO `yzl_area_region` (`shipping_area_id`,`region_id`) VALUES ('1','1');
INSERT INTO `yzl_area_region` (`shipping_area_id`,`region_id`) VALUES ('2','1');
INSERT INTO `yzl_area_region` (`shipping_area_id`,`region_id`) VALUES ('3','1');
INSERT INTO `yzl_area_region` (`shipping_area_id`,`region_id`) VALUES ('4','3');
INSERT INTO `yzl_area_region` (`shipping_area_id`,`region_id`) VALUES ('4','4');
INSERT INTO `yzl_area_region` (`shipping_area_id`,`region_id`) VALUES ('4','6');
INSERT INTO `yzl_area_region` (`shipping_area_id`,`region_id`) VALUES ('4','9');
INSERT INTO `yzl_area_region` (`shipping_area_id`,`region_id`) VALUES ('4','30');
INSERT INTO `yzl_area_region` (`shipping_area_id`,`region_id`) VALUES ('4','32');
/*!40000 ALTER TABLE `yzl_area_region` ENABLE KEYS */;


--
-- Create Table `yzl_article`
--

DROP TABLE IF EXISTS `yzl_article`;
CREATE TABLE `yzl_article` (
  `article_id` mediumint(8) unsigned NOT NULL auto_increment,
  `cat_id` smallint(5) NOT NULL default '0',
  `title` varchar(150) NOT NULL default '',
  `content` longtext NOT NULL,
  `author` varchar(30) NOT NULL default '',
  `author_email` varchar(60) NOT NULL default '',
  `keywords` varchar(255) NOT NULL default '',
  `article_type` tinyint(1) unsigned NOT NULL default '2',
  `is_open` tinyint(1) unsigned NOT NULL default '1',
  `add_time` int(10) unsigned NOT NULL default '0',
  `file_url` varchar(255) NOT NULL default '',
  `article_thumb` varchar(255) NOT NULL,
  `article_img` varchar(255) NOT NULL,
  `original_img` varchar(255) character set ucs2 NOT NULL,
  `article_icon_1` varchar(255) NOT NULL,
  `article_icon_2` varchar(255) NOT NULL,
  `open_type` tinyint(1) unsigned NOT NULL default '0',
  `link` varchar(255) NOT NULL default '',
  `description` varchar(255) default NULL,
  `vedio_link` varchar(255) NOT NULL,
  `mark` varchar(255) NOT NULL,
  `define_url` varchar(255) NOT NULL,
  `define_theme` varchar(255) NOT NULL,
  PRIMARY KEY  (`article_id`),
  KEY `cat_id` (`cat_id`),
  KEY `mark` (`mark`),
  KEY `define_url` (`define_url`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_article`
--

/*!40000 ALTER TABLE `yzl_article` DISABLE KEYS */;
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('81','26','常见问题','<div class=\"FAQ_box\">\r\n	<div class=\"Guide\">\r\n		<h1>\r\n			<img src=\"/upload/image/20131121/20131121142800_11845.jpg\" alt=\"images/FAQ_tittle.jpg\" /> \r\n			<p>\r\n				新手指南\r\n			</p>\r\n		</h1>\r\n		<div class=\"guide_L\">\r\n			<p>\r\n				易张脸，致力于为您提供最完善的客户服务。为了使您拥有最便捷的购物体验，以下提供我们最常见问题的解答。\r\n			</p>\r\n			<p>\r\n				您如需其他帮助，可随时联系我们。如果您对订单有任何疑问，请到我们网站咨询<span>在线客服</span>或者拨打<span>400-789-5678</span>。\r\n			</p>\r\n		</div>\r\n		<div class=\"guide_R\">\r\n			<img src=\"images/FAQ_pic.jpg\" width=\"535\" height=\"134\" /> \r\n		</div>\r\n	</div>\r\n	<div class=\"FAQ_login\">\r\n		<h1>\r\n			<img src=\"images/FAQ_tittle2.jpg\" width=\"998\" height=\"33\" /> \r\n			<p>\r\n				注册/登录\r\n			</p>\r\n		</h1>\r\n		<h2>\r\n			如果您是第一次来到我们的网站，请进行如下操作：\r\n		</h2>\r\n		<ul class=\"list\">\r\n			<li>\r\n				<i>1</i> \r\n				<p>\r\n					请在页面上部点击【<span>注册/登录</span>】；\r\n				</p>\r\n			</li>\r\n			<li>\r\n				<i>2</i> \r\n				<p>\r\n					点击进入【注册/登录】页面，填写用户名、密码、邮箱等个人信息，并且选择\"我已看过并接受相关协议\"进行<span>注册</span>；\r\n				</p>\r\n			</li>\r\n			<li class=\"no_border\">\r\n				<i>3</i> \r\n				<p>\r\n					击注册按钮，完成注册。请在注册时务必详细填写<span>个人信息</span>；\r\n				</p>\r\n			</li>\r\n		</ul>\r\n		<ul class=\"list_next\">\r\n			<li>\r\n				<i>4</i> \r\n				<p>\r\n					注册成功或者有会员帐号的用户，请输入用户名及密码点击<span>登录</span> \r\n				</p>\r\n			</li>\r\n			<li class=\"five\">\r\n				<i>5</i> \r\n				<p>\r\n					对于忘记密码，我们提供了找回密码的功能，请您在点击登录旁边【<span>找回密码</span>】按钮，进入找回密码页面，填写用户名、注册时邮箱、验证码，点击提交，系统将会将密码发送到您注册的邮箱。\r\n				</p>\r\n			</li>\r\n		</ul>\r\n	</div>\r\n	<div class=\"order_flow\">\r\n		<h1>\r\n			<img src=\"images/FAQ_tittle3.jpg\" width=\"998\" height=\"33\" /> \r\n			<p>\r\n				订购流程\r\n			</p>\r\n		</h1>\r\n		<ul class=\"order_flow_box\">\r\n			<li>\r\n				<span>选购商品</span> \r\n			</li>\r\n			<li>\r\n				<span>加入购物车</span> \r\n			</li>\r\n			<li>\r\n				<span>登录/注册</span> \r\n			</li>\r\n			<li class=\"no_margin\">\r\n				<span>填写收货人信息</span> \r\n			</li>\r\n			<li>\r\n				<span>选择配送方式</span> \r\n			</li>\r\n			<li>\r\n				<span>选择支付方式</span> \r\n			</li>\r\n			<li>\r\n				<span>核对订单信息</span> \r\n			</li>\r\n			<li class=\"success\">\r\n				<span><strong>成功提交订单后</strong><br />\r\n等待收货 完成交易</span> \r\n			</li>\r\n		</ul>\r\n	</div>\r\n	<div class=\"order_pro\">\r\n		<h1>\r\n			<img src=\"images/FAQ_tittle33.jpg\" width=\"998\" height=\"33\" /> \r\n			<p>\r\n				选购商品\r\n			</p>\r\n		</h1>\r\n		<div class=\"order_pro_box\">\r\n			<div class=\"one\">\r\n				<span>通过分类栏查询 </span> \r\n				<p>\r\n					在主页上点击不同的商品种类，您可以看到所属类别的商品列表，选择<strong>人气、销量、价格、上新时间</strong>等排序方式进行选购。\r\n				</p>\r\n			</div>\r\n			<div class=\"one\">\r\n				<span>通过搜索栏查询 </span> \r\n				<p>\r\n					您可以在我们的搜索栏中键入您<strong>想要的商品名称、商品功效</strong>等关键字即可搜索到该产品。\r\n				</p>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<div class=\"alipay_way\">\r\n		<h1>\r\n			<img src=\"images/FAQ_tittle4.jpg\" width=\"998\" height=\"33\" /> \r\n			<p>\r\n				支付方式\r\n			</p>\r\n		</h1>\r\n		<p class=\"alipay_text\">\r\n			易张脸官网商城支持全球领先的独立第三方支付平台——<span>支付宝，安全快速，支持各银行在线付款。</span> \r\n		</p>\r\n		<div class=\"alipay_img\">\r\n			<img src=\"images/alipay.jpg\" width=\"115\" height=\"39\" /> \r\n		</div>\r\n	</div>\r\n	<div class=\"order_form\">\r\n		<h1>\r\n			<p>\r\n				<img src=\"images/FAQ_tittle5.jpg\" width=\"998\" height=\"33\" />配送方式\r\n			</p>\r\n		</h1>\r\n		<table width=\"876\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\r\n			<tbody>\r\n				<tr>\r\n					<td>\r\n						<span>注册用户如何查询订单状态？</span> \r\n						<p>\r\n							易张脸注册用户，可以随时在网站上登录，查看您的订单状态。此外，您也可以在每天的9:00-18:00期间（除国定假日外）拨打电话400-789-5678，联系我们的客户服务团队。在提问咨询时，请提供您的订单号码。\r\n						</p>\r\n					</td>\r\n					<td>\r\n						<span>注册用户如何查询订单状态？</span> \r\n						<p>\r\n							易张脸注册用户，可以随时在网站上登录，查看您的订单状态。此外，您也可以在每天的9:00-18:00期间（除国定假日外）拨打电话400-789-5678，联系我们的客户服务团队。在提问咨询时，请提供您的订单号码。\r\n						</p>\r\n					</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n	</div>\r\n	<div class=\"distribution_way\">\r\n		<h1>\r\n			<img src=\"images/FAQ_tittle6.jpg\" width=\"998\" height=\"33\" /> \r\n			<p>\r\n				配送方式\r\n			</p>\r\n		</h1>\r\n		<p class=\"alipay_text alipay_yzl\">\r\n			易张脸官方商城合作快递有<span>韵达、申通、顺丰</span>等，因各边区化妆品邮寄受限制，根据所在地区选择对应快递。\r\n		</p>\r\n		<div class=\"alipay_express\">\r\n			<a href=\"#\"><img src=\"images/express1.jpg\" width=\"138\" height=\"42\" /></a><a href=\"#\"><img src=\"images/express2.jpg\" width=\"125\" height=\"42\" /></a><a href=\"#\"><img src=\"images/express3.jpg\" width=\"125\" height=\"42\" /></a><a href=\"#\" class=\"no_margin\"><img src=\"images/express4.jpg\" width=\"120\" height=\"42\" /></a> \r\n		</div>\r\n	</div>\r\n	<div class=\"delivery_time\">\r\n		<h1>\r\n			<img src=\"images/FAQ_tittle7.jpg\" width=\"998\" height=\"33\" /> \r\n			<p>\r\n				配送时间\r\n			</p>\r\n		</h1>\r\n		<div class=\"delivery_inner\">\r\n			所有订购的商品统一发出；<span>每天16:00以前下的订单将于当日处理完毕并发出，</span>16:00以后下的订单将于次日之前处理完毕并发出；我们无法将产品送往中国大陆以外的地址，也无法送往诸如邮政信箱之类的虚拟地址,对于此类订单，我们将联系顾客表示歉意，并予以取消；中国大陆各地区的具体到货时间从订单出库的时间起开始计算。\r\n		</div>\r\n	</div>\r\n	<div class=\"back_time\">\r\n		<h1>\r\n			<img src=\"images/FAQ_tittle8.jpg\" width=\"998\" height=\"33\" /> \r\n			<p>\r\n				售后服务\r\n			</p>\r\n		</h1>\r\n		<div class=\"back_inner\">\r\n			<div class=\"left\">\r\n				<h1>\r\n					退换货政策：\r\n				</h1>\r\n				<ul>\r\n					<li>\r\n						<i>1</i> \r\n						<p>\r\n							收到货物时即发现产品破损;\r\n						</p>\r\n					</li>\r\n					<li>\r\n						<i>2</i> \r\n						<p>\r\n							与顾客订购的产品不同;\r\n						</p>\r\n					</li>\r\n					<li>\r\n						<i>3</i> \r\n						<p>\r\n							收到货物时即发现产品已过期。\r\n						</p>\r\n					</li>\r\n				</ul>\r\n			</div>\r\n			<div class=\"right\">\r\n				<h1>\r\n					退换货流程：\r\n				</h1>\r\n				<ul>\r\n					<li>\r\n						<i>1</i> \r\n						<p>\r\n							务必首先致电客服部门，告知所遇到的问题，然后根据客服指示进行退换货；\r\n						</p>\r\n					</li>\r\n					<li>\r\n						<i>2</i> \r\n						<p>\r\n							退换货时请提供所有需要退换的产品，哪怕已经破损或被打开；\r\n						</p>\r\n					</li>\r\n					<li>\r\n						<i>3</i> \r\n						<p>\r\n							退换货时请附上随产品一起送达的销售单据及发票；\r\n						</p>\r\n					</li>\r\n					<li>\r\n						<i>4</i> \r\n						<p>\r\n							为了您的便利，请在致电我们客户服务部时，告知您购买产品的订单号。\r\n						</p>\r\n					</li>\r\n				</ul>\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>','','','','0','1','1384984965','','','','','','','0','http://','','','','faq','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('82','26','联系我们','<div class=\"contact_us\">\r\n    	<p class=\"left\">公司地址：重庆市北部新区栖霞路18号融创金贸时代1栋1501<br>\r\n邮政编码：40015</p>\r\n        <div class=\"right\"><strong>全国订购热线</strong><span> 400-789-5678</span><br>\r\n周一至周六9:00—18:00，法定节假日除外</div>\r\n    </div>\r\n\r\n<div class=\"contact_map\"><img src=\"images/contact_bg.jpg\" width=\"995\" height=\"435\"></div>','','','联系我们联系我们','0','1','1384987231','','','','','','','0','http://','联系我们联系我们','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('83','26','网站地图','<div class=\"web_map_box\">\r\n	<ul class=\"left_nav\">\r\n		<li>\r\n			<span><a href=\"#\">用户中心</a></span> \r\n			<div class=\"inner\">\r\n				<a href=\"#\">我的订单</a><a href=\"#\">我的购物袋 </a><a href=\"#\">个人资料 </a><a href=\"#\" class=\"current\">用户密码 </a>\r\n			</div>\r\n		</li>\r\n		<li>\r\n			<span><a href=\"#\">花本养肤</a></span> \r\n			<div class=\"inner\">\r\n				<a href=\"#\">养颜古方</a><a href=\"#\">花本专家 </a><a href=\"#\">生产基地 </a><a href=\"#\">科研实力 </a><a href=\"#\">生产流程</a>\r\n			</div>\r\n		</li>\r\n		<li>\r\n			<span><a href=\"#\">养颜学堂</a></span> \r\n			<div class=\"inner\">\r\n				<a href=\"#\">花本功效堂</a><a href=\"#\">肤质解析堂 </a><a href=\"#\">养肤常识堂 </a>\r\n			</div>\r\n		</li>\r\n		<li class=\"all_pro_box\">\r\n			<span class=\"big_tittle\"><a href=\"#\">全线产品</a></span> \r\n			<div class=\"all_products\">\r\n				<div class=\"one\">\r\n					<span><a href=\"#\" class=\"pro_title\">玫瑰莹润焕白</a></span><a href=\"#\">洋甘菊清透保湿</a> <a href=\"#\">雪莲逆颜抗衰</a> \r\n				</div>\r\n				<div class=\"one\">\r\n					<span><a href=\"#\" class=\"pro_title\">产品类型</a></span><a href=\"#\">养肤洁面乳</a> <a href=\"#\">养肤水</a> <a href=\"#\">品牌宣言</a><a href=\"#\">养肤乳液</a> <a href=\"#\">养肤面霜</a><a href=\"#\">养肤蚕丝面膜</a><a href=\"#\">养肤蚕丝面膜</a> \r\n				</div>\r\n				<div class=\"one\">\r\n					<span><a href=\"#\" class=\"pro_title\">肌肤需求</a></span><a href=\"#\">肌肤黯沉、疲倦</a> <a href=\"#\">干燥、粗糙</a> <a href=\"#\">毛孔粗大、脫屑</a> <a href=\"#\">细纹/幼纹</a> <a href=\"#\">松弛、皱纹</a><a href=\"#\">色斑、肤色不均</a> \r\n				</div>\r\n			</div>\r\n		</li>\r\n		<li>\r\n			<span><a href=\"#\">活动中心</a></span> \r\n			<div class=\"inner\">\r\n				<a href=\"#\">新品发布</a><a href=\"#\">优惠活动 </a>\r\n			</div>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<div class=\"web_map_box\">\r\n	<ul class=\"left_nav\">\r\n		<li>\r\n			<span><a href=\"#\">皮肤检测中心</a></span> \r\n		</li>\r\n		<li>\r\n			<span><a href=\"#\">养肤体验馆</a></span> \r\n		</li>\r\n		<li>\r\n			<span><a href=\"#\">易享·花养颜</a></span> \r\n			<div class=\"inner\">\r\n				<a href=\"#\" class=\"current\">线上商城</a><a href=\"#\">线下商城 </a><a href=\"#\">养肤常识堂 </a>\r\n			</div>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<div class=\"web_map_box\">\r\n	<ul class=\"left_nav\">\r\n		<li>\r\n			<span><a href=\"#\">用户中心</a></span> \r\n			<div class=\"inner\">\r\n				<a href=\"#\" class=\"current\">我的订单</a><a href=\"#\">我的购物袋 </a><a href=\"#\">个人资料 </a><a href=\"use-center3.html\">用户密码 </a>\r\n			</div>\r\n		</li>\r\n		<li>\r\n			<span><a href=\"#\">在线客服</a></span> \r\n		</li>\r\n		<li>\r\n			<span><a href=\"#\">常见问题</a></span> \r\n		</li>\r\n		<li>\r\n			<span><a href=\"#\">网站地图</a></span> \r\n		</li>\r\n		<li>\r\n			<span><a href=\"#\">隐私条款</a></span> \r\n		</li>\r\n	</ul>\r\n</div>','','','网站地图','0','1','1384987407','','','','','','','0','http://','网站地图','','','','article_sitemap.dwt');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('84','26','隐私条款','<div class=\"policy_box\">\r\n	<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"policy_inner ke-zeroborder\">\r\n		<tbody>\r\n			<tr>\r\n				<td height=\"129\">\r\n					<div class=\"inner\">\r\n						<span>登录个人资料</span> \r\n						<p>\r\n							您的个人资料有助于我们辨识或联络您。当您加入会员或参与本站活动、订阅电子报或索取赠品时，会要求您填写一些个人资料，如年龄、性别、职业、电子信箱及地址等，其目的是要增进对您的了解，并提供更佳的服务。\r\n						</p>\r\n					</div>\r\n				</td>\r\n				<td>\r\n					<div class=\"inner\">\r\n						<span>对个人资料的保密</span> \r\n						<p>\r\n							您的个人资料除经您同意或政府机关、法院及其他本站应依法提供之情形者外，绝不贩卖或透露给网站以外的其他人及单位，并严禁内部人员私自使用这些资料。\r\n						</p>\r\n					</div>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					<div class=\"inner inner1\">\r\n						<span>管理个人资讯</span> \r\n						<p>\r\n							本站将提供您浏览与编辑您的个人资讯的权限。当您登录成会员或订阅相关资料时，您可以浏览或编辑您的个人资讯；您必须要先键入您的电子邮件信箱与密码。您可以：\r\n                            a·浏览或修改您先前提供的个人信息。<br />\r\nb·选择要不要收到易张脸所提供的宣传资料。<br />\r\nc·订阅或取消订阅易张脸产品或服务的电子报。\r\n						</p>\r\n					</div>\r\n				</td>\r\n				<td>\r\n					<div class=\"inner inner1\">\r\n						<span>著作权声明</span> \r\n						<p>\r\n							本站所有内容，包括但不限于文字、照片、影像、插图、录音、影音、档案、网站画面的安排、网页设计等素材，均受到相关著作权法律的保障。本网站内容或服务，仅供个人、非商业用途之使用，未经内容著作权人之授权，不得转载、公开播送或公开传输。本网站所刊载之内容，或有提供或建立相关链接供第三人使用，该等链接所指向之网页或资料，均为被链接网站所提供，相关权利为该等网站或合法权利人所有。\r\n						</p>\r\n					</div>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					<div class=\"inner\">\r\n						<span>商标声明</span> \r\n						<p>\r\n							除非另外声明，本站上出现的皆为易张脸的品牌商标。\r\n						</p>\r\n					</div>\r\n				</td>\r\n				<td>\r\n					<div class=\"inner\">\r\n						<span>保证义务免除</span> \r\n						<p>\r\n							本站所有内容由广州欧菲诗化妆品有限公司所提供，我们力求信息的准确性，但请您体谅我们无法担保这些资讯的完全准确性、即时性或完整性。\r\n						</p>\r\n					</div>\r\n				</td>\r\n			</tr>\r\n			<tr class=\"no_border\">\r\n				<td>\r\n					<div class=\"inner\">\r\n						<span>不提供授权</span> \r\n						<p>\r\n							希望本网站能带给您愉悦的浏览经验，并请您了解为保障知识产权，本网站所刊载之内容，或与其他单位合作之内容，我们不提供任何形式的授权。\r\n						</p>\r\n					</div>\r\n				</td>\r\n				<td>\r\n					<div class=\"inner\">\r\n						<span>评论使用声明</span> \r\n						<p>\r\n							广州欧菲诗化妆品有限公司感谢您提供宝贵的使用经验与所有的爱好者一同分享，不管是赞许或是指教，只要您的发言是公正且有建设性的，我们都将公布于官网上，欢迎您留下宝贵的使用心得。\r\n						</p>\r\n					</div>\r\n				</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>','','','','0','1','1384987655','','','','','','','0','http://','privacy_policy','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('85','27','测试的问啊大是大非','发射点发岁的法阿萨德发送到发生撒旦发射点发的发射点发','','','','0','1','1384992307','','','','','','','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('86','17','玫瑰','<div class=\"product_box\">\r\n            <div class=\"pic\"> <img src=\"images/big_rose.jpg\" width=\"435\" height=\"421\"></div>\r\n            <div class=\"explain\">\r\n                <h4><img src=\"images/rose_logo.jpg\" width=\"157\" height=\"45\"></h4>\r\n                <p class=\"couplet\"><img src=\"images/rose-couplet.jpg\" width=\"32\" height=\"105\"></p>\r\n                <div class=\"effect\">\r\n                    <h5>药用功效</h5>\r\n                    <p>活血调经、解郁安神，适用于缓和情绪，平衡内分泌。</p>\r\n                    <h5>美容功效</h5>\r\n                    <p>玫瑰作为养颜圣品早早就活跃于历史舞台，其功效一直备受推崇。尤其突出的是美白、控油、收敛毛孔等，所有美容的花中，玫瑰是当之无愧的冠军。</p>\r\n                    <p>1 保湿滋养，使干燥敏感的肌肤及时恢复水润柔嫩；\r\n                        4 玫瑰香气能舒缓紧致情绪，进而放松心情，给人安心与幸福感，消除压力，进一步提升美肌效果。</p>\r\n                    <p>2 具有收敛、抗菌和镇静舒缓的作用，紧致毛孔、抑制过多油脂分泌，使肌肤细腻清新，不泛油光； </p>\r\n                    <p>3 富含多种维生素、葡萄糖、果糖、柠檬糖等有益人体健康的营养物质，具有延缓衰老的作用，长期使用能使肌肤滋润而富有光泽； </p>\r\n                </div>\r\n            </div>\r\n        </div>','','','','0','1','1384993693','','','','','data/icon/201311/1385023623912606542.jpg','data/icon/201311/1385023623623957956.png','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('87','17','洋甘菊','<div class=\"product_box\">\r\n            <div class=\"pic\"><img src=\"images/big_num.jpg\" width=\"435\" height=\"421\"></div>\r\n            <div class=\"explain_num\">\r\n                <h4><img src=\"images/num_logo.jpg\" width=\"234\" height=\"53\"></h4>\r\n                <p class=\"couplet\"><img src=\"images/num-couplet.jpg\" width=\"50\" height=\"87\"></p>\r\n                <div class=\"effect\">\r\n                    <h5>药用功效</h5>\r\n                    <p>清凉、镇定、抗敏，能刺激食欲。</p>\r\n                    <h5>美容功效</h5>\r\n                    <p>洋甘菊的使用历史可追溯到公元前。因其具有良好的安抚作用而被喻为\"植物医师\"。取其抗敏舒缓之效，解除肌肤压力，让你的美丽亲近自然，随心绽放。</p>\r\n                    <p>1 洋甘菊又名西洋甘菊，是一年生草本菊科植物，花瓣呈白色细小碎裂状。它具有消炎、止痒、安抚、修护、洁净、醒肤、抗敏等功效，自古以来，就被西方人当作药草植物，除了冲茶饮用、制药之外，它更是美容界现在争相运用的完美舒缓抗敏成分。</p>\r\n                    <p>2 洋甘菊最主要的特点就是温和，因此它最适合婴儿和敏感肌肤使用，适用于修复受损肌肤、皮肤过敏、干裂缺水等。 </p>\r\n                    <p>3 可以温和调理肌肤的敏感症状，以及舒缓晒后及缺水肌肤的不适感，洋甘菊常被用在婴儿清洁保养品中，保护BABY幼嫩的肌肤。</p>\r\n                </div>\r\n            </div>\r\n        </div>','','','','0','1','1384997795','','','','','data/icon/201311/1385026334502540873.png','data/icon/201311/1385026334203867738.png','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('88','17','雪莲','<div class=\"product_box\">\r\n	<div class=\"pic\">\r\n		<img src=\"images/big_lotus.jpg\" width=\"435\" height=\"421\" />\r\n	</div>\r\n	<div class=\"explain_lotus\">\r\n		<h4>\r\n			<img src=\"images/lotus_logo.jpg\" width=\"232\" height=\"36\" />\r\n		</h4>\r\n		<p class=\"couplet\">\r\n			<img src=\"images/lotus-couplet.jpg\" width=\"32\" height=\"100\" />\r\n		</p>\r\n		<div class=\"effect\">\r\n			<h5>\r\n				药用功效\r\n			</h5>\r\n			<p>\r\n				袪风湿，强筋骨，补肾阳，调经止血。\r\n			</p>\r\n			<h5>\r\n				美容功效\r\n			</h5>\r\n			<p>\r\n				雪莲是高山稀有的名贵药用植物，5年开花，花期7月，果期8月。\r\n			</p>\r\n			<p>\r\n				1 天然的雪莲花中含有黄硐类芦、雪莲内脂、雪莲多糖等。其防晒系数高达到22SPF，远高于15SPF的国内超强度紫外线辐射，可有效地保护皮肤受紫外线侵害，在内服时表现为保健和增强免疫功能，外用时可达到美容、祛斑、延缓皮肤衰老的目的；\r\n			</p>\r\n			<p>\r\n				2 雪莲能调理肠胃，平衡内分泌，花蕊含有丰富的多种维生素，有消炎灭菌作用等功能，正适合治疗青春痘。\r\n			</p>\r\n			<p>\r\n				3 雪莲可加速皮肤新陈代谢，平衡内分泌，自然除火祛斑，减少皱纹，使皮肤保持光泽、丰满、对面部雀斑、肝斑等有良好的疗效，原来使用其他化妆品过敏的人，使用雪莲便不再过敏。\r\n			</p>\r\n		</div>\r\n	</div>\r\n</div>','','','','0','1','1384997813','','','','','data/icon/201311/1385026348902922474.png','data/icon/201311/1385026348133623085.png','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('95','27','臻享好礼1','','','','','0','1','1385031818','','','images/201311/goods_img/95_G_1385031818144.jpg','images/201311/source_img/95_G_1385031818171.jpg','','','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('96','27','臻享好礼2','','','','','0','1','1385031829','','','images/201311/goods_img/96_G_1385031829243.jpg','images/201311/source_img/96_G_1385031829628.jpg','','','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('97','27','臻享好礼3','','','','','0','1','1385031840','','','images/201311/goods_img/97_G_1385031840248.jpg','images/201311/source_img/97_G_1385031840564.jpg','','','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('98','27','臻享好礼4','','','','','0','1','1385031848','','','images/201311/goods_img/98_G_1385031848668.jpg','images/201311/source_img/98_G_1385031848124.jpg','','','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('99','27','臻享好礼5','','','','','0','1','1385031854','','','images/201311/goods_img/99_G_1385031854573.jpg','images/201311/source_img/99_G_1385031854565.jpg','','','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('100','27','臻享好礼6','','','','','0','1','1385031860','','','images/201311/goods_img/100_G_1385031860742.jpg','images/201311/source_img/100_G_1385031860614.jpg','','','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('101','27','臻享好礼7','','','','','0','1','1385031865','','','images/201311/goods_img/101_G_1385031865029.jpg','images/201311/source_img/101_G_1385031865080.jpg','','','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('102','27','臻享好礼8','','','','','0','1','1385031871','','','images/201311/goods_img/102_G_1385031871482.jpg','images/201311/source_img/102_G_1385031871690.jpg','','','0','http://','','','','','');
INSERT INTO `yzl_article` (`article_id`,`cat_id`,`title`,`content`,`author`,`author_email`,`keywords`,`article_type`,`is_open`,`add_time`,`file_url`,`article_thumb`,`article_img`,`original_img`,`article_icon_1`,`article_icon_2`,`open_type`,`link`,`description`,`vedio_link`,`mark`,`define_url`,`define_theme`) VALUES ('103','27','臻享好礼9','<p>\r\n	\"养\"和\"易\"是易张脸品牌文化中的核心点，两者既相对独立，又存在内在的必然联系。\"养\"是\"易\"的前置铺陈，\"易\"则是\"养\"的蜕变升华。而这个内在的变化可表现为两个层面。\r\n</p>\r\n<p>\r\n	以花养颜。艳丽多姿的花瓣仪态万千，雅致娇柔的花蕊魅力无限，自然界里的各色花朵蕴含着植物最美丽的奥秘，以花养颜即是传承梨园名伶百年神奇花颜养肤秘法，通过植物专家多年对各类鲜花的研究中寻找到新的护肤灵感，床在了奢华魅力、以花养颜的新时尚。 以养引易。何以为\"养\"，养可以是滋养、补养，亦可谓是培养、修养。所以易张脸品牌提出的\"养\"不仅仅指外在的面部身体滋养，更倡导在外面养护的同时调节自我，修养内在的心性。\"养\"是个漫长积累的过程，每天静静享受鲜花养肤的时刻，同时抛弃城市的喧嚣，还内心一片清新与宁静，月月年年，外修内养，或许不经意间，你以脱变成更完美的自己。\r\n</p>\r\n<p>\r\n	\"养\"和\"易\"是易张脸品牌文化中的核心点，两者既相对独立，又存在内在的必然联系。\"养\"是\"易\"的前置铺陈，\"易\"则是\"养\"的蜕变升华。而这个内在的变化可表现为两个层面。 以花养颜。艳丽多姿的花瓣仪态万千，雅致娇柔的花蕊魅力无限，自然界里的各色花朵蕴含着植物最美丽的奥秘，以花养颜即是传承梨园名伶百年神奇花颜养肤秘法，通过植物专家多年对各类鲜花的研究中寻找到新的护肤灵感，床在了奢华魅力、以花养颜的新时尚。 以养引易。何以为\"养\"，养可以是滋养、补养，亦可谓是培养、修养。所以易张脸品牌提出的\"养\"不仅仅指外在的面部身体滋养，更倡导在外面养护的同时调节自我，修养内在的心性。\"养\"是个漫长积累的过程，每天静静享受鲜花养肤的时刻，同时抛弃城市的喧嚣，还内心一片清新与宁静，月月年年，外修内养，或许不经意间，你以脱变成更完美的自己。 \"养\"和\"易\"是易张脸品牌文化中的核心点，两者既相对独立，又存在内在的必然联系。\"养\"是\"易\"的前置铺陈，\"易\"则是\"养\"的蜕变升华。而这个内在的变化可表现为两个层面。 以花养颜。艳丽多姿的花瓣仪态万千，雅致娇柔的花蕊魅力无限，自然界里的各色花朵蕴含着植物最美丽的奥秘，以花养颜即是传承梨园名伶百年神奇花颜养肤秘法，通过植物专家多年对各类鲜花的研究中寻找到新的护肤灵感，床在了奢华魅力、以花养颜的新时尚。\r\n</p>\r\n<p>\r\n	以养引易。何以为\"养\"，养可以是滋养、补养，亦可谓是培养、修养。所以易张脸品牌提出的\"养\"不仅仅指外在的面部身体滋养，更倡导在外面养护的同时调节自我，修养内在的心性。\"养\"是个漫长积累的过程，每天静静享受鲜花养肤的时刻，同时抛弃城市的喧嚣，还内心一片清新与宁静，月月年年，外修内养，或许不经意间，你以脱变成更完美的自己。\r\n</p>\r\n<br />','','','','0','1','1385031876','','','images/201311/goods_img/103_G_1385031876670.jpg','images/201311/source_img/103_G_1385031876675.jpg','','','0','http://','','','','','');
/*!40000 ALTER TABLE `yzl_article` ENABLE KEYS */;


--
-- Create Table `yzl_article_cat`
--

DROP TABLE IF EXISTS `yzl_article_cat`;
CREATE TABLE `yzl_article_cat` (
  `cat_id` smallint(5) NOT NULL auto_increment,
  `cat_name` varchar(255) NOT NULL default '',
  `cat_type` tinyint(1) unsigned NOT NULL default '1',
  `keywords` varchar(255) NOT NULL default '',
  `cat_desc` varchar(255) NOT NULL default '',
  `cat_detail` text COMMENT '分类详情描述',
  `sort_order` tinyint(3) unsigned NOT NULL default '50',
  `show_in_nav` tinyint(1) unsigned NOT NULL default '0',
  `parent_id` smallint(5) unsigned NOT NULL default '0',
  `mark` varchar(255) NOT NULL,
  `define_url` varchar(255) NOT NULL,
  `define_theme` varchar(255) NOT NULL,
  PRIMARY KEY  (`cat_id`),
  KEY `cat_type` (`cat_type`),
  KEY `sort_order` (`sort_order`),
  KEY `parent_id` (`parent_id`),
  KEY `mark` (`mark`),
  KEY `define_url` (`define_url`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_article_cat`
--

/*!40000 ALTER TABLE `yzl_article_cat` DISABLE KEYS */;
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('2','品牌故事','1','k 帮助中心','d 帮助中心',NULL,'2','0','0','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('3','易享·花养颜','1','','','','50','0','0','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('8','线上商城','1','','','<ul class=\"webcity_logo\">\r\n            <li class=\"yzl_pic\"><span><img src=\"images/two_code.jpg\" width=\"65\" height=\"65\"></span><a href=\"#\"><img src=\"images/web_linepic1.jpg\" width=\"418\" height=\"238\"></a></li>\r\n            <li><span><img src=\"images/two_code.jpg\" width=\"65\" height=\"65\"></span><a href=\"#\"><img src=\"images/web_linepic2.jpg\" width=\"418\" height=\"238\"></a></li>\r\n        </ul>\r\n\r\n<ul class=\"yzl_about\">\r\n            <li><span><a href=\"#\"><img src=\"images/code.jpg\" width=\"43\" height=\"42\"></a></span>\r\n                <p><a href=\"#\">易张脸官网</a><strong>扫描进入</strong></p>\r\n            </li>\r\n            <li><span><a href=\"#\"><img src=\"images/code.jpg\" width=\"43\" height=\"42\"></a></span>\r\n                <p><a href=\"#\">易张脸官网</a><strong>扫描进入</strong></p>\r\n            </li>\r\n            <li><span><a href=\"#\"><img src=\"images/code.jpg\" width=\"43\" height=\"42\"></a></span>\r\n                <p><a href=\"#\">易张脸官网</a><strong>扫描进入</strong></p>\r\n            </li>\r\n            <li class=\"no_border\"><span><a href=\"#\"><img src=\"images/code.jpg\" width=\"43\" height=\"42\"></a></span>\r\n                <p><a href=\"#\">易张脸官网</a><strong>扫描进入</strong></p>\r\n            </li>\r\n        </ul>','50','0','3','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('31','易张脸','1','','',NULL,'50','0','2','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('32','品牌理念','1','','',NULL,'50','0','2','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('33','品牌愿景','1','','',NULL,'50','0','2','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('34','品牌宣言','1','','',NULL,'50','0','2','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('4','花本养肤','1','','',NULL,'3','0','0','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('41','养颜古方','1','','','<img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131127/20131127095226_77423.jpg\" />\r\n<p>\r\n	&nbsp;\r\n</p>','50','0','4','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('42','花本专家','1','','','<img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131127/20131127095250_26790.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131127/20131127095251_85124.jpg\" />\r\n<p>\r\n	&nbsp;\r\n</p>','50','0','4','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('43','生产基地','1','','',NULL,'50','0','4','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('44','科研实力','1','','','<img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131127/20131127093649_45125.jpg\" />','50','0','4','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('45','生成流程','1','','','<img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131127/20131127094333_44774.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131127/20131127094334_36148.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131127/20131127094335_89869.jpg\" />','50','0','4','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('12','养颜学堂','1','','','','4','0','0','','myjt','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('15','肤质解析堂','1','','','<img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126154120_40052.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126154123_85142.jpg\" /><embed src=\"/upload/flash/20131126/20131126154217_27073.swf\" type=\"application/x-shockwave-flash\" width=\"420\" height=\"410\" quality=\"high\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126154126_37175.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126154128_84121.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126154131_49419.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126154135_47654.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126154138_78613.jpg\" />','50','0','12','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('16','养肤常识堂','1','','','<img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126162714_28662.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126162716_99761.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126162723_30785.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126162725_50545.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126162729_93444.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126162734_11371.jpg\" /><img alt=\"\" src=\"/includes/kindeditor/php/../../../upload/image/20131126/20131126162738_21855.jpg\" />','50','0','12','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('17','花本功效堂','1','','','','10','0','12','','','article_cat_hbgxt.dwt');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('22','线下商城','1','','','<div class=\"webmap_top\">\r\n        	<p>查询地图</p>\r\n            <form>\r\n                <ul class=\"map_con\">\r\n                    <li>省份<select name=\"\"><option>重庆</option><option>北京</option></select></li>\r\n                    <li>城市<select name=\"\"><option>重庆</option><option>北京</option></select></li>\r\n                    <li>分址<select name=\"\"class=\"add\"><option>重庆</option><option>北京</option></select></li>\r\n                </ul>\r\n            </form>\r\n        </div>\r\n        <div class=\"yzl_add\">\r\n        	<P><span>重庆市江北区观音桥重百店</span><span> 地址：重庆市江北区观音桥重百一楼1001</span><span>客服电话：023-66668888</span></P>\r\n        </div>\r\n        <div class=\"map\"><img src=\"images/map.jpg\" width=\"856\" height=\"410\"></div>\r\n','50','0','3','','','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('26','系统帮助','5','','','','1','0','0','','help','');
INSERT INTO `yzl_article_cat` (`cat_id`,`cat_name`,`cat_type`,`keywords`,`cat_desc`,`cat_detail`,`sort_order`,`show_in_nav`,`parent_id`,`mark`,`define_url`,`define_theme`) VALUES ('27','臻享好礼','1','臻享好礼','臻享好礼','','50','0','0','','active','article_topic_cat.dwt');
/*!40000 ALTER TABLE `yzl_article_cat` ENABLE KEYS */;


--
-- Create Table `yzl_article_file`
--

DROP TABLE IF EXISTS `yzl_article_file`;
CREATE TABLE `yzl_article_file` (
  `id` int(4) unsigned NOT NULL auto_increment,
  `article_id` int(8) unsigned NOT NULL,
  `cat_type` int(8) unsigned NOT NULL,
  `file_url` varchar(255) NOT NULL,
  `article_desc` varchar(255) NOT NULL,
  `sort` tinyint(2) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `article_id` (`article_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文章扩展文件';

--
-- Data for Table `yzl_article_file`
--

/*!40000 ALTER TABLE `yzl_article_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_article_file` ENABLE KEYS */;


--
-- Create Table `yzl_article_wallpaper`
--

DROP TABLE IF EXISTS `yzl_article_wallpaper`;
CREATE TABLE `yzl_article_wallpaper` (
  `img_id` mediumint(8) unsigned NOT NULL auto_increment,
  `article_id` mediumint(8) unsigned NOT NULL default '0',
  `img_url` varchar(255) NOT NULL default '',
  `img_desc` varchar(255) NOT NULL default '',
  `thumb_url` varchar(255) NOT NULL default '',
  `img_original` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`img_id`),
  KEY `goods_id` (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_article_wallpaper`
--

/*!40000 ALTER TABLE `yzl_article_wallpaper` DISABLE KEYS */;
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('10','55','images/201310/goods_img/55_P_1381740460895.jpg','','images/201310/thumb_img/55_thumb_P_1381740460707.jpg','images/201310/source_img/55_P_1381740460711.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('11','55','images/201310/goods_img/55_P_1381740460950.jpg','啊发额发额发额发额发额V个','images/201310/thumb_img/55_thumb_P_1381740460950.jpg','images/201310/source_img/55_P_1381740460227.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('12','56','images/201310/goods_img/56_P_1381741534162.jpg','faefaefaefe','images/201310/thumb_img/56_thumb_P_1381741534942.jpg','images/201310/source_img/56_P_1381741534043.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('13','66','images/201310/goods_img/66_P_1381742113416.jpg','','images/201310/thumb_img/66_thumb_P_1381742113140.jpg','images/201310/source_img/66_P_1381742113328.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('8','54','images/201310/goods_img/54_P_1381740403206.jpg','发发额发而发','images/201310/thumb_img/54_thumb_P_1381740403147.jpg','images/201310/source_img/54_P_1381740403506.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('9','54','images/201310/goods_img/54_P_1381740403915.jpg','啊我发额发vba地方','images/201310/thumb_img/54_thumb_P_1381740403212.jpg','images/201310/source_img/54_P_1381740403107.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('14','66','images/201310/goods_img/66_P_1381742113315.jpg','发额法尔范','images/201310/thumb_img/66_thumb_P_1381742113811.jpg','images/201310/source_img/66_P_1381742113411.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('18','66','images/201310/goods_img/66_P_1381745316923.jpg','','images/201310/thumb_img/66_thumb_P_1381745316549.jpg','images/201310/source_img/66_P_1381745316537.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('36','76','images/201310/goods_img/76_P_1382317583081.jpg','阿伟法尔范','images/201310/thumb_img/76_thumb_P_1382317583608.jpg','images/201310/source_img/76_P_1382317583885.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('35','75','images/201310/goods_img/75_P_1382317566328.jpg','发我发而发','images/201310/thumb_img/75_thumb_P_1382317566655.jpg','images/201310/source_img/75_P_1382317566189.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('34','74','images/201310/goods_img/74_P_1382317552425.jpg','菲菲','images/201310/thumb_img/74_thumb_P_1382317552443.jpg','images/201310/source_img/74_P_1382317552017.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('29','69','images/201310/goods_img/69_P_1382317363710.jpg','对方得分','images/201310/thumb_img/69_thumb_P_1382317363321.jpg','images/201310/source_img/69_P_1382317363047.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('31','70','images/201310/goods_img/70_P_1382317502965.jpg','东风东风','images/201310/thumb_img/70_thumb_P_1382317502828.jpg','images/201310/source_img/70_P_1382317502981.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('32','73','images/201310/goods_img/73_P_1382317524985.jpg','','images/201310/thumb_img/73_thumb_P_1382317524377.jpg','images/201310/source_img/73_P_1382317524411.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('33','74','images/201310/goods_img/74_P_1382317538577.jpg','凤飞飞','images/201310/thumb_img/74_thumb_P_1382317538330.jpg','images/201310/source_img/74_P_1382317538796.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('30','71','images/201310/goods_img/71_P_1382317404152.jpg','尺短寸长','images/201310/thumb_img/71_thumb_P_1382317404169.jpg','images/201310/source_img/71_P_1382317404849.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('27','72','images/201310/goods_img/72_P_1382316614635.jpg','是的我说的是','images/201310/thumb_img/72_thumb_P_1382316614117.jpg','images/201310/source_img/72_P_1382316614633.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('28','72','images/201310/goods_img/72_P_1382316614397.jpg','事实上','images/201310/thumb_img/72_thumb_P_1382316614376.jpg','images/201310/source_img/72_P_1382316614210.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('37','77','images/201310/goods_img/77_P_1382317596610.jpg','分啊地方擦速度发擦','images/201310/thumb_img/77_thumb_P_1382317596730.jpg','images/201310/source_img/77_P_1382317596534.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('38','21','images/201310/goods_img/21_P_1382318634914.jpg','cccc','images/201310/thumb_img/21_thumb_P_1382318634643.jpg','images/201310/source_img/21_P_1382318634407.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('39','78','images/201310/goods_img/78_P_1382319935477.jpg','菲菲','images/201310/thumb_img/78_thumb_P_1382319936292.jpg','images/201310/source_img/78_P_1382319935493.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('42','91','images/201311/goods_img/91_P_1385001163509.jpg','','images/201311/thumb_img/91_thumb_P_1385001163510.jpg','images/201311/source_img/91_P_1385001163393.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('43','91','images/201311/goods_img/91_P_1385001168218.jpg','','images/201311/thumb_img/91_thumb_P_1385001168286.jpg','images/201311/source_img/91_P_1385001168766.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('44','91','images/201311/goods_img/91_P_1385001193251.jpg','','images/201311/thumb_img/91_thumb_P_1385001193472.jpg','images/201311/source_img/91_P_1385001193410.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('45','91','images/201311/goods_img/91_P_1385001597363.jpg','','images/201311/thumb_img/91_thumb_P_1385001597027.jpg','images/201311/source_img/91_P_1385001597057.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('46','91','images/201311/goods_img/91_P_1385009649605.jpg','','images/201311/thumb_img/91_thumb_P_1385009649948.jpg','images/201311/source_img/91_P_1385009649165.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('47','92','images/201311/goods_img/92_P_1385009734489.jpg','','images/201311/thumb_img/92_thumb_P_1385009734102.jpg','images/201311/source_img/92_P_1385009734696.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('48','92','images/201311/goods_img/92_P_1385009795116.jpg','','images/201311/thumb_img/92_thumb_P_1385009795101.jpg','images/201311/source_img/92_P_1385009795857.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('49','92','images/201311/goods_img/92_P_1385009864996.jpg','','images/201311/thumb_img/92_thumb_P_1385009864548.jpg','images/201311/source_img/92_P_1385009864387.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('50','95','images/201311/goods_img/95_P_1385031818684.jpg','','images/201311/thumb_img/95_thumb_P_1385031818652.jpg','images/201311/source_img/95_P_1385031818318.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('51','96','images/201311/goods_img/96_P_1385031829482.jpg','','images/201311/thumb_img/96_thumb_P_1385031829150.jpg','images/201311/source_img/96_P_1385031829284.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('52','97','images/201311/goods_img/97_P_1385031840287.jpg','','images/201311/thumb_img/97_thumb_P_1385031840515.jpg','images/201311/source_img/97_P_1385031840960.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('53','98','images/201311/goods_img/98_P_1385031848350.jpg','','images/201311/thumb_img/98_thumb_P_1385031848890.jpg','images/201311/source_img/98_P_1385031848981.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('54','99','images/201311/goods_img/99_P_1385031854857.jpg','','images/201311/thumb_img/99_thumb_P_1385031854378.jpg','images/201311/source_img/99_P_1385031854164.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('55','100','images/201311/goods_img/100_P_1385031860158.jpg','','images/201311/thumb_img/100_thumb_P_1385031860968.jpg','images/201311/source_img/100_P_1385031860728.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('56','101','images/201311/goods_img/101_P_1385031865030.jpg','','images/201311/thumb_img/101_thumb_P_1385031865652.jpg','images/201311/source_img/101_P_1385031865433.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('57','102','images/201311/goods_img/102_P_1385031871818.jpg','','images/201311/thumb_img/102_thumb_P_1385031871368.jpg','images/201311/source_img/102_P_1385031871372.jpg');
INSERT INTO `yzl_article_wallpaper` (`img_id`,`article_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('58','103','images/201311/goods_img/103_P_1385031876884.jpg','','images/201311/thumb_img/103_thumb_P_1385031876693.jpg','images/201311/source_img/103_P_1385031876060.jpg');
/*!40000 ALTER TABLE `yzl_article_wallpaper` ENABLE KEYS */;


--
-- Create Table `yzl_attribute`
--

DROP TABLE IF EXISTS `yzl_attribute`;
CREATE TABLE `yzl_attribute` (
  `attr_id` smallint(5) unsigned NOT NULL auto_increment,
  `cat_id` smallint(5) unsigned NOT NULL default '0',
  `attr_name` varchar(60) NOT NULL default '',
  `attr_input_type` tinyint(1) unsigned NOT NULL default '1',
  `attr_type` tinyint(1) unsigned NOT NULL default '1',
  `attr_values` text NOT NULL,
  `attr_index` tinyint(1) unsigned NOT NULL default '0',
  `sort_order` tinyint(3) unsigned NOT NULL default '0',
  `is_linked` tinyint(1) unsigned NOT NULL default '0',
  `attr_group` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`attr_id`),
  KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=213 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_attribute`
--

/*!40000 ALTER TABLE `yzl_attribute` DISABLE KEYS */;
INSERT INTO `yzl_attribute` (`attr_id`,`cat_id`,`attr_name`,`attr_input_type`,`attr_type`,`attr_values`,`attr_index`,`sort_order`,`is_linked`,`attr_group`) VALUES ('165','8','产地','0','0','','0','10','0','0');
INSERT INTO `yzl_attribute` (`attr_id`,`cat_id`,`attr_name`,`attr_input_type`,`attr_type`,`attr_values`,`attr_index`,`sort_order`,`is_linked`,`attr_group`) VALUES ('166','8','产品规格/容量','0','0','','0','10','0','0');
INSERT INTO `yzl_attribute` (`attr_id`,`cat_id`,`attr_name`,`attr_input_type`,`attr_type`,`attr_values`,`attr_index`,`sort_order`,`is_linked`,`attr_group`) VALUES ('167','8','养肤成分','1','2','樱花提取物\r\n当归提取物\r\n光甘草啶\r\n太阳花籽油\r\n仙人掌糖醛\r\n樱花提取物\r\n当归提取物\r\n光甘草啶\r\n太阳花籽油','0','50','0','0');
INSERT INTO `yzl_attribute` (`attr_id`,`cat_id`,`attr_name`,`attr_input_type`,`attr_type`,`attr_values`,`attr_index`,`sort_order`,`is_linked`,`attr_group`) VALUES ('168','8','所属类别','1','0','彩妆\r\n化妆工具\r\n护肤品\r\n香水','0','10','0','0');
INSERT INTO `yzl_attribute` (`attr_id`,`cat_id`,`attr_name`,`attr_input_type`,`attr_type`,`attr_values`,`attr_index`,`sort_order`,`is_linked`,`attr_group`) VALUES ('169','8','使用部位','0','0','','0','10','0','0');
INSERT INTO `yzl_attribute` (`attr_id`,`cat_id`,`attr_name`,`attr_input_type`,`attr_type`,`attr_values`,`attr_index`,`sort_order`,`is_linked`,`attr_group`) VALUES ('170','8','适合肤质','1','0','油性\r\n中性\r\n干性','0','10','0','0');
INSERT INTO `yzl_attribute` (`attr_id`,`cat_id`,`attr_name`,`attr_input_type`,`attr_type`,`attr_values`,`attr_index`,`sort_order`,`is_linked`,`attr_group`) VALUES ('171','8','适用人群','1','0','女性\r\n男性','0','10','0','0');
INSERT INTO `yzl_attribute` (`attr_id`,`cat_id`,`attr_name`,`attr_input_type`,`attr_type`,`attr_values`,`attr_index`,`sort_order`,`is_linked`,`attr_group`) VALUES ('212','8','品牌系列','1','0','玫瑰莹润焕白\r\n系列2\r\n系列3\r\n系列4','0','10','0','0');
INSERT INTO `yzl_attribute` (`attr_id`,`cat_id`,`attr_name`,`attr_input_type`,`attr_type`,`attr_values`,`attr_index`,`sort_order`,`is_linked`,`attr_group`) VALUES ('211','8','肌肤需求','1','0','aaaaaaaaaaaaa\r\naaaaaaaaaaaaab\r\naaaaaaaaaaaaac\r\naaaaaaaaaaaaad','1','10','0','0');
/*!40000 ALTER TABLE `yzl_attribute` ENABLE KEYS */;


--
-- Create Table `yzl_auction_log`
--

DROP TABLE IF EXISTS `yzl_auction_log`;
CREATE TABLE `yzl_auction_log` (
  `log_id` mediumint(8) unsigned NOT NULL auto_increment,
  `act_id` mediumint(8) unsigned NOT NULL,
  `bid_user` mediumint(8) unsigned NOT NULL,
  `bid_price` decimal(10,2) unsigned NOT NULL,
  `bid_time` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`log_id`),
  KEY `act_id` (`act_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_auction_log`
--

/*!40000 ALTER TABLE `yzl_auction_log` DISABLE KEYS */;
INSERT INTO `yzl_auction_log` (`log_id`,`act_id`,`bid_user`,`bid_price`,`bid_time`) VALUES ('1','4','1','170.00','1242144083');
/*!40000 ALTER TABLE `yzl_auction_log` ENABLE KEYS */;


--
-- Create Table `yzl_auto_manage`
--

DROP TABLE IF EXISTS `yzl_auto_manage`;
CREATE TABLE `yzl_auto_manage` (
  `item_id` mediumint(8) NOT NULL,
  `type` varchar(10) NOT NULL,
  `starttime` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  PRIMARY KEY  (`item_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_auto_manage`
--

/*!40000 ALTER TABLE `yzl_auto_manage` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_auto_manage` ENABLE KEYS */;


--
-- Create Table `yzl_back_goods`
--

DROP TABLE IF EXISTS `yzl_back_goods`;
CREATE TABLE `yzl_back_goods` (
  `rec_id` mediumint(8) unsigned NOT NULL auto_increment,
  `back_id` mediumint(8) unsigned default '0',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `product_id` mediumint(8) unsigned NOT NULL default '0',
  `product_sn` varchar(60) default NULL,
  `goods_name` varchar(120) default NULL,
  `brand_name` varchar(60) default NULL,
  `goods_sn` varchar(60) default NULL,
  `is_real` tinyint(1) unsigned default '0',
  `send_number` smallint(5) unsigned default '0',
  `goods_attr` text,
  PRIMARY KEY  (`rec_id`),
  KEY `back_id` (`back_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_back_goods`
--

/*!40000 ALTER TABLE `yzl_back_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_back_goods` ENABLE KEYS */;


--
-- Create Table `yzl_back_order`
--

DROP TABLE IF EXISTS `yzl_back_order`;
CREATE TABLE `yzl_back_order` (
  `back_id` mediumint(8) unsigned NOT NULL auto_increment,
  `delivery_sn` varchar(20) NOT NULL,
  `order_sn` varchar(20) NOT NULL,
  `order_id` mediumint(8) unsigned NOT NULL default '0',
  `invoice_no` varchar(50) default NULL,
  `add_time` int(10) unsigned default '0',
  `shipping_id` tinyint(3) unsigned default '0',
  `shipping_name` varchar(120) default NULL,
  `user_id` mediumint(8) unsigned default '0',
  `action_user` varchar(30) default NULL,
  `consignee` varchar(60) default NULL,
  `address` varchar(250) default NULL,
  `country` smallint(5) unsigned default '0',
  `province` smallint(5) unsigned default '0',
  `city` smallint(5) unsigned default '0',
  `district` smallint(5) unsigned default '0',
  `sign_building` varchar(120) default NULL,
  `email` varchar(60) default NULL,
  `zipcode` varchar(60) default NULL,
  `tel` varchar(60) default NULL,
  `mobile` varchar(60) default NULL,
  `best_time` varchar(120) default NULL,
  `postscript` varchar(255) default NULL,
  `how_oos` varchar(120) default NULL,
  `insure_fee` decimal(10,2) unsigned default '0.00',
  `shipping_fee` decimal(10,2) unsigned default '0.00',
  `update_time` int(10) unsigned default '0',
  `suppliers_id` smallint(5) default '0',
  `status` tinyint(1) unsigned NOT NULL default '0',
  `return_time` int(10) unsigned default '0',
  `agency_id` smallint(5) unsigned default '0',
  PRIMARY KEY  (`back_id`),
  KEY `user_id` (`user_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_back_order`
--

/*!40000 ALTER TABLE `yzl_back_order` DISABLE KEYS */;
INSERT INTO `yzl_back_order` (`back_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`return_time`,`agency_id`) VALUES ('1','20090615054961769','2009061585887','15','2009061585884','1245044533','3','','1','admin','刘先生','海兴大厦','1','2','52','502','','ecshop@ecshop.com','','010-25851234','13986765412','','','等待所有商品备齐后再发','0.00','10.00','1245044964','2','0','1245045515','0');
INSERT INTO `yzl_back_order` (`back_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`return_time`,`agency_id`) VALUES ('2','20090615055104671','2009061585887','15','20090615','1245044533','3','','1','admin','刘先生','海兴大厦','1','2','52','502','','ecshop@ecshop.com','','010-25851234','13986765412','','','等待所有商品备齐后再发','0.00','10.00','1245045061','1','0','1245045515','0');
INSERT INTO `yzl_back_order` (`back_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`return_time`,`agency_id`) VALUES ('3','20090615055780744','2009061585887','15','123232','1245044533','3','','1','admin','刘先生','海兴大厦','1','2','52','502','','ecshop@ecshop.com','','010-25851234','13986765412','','','等待所有商品备齐后再发','0.00','10.00','1245045443','0','0','1245045515','0');
INSERT INTO `yzl_back_order` (`back_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`return_time`,`agency_id`) VALUES ('4','20090615064331475','2009061503335','17','00906150333512','1245047978','3','','1','admin','刘先生','海兴大厦','1','2','52','502','','ecshop@ecshop.com','','010-25851234','13986765412','','','等待所有商品备齐后再发','0.00','10.00','1245048189','0','0','1245048212','0');
/*!40000 ALTER TABLE `yzl_back_order` ENABLE KEYS */;


--
-- Create Table `yzl_bonus_type`
--

DROP TABLE IF EXISTS `yzl_bonus_type`;
CREATE TABLE `yzl_bonus_type` (
  `type_id` smallint(5) unsigned NOT NULL auto_increment,
  `type_name` varchar(60) NOT NULL default '',
  `type_money` decimal(10,2) NOT NULL default '0.00',
  `send_type` tinyint(3) unsigned NOT NULL default '0',
  `min_amount` decimal(10,2) unsigned NOT NULL default '0.00',
  `max_amount` decimal(10,2) unsigned NOT NULL default '0.00',
  `send_start_date` int(11) NOT NULL default '0',
  `send_end_date` int(11) NOT NULL default '0',
  `use_start_date` int(11) NOT NULL default '0',
  `use_end_date` int(11) NOT NULL default '0',
  `min_goods_amount` decimal(10,2) unsigned NOT NULL default '0.00',
  PRIMARY KEY  (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_bonus_type`
--

/*!40000 ALTER TABLE `yzl_bonus_type` DISABLE KEYS */;
INSERT INTO `yzl_bonus_type` (`type_id`,`type_name`,`type_money`,`send_type`,`min_amount`,`max_amount`,`send_start_date`,`send_end_date`,`use_start_date`,`use_end_date`,`min_goods_amount`) VALUES ('1','用户红包','2.00','0','0.00','0.00','1242057600','1244736000','1242057600','1250006400','500.00');
INSERT INTO `yzl_bonus_type` (`type_id`,`type_name`,`type_money`,`send_type`,`min_amount`,`max_amount`,`send_start_date`,`send_end_date`,`use_start_date`,`use_end_date`,`min_goods_amount`) VALUES ('2','商品红包','10.00','1','0.00','0.00','1241971200','1250352000','1242057600','1250006400','500.00');
INSERT INTO `yzl_bonus_type` (`type_id`,`type_name`,`type_money`,`send_type`,`min_amount`,`max_amount`,`send_start_date`,`send_end_date`,`use_start_date`,`use_end_date`,`min_goods_amount`) VALUES ('3','订单红包','20.00','2','1500.00','0.00','1242057600','1309363200','1242057600','1257955200','800.00');
INSERT INTO `yzl_bonus_type` (`type_id`,`type_name`,`type_money`,`send_type`,`min_amount`,`max_amount`,`send_start_date`,`send_end_date`,`use_start_date`,`use_end_date`,`min_goods_amount`) VALUES ('4','线下红包','5.00','3','0.00','0.00','1242057600','1244736000','1242057600','1255449600','360.00');
/*!40000 ALTER TABLE `yzl_bonus_type` ENABLE KEYS */;


--
-- Create Table `yzl_booking_goods`
--

DROP TABLE IF EXISTS `yzl_booking_goods`;
CREATE TABLE `yzl_booking_goods` (
  `rec_id` mediumint(8) unsigned NOT NULL auto_increment,
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `email` varchar(60) NOT NULL default '',
  `link_man` varchar(60) NOT NULL default '',
  `tel` varchar(60) NOT NULL default '',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_desc` varchar(255) NOT NULL default '',
  `goods_number` smallint(5) unsigned NOT NULL default '0',
  `booking_time` int(10) unsigned NOT NULL default '0',
  `is_dispose` tinyint(1) unsigned NOT NULL default '0',
  `dispose_user` varchar(30) NOT NULL default '',
  `dispose_time` int(10) unsigned NOT NULL default '0',
  `dispose_note` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`rec_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_booking_goods`
--

/*!40000 ALTER TABLE `yzl_booking_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_booking_goods` ENABLE KEYS */;


--
-- Create Table `yzl_brand`
--

DROP TABLE IF EXISTS `yzl_brand`;
CREATE TABLE `yzl_brand` (
  `brand_id` smallint(5) unsigned NOT NULL auto_increment,
  `brand_name` varchar(60) NOT NULL default '',
  `brand_logo` varchar(80) NOT NULL default '',
  `brand_desc` text NOT NULL,
  `site_url` varchar(255) NOT NULL default '',
  `sort_order` tinyint(3) unsigned NOT NULL default '50',
  `is_show` tinyint(1) unsigned NOT NULL default '1',
  `define_url` varchar(255) NOT NULL,
  PRIMARY KEY  (`brand_id`),
  KEY `is_show` (`is_show`),
  KEY `define_url` (`define_url`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_brand`
--

/*!40000 ALTER TABLE `yzl_brand` DISABLE KEYS */;
INSERT INTO `yzl_brand` (`brand_id`,`brand_name`,`brand_logo`,`brand_desc`,`site_url`,`sort_order`,`is_show`,`define_url`) VALUES ('12','易张脸','','','','50','1','');
/*!40000 ALTER TABLE `yzl_brand` ENABLE KEYS */;


--
-- Create Table `yzl_card`
--

DROP TABLE IF EXISTS `yzl_card`;
CREATE TABLE `yzl_card` (
  `card_id` tinyint(3) unsigned NOT NULL auto_increment,
  `card_name` varchar(120) NOT NULL default '',
  `card_img` varchar(255) NOT NULL default '',
  `card_fee` decimal(6,2) unsigned NOT NULL default '0.00',
  `free_money` decimal(6,2) unsigned NOT NULL default '0.00',
  `card_desc` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`card_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_card`
--

/*!40000 ALTER TABLE `yzl_card` DISABLE KEYS */;
INSERT INTO `yzl_card` (`card_id`,`card_name`,`card_img`,`card_fee`,`free_money`,`card_desc`) VALUES ('1','祝福贺卡','1242108754847457261.jpg','5.00','1000.00','把您的祝福带给您身边的人');
/*!40000 ALTER TABLE `yzl_card` ENABLE KEYS */;


--
-- Create Table `yzl_cart`
--

DROP TABLE IF EXISTS `yzl_cart`;
CREATE TABLE `yzl_cart` (
  `rec_id` mediumint(8) unsigned NOT NULL auto_increment,
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `session_id` char(32) character set utf8 collate utf8_bin NOT NULL default '',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_sn` varchar(60) NOT NULL default '',
  `product_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_name` varchar(120) NOT NULL default '',
  `market_price` decimal(10,2) unsigned NOT NULL default '0.00',
  `goods_price` decimal(10,2) NOT NULL default '0.00',
  `goods_number` smallint(5) unsigned NOT NULL default '0',
  `goods_attr` text NOT NULL,
  `is_real` tinyint(1) unsigned NOT NULL default '0',
  `extension_code` varchar(30) NOT NULL default '',
  `parent_id` mediumint(8) unsigned NOT NULL default '0',
  `rec_type` tinyint(1) unsigned NOT NULL default '0',
  `is_gift` smallint(5) unsigned NOT NULL default '0',
  `is_shipping` tinyint(1) unsigned NOT NULL default '0',
  `can_handsel` tinyint(3) unsigned NOT NULL default '0',
  `goods_attr_id` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`rec_id`),
  KEY `session_id` (`session_id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_cart`
--

/*!40000 ALTER TABLE `yzl_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_cart` ENABLE KEYS */;


--
-- Create Table `yzl_cat_recommend`
--

DROP TABLE IF EXISTS `yzl_cat_recommend`;
CREATE TABLE `yzl_cat_recommend` (
  `cat_id` smallint(5) NOT NULL,
  `recommend_type` tinyint(1) NOT NULL,
  PRIMARY KEY  (`cat_id`,`recommend_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_cat_recommend`
--

/*!40000 ALTER TABLE `yzl_cat_recommend` DISABLE KEYS */;
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('3','1');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('3','2');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('3','3');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('5','1');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('5','2');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('5','3');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('12','1');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('12','2');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('12','3');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('13','3');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('14','2');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('14','3');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('15','1');
INSERT INTO `yzl_cat_recommend` (`cat_id`,`recommend_type`) VALUES ('15','2');
/*!40000 ALTER TABLE `yzl_cat_recommend` ENABLE KEYS */;


--
-- Create Table `yzl_category`
--

DROP TABLE IF EXISTS `yzl_category`;
CREATE TABLE `yzl_category` (
  `cat_id` smallint(5) unsigned NOT NULL auto_increment,
  `cat_name` varchar(90) NOT NULL default '',
  `keywords` varchar(255) NOT NULL default '',
  `cat_desc` varchar(255) NOT NULL default '',
  `parent_id` smallint(5) unsigned NOT NULL default '0',
  `sort_order` tinyint(1) unsigned NOT NULL default '50',
  `template_file` varchar(50) NOT NULL default '',
  `measure_unit` varchar(15) NOT NULL default '',
  `show_in_nav` tinyint(1) NOT NULL default '0',
  `style` varchar(150) NOT NULL,
  `is_show` tinyint(1) unsigned NOT NULL default '1',
  `grade` tinyint(4) NOT NULL default '0',
  `filter_attr` varchar(255) NOT NULL default '0',
  `define_url` varchar(255) NOT NULL,
  PRIMARY KEY  (`cat_id`),
  KEY `parent_id` (`parent_id`),
  KEY `define_url` (`define_url`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_category`
--

/*!40000 ALTER TABLE `yzl_category` DISABLE KEYS */;
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('1','产品类型','','','0','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('3','品牌系列','','','0','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('4','肌肤需求','','','0','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('16','养肤面膜贴','k 养肤面膜贴','d 养肤面膜贴','1','20','','个','0','','1','0','','yfmmt');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('17','养肤洁面乳','养肤洁面乳','养肤洁面乳','1','10','','','0','','1','0','211,212,171,165,166,167,168,170','yfjmr');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('18','养肤水','养肤水','养肤水','1','30','','','0','','1','0','0','yfs');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('19','精华液','精华液','精华液','1','40','','','0','','1','0','0','jhy');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('20','养肤面霜','养肤面霜','养肤面霜','1','50','','','0','','1','0','0','yfms');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('21','面膜泥冻膜','面膜泥冻膜','面膜泥冻膜','1','60','','','0','','1','0','0','mmndm');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('22','眼部护理','眼部护理','眼部护理','1','70','','','0','','1','0','0','ybhl');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('31','玫瑰莹润焕白','','','3','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('32','玫瑰莹润焕白2','','','3','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('33','玫瑰莹润焕白3','','','3','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('34','玫瑰莹润焕白4','','','3','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('41','色斑、肤色不均','','','4','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('42','肌肤黯沉、疲倦','','','4','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('43','干燥、粗糙','','','4','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('44','毛孔粗大、脫屑','','','4','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('45','细纹/幼纹','','','4','50','','','0','','1','0','0','');
INSERT INTO `yzl_category` (`cat_id`,`cat_name`,`keywords`,`cat_desc`,`parent_id`,`sort_order`,`template_file`,`measure_unit`,`show_in_nav`,`style`,`is_show`,`grade`,`filter_attr`,`define_url`) VALUES ('46','松弛、皱纹','','','4','50','','','0','','1','0','0','');
/*!40000 ALTER TABLE `yzl_category` ENABLE KEYS */;


--
-- Create Table `yzl_collect_goods`
--

DROP TABLE IF EXISTS `yzl_collect_goods`;
CREATE TABLE `yzl_collect_goods` (
  `rec_id` mediumint(8) unsigned NOT NULL auto_increment,
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `add_time` int(11) unsigned NOT NULL default '0',
  `is_attention` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`rec_id`),
  KEY `user_id` (`user_id`),
  KEY `goods_id` (`goods_id`),
  KEY `is_attention` (`is_attention`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_collect_goods`
--

/*!40000 ALTER TABLE `yzl_collect_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_collect_goods` ENABLE KEYS */;


--
-- Create Table `yzl_comment`
--

DROP TABLE IF EXISTS `yzl_comment`;
CREATE TABLE `yzl_comment` (
  `comment_id` int(10) unsigned NOT NULL auto_increment,
  `comment_type` tinyint(3) unsigned NOT NULL default '0',
  `id_value` mediumint(8) unsigned NOT NULL default '0',
  `email` varchar(60) NOT NULL default '',
  `user_name` varchar(60) NOT NULL default '',
  `content` text NOT NULL,
  `comment_rank` tinyint(1) unsigned NOT NULL default '0',
  `add_time` int(10) unsigned NOT NULL default '0',
  `ip_address` varchar(15) NOT NULL default '',
  `status` tinyint(3) unsigned NOT NULL default '0',
  `parent_id` int(10) unsigned NOT NULL default '0',
  `user_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`comment_id`),
  KEY `parent_id` (`parent_id`),
  KEY `id_value` (`id_value`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_comment`
--

/*!40000 ALTER TABLE `yzl_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_comment` ENABLE KEYS */;


--
-- Create Table `yzl_crons`
--

DROP TABLE IF EXISTS `yzl_crons`;
CREATE TABLE `yzl_crons` (
  `cron_id` tinyint(3) unsigned NOT NULL auto_increment,
  `cron_code` varchar(20) NOT NULL,
  `cron_name` varchar(120) NOT NULL,
  `cron_desc` text,
  `cron_order` tinyint(3) unsigned NOT NULL default '0',
  `cron_config` text NOT NULL,
  `thistime` int(10) NOT NULL default '0',
  `nextime` int(10) NOT NULL,
  `day` tinyint(2) NOT NULL,
  `week` varchar(1) NOT NULL,
  `hour` varchar(2) NOT NULL,
  `minute` varchar(255) NOT NULL,
  `enable` tinyint(1) NOT NULL default '1',
  `run_once` tinyint(1) NOT NULL default '0',
  `allow_ip` varchar(100) NOT NULL default '',
  `alow_files` varchar(255) NOT NULL,
  PRIMARY KEY  (`cron_id`),
  KEY `nextime` (`nextime`),
  KEY `enable` (`enable`),
  KEY `cron_code` (`cron_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_crons`
--

/*!40000 ALTER TABLE `yzl_crons` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_crons` ENABLE KEYS */;


--
-- Create Table `yzl_delivery_goods`
--

DROP TABLE IF EXISTS `yzl_delivery_goods`;
CREATE TABLE `yzl_delivery_goods` (
  `rec_id` mediumint(8) unsigned NOT NULL auto_increment,
  `delivery_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `product_id` mediumint(8) unsigned default '0',
  `product_sn` varchar(60) default NULL,
  `goods_name` varchar(120) default NULL,
  `brand_name` varchar(60) default NULL,
  `goods_sn` varchar(60) default NULL,
  `is_real` tinyint(1) unsigned default '0',
  `extension_code` varchar(30) default NULL,
  `parent_id` mediumint(8) unsigned default '0',
  `send_number` smallint(5) unsigned default '0',
  `goods_attr` text,
  PRIMARY KEY  (`rec_id`),
  KEY `delivery_id` (`delivery_id`,`goods_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_delivery_goods`
--

/*!40000 ALTER TABLE `yzl_delivery_goods` DISABLE KEYS */;
INSERT INTO `yzl_delivery_goods` (`rec_id`,`delivery_id`,`goods_id`,`product_id`,`product_sn`,`goods_name`,`brand_name`,`goods_sn`,`is_real`,`extension_code`,`parent_id`,`send_number`,`goods_attr`) VALUES ('1','1','13','0',NULL,'诺基亚5320 XpressMusic','诺基亚','ECS000013','1','','0','3',NULL);
INSERT INTO `yzl_delivery_goods` (`rec_id`,`delivery_id`,`goods_id`,`product_id`,`product_sn`,`goods_name`,`brand_name`,`goods_sn`,`is_real`,`extension_code`,`parent_id`,`send_number`,`goods_attr`) VALUES ('2','1','14','0',NULL,'诺基亚5800XM','诺基亚','ECS000014','1','','0','1',NULL);
INSERT INTO `yzl_delivery_goods` (`rec_id`,`delivery_id`,`goods_id`,`product_id`,`product_sn`,`goods_name`,`brand_name`,`goods_sn`,`is_real`,`extension_code`,`parent_id`,`send_number`,`goods_attr`) VALUES ('3','2','24','0',NULL,'P806','联想','ECS000024','1','','0','3',NULL);
INSERT INTO `yzl_delivery_goods` (`rec_id`,`delivery_id`,`goods_id`,`product_id`,`product_sn`,`goods_name`,`brand_name`,`goods_sn`,`is_real`,`extension_code`,`parent_id`,`send_number`,`goods_attr`) VALUES ('4','2','9','0',NULL,'诺基亚E66','诺基亚','ECS000009','1','','0','1',NULL);
INSERT INTO `yzl_delivery_goods` (`rec_id`,`delivery_id`,`goods_id`,`product_id`,`product_sn`,`goods_name`,`brand_name`,`goods_sn`,`is_real`,`extension_code`,`parent_id`,`send_number`,`goods_attr`) VALUES ('5','3','24','0',NULL,'P806','联想','ECS000024','1','','0','1',NULL);
INSERT INTO `yzl_delivery_goods` (`rec_id`,`delivery_id`,`goods_id`,`product_id`,`product_sn`,`goods_name`,`brand_name`,`goods_sn`,`is_real`,`extension_code`,`parent_id`,`send_number`,`goods_attr`) VALUES ('6','3','8','0',NULL,'飞利浦9@9v','飞利浦','ECS000008','1','','0','3',NULL);
INSERT INTO `yzl_delivery_goods` (`rec_id`,`delivery_id`,`goods_id`,`product_id`,`product_sn`,`goods_name`,`brand_name`,`goods_sn`,`is_real`,`extension_code`,`parent_id`,`send_number`,`goods_attr`) VALUES ('7','4','12','0',NULL,'摩托罗拉A810','摩托罗拉','ECS000012','1','','0','2',NULL);
INSERT INTO `yzl_delivery_goods` (`rec_id`,`delivery_id`,`goods_id`,`product_id`,`product_sn`,`goods_name`,`brand_name`,`goods_sn`,`is_real`,`extension_code`,`parent_id`,`send_number`,`goods_attr`) VALUES ('8','5','24','0',NULL,'P806','联想','ECS000024','1','','0','1',NULL);
INSERT INTO `yzl_delivery_goods` (`rec_id`,`delivery_id`,`goods_id`,`product_id`,`product_sn`,`goods_name`,`brand_name`,`goods_sn`,`is_real`,`extension_code`,`parent_id`,`send_number`,`goods_attr`) VALUES ('9','6','23','0','','诺基亚N96','诺基亚','ECS000023','1',NULL,'0','1','附加配件: 原装电池 [+100]');
/*!40000 ALTER TABLE `yzl_delivery_goods` ENABLE KEYS */;


--
-- Create Table `yzl_delivery_order`
--

DROP TABLE IF EXISTS `yzl_delivery_order`;
CREATE TABLE `yzl_delivery_order` (
  `delivery_id` mediumint(8) unsigned NOT NULL auto_increment,
  `delivery_sn` varchar(20) NOT NULL,
  `order_sn` varchar(20) NOT NULL,
  `order_id` mediumint(8) unsigned NOT NULL default '0',
  `invoice_no` varchar(50) default NULL,
  `add_time` int(10) unsigned default '0',
  `shipping_id` tinyint(3) unsigned default '0',
  `shipping_name` varchar(120) default NULL,
  `user_id` mediumint(8) unsigned default '0',
  `action_user` varchar(30) default NULL,
  `consignee` varchar(60) default NULL,
  `address` varchar(250) default NULL,
  `country` smallint(5) unsigned default '0',
  `province` smallint(5) unsigned default '0',
  `city` smallint(5) unsigned default '0',
  `district` smallint(5) unsigned default '0',
  `sign_building` varchar(120) default NULL,
  `email` varchar(60) default NULL,
  `zipcode` varchar(60) default NULL,
  `tel` varchar(60) default NULL,
  `mobile` varchar(60) default NULL,
  `best_time` varchar(120) default NULL,
  `postscript` varchar(255) default NULL,
  `how_oos` varchar(120) default NULL,
  `insure_fee` decimal(10,2) unsigned default '0.00',
  `shipping_fee` decimal(10,2) unsigned default '0.00',
  `update_time` int(10) unsigned default '0',
  `suppliers_id` smallint(5) default '0',
  `status` tinyint(1) unsigned NOT NULL default '0',
  `agency_id` smallint(5) unsigned default '0',
  PRIMARY KEY  (`delivery_id`),
  KEY `user_id` (`user_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_delivery_order`
--

/*!40000 ALTER TABLE `yzl_delivery_order` DISABLE KEYS */;
INSERT INTO `yzl_delivery_order` (`delivery_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`agency_id`) VALUES ('1','20090615054961769','2009061585887','15','2009061585884','1245044533','3','城际快递','1','admin','刘先生','海兴大厦','1','2','52','502','','ecshop@ecshop.com','','010-25851234','13986765412','','','等待所有商品备齐后再发','0.00','10.00','1245044964','2','1','0');
INSERT INTO `yzl_delivery_order` (`delivery_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`agency_id`) VALUES ('2','20090615055104671','2009061585887','15','20090615','1245044533','3','城际快递','1','admin','刘先生','海兴大厦','1','2','52','502','','ecshop@ecshop.com','','010-25851234','13986765412','','','等待所有商品备齐后再发','0.00','10.00','1245045061','1','1','0');
INSERT INTO `yzl_delivery_order` (`delivery_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`agency_id`) VALUES ('3','20090615055780744','2009061585887','15','123232','1245044533','3','城际快递','1','admin','刘先生','海兴大厦','1','2','52','502','','ecshop@ecshop.com','','010-25851234','13986765412','','','等待所有商品备齐后再发','0.00','10.00','1245045443','0','1','0');
INSERT INTO `yzl_delivery_order` (`delivery_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`agency_id`) VALUES ('4','20090615060281017','2009061525429','16','2009061525121','1245045672','3','城际快递','1','admin','刘先生','海兴大厦','1','2','52','502','','ecshop@ecshop.com','','010-25851234','13986765412','','','等待所有商品备齐后再发','0.00','10.00','1245045723','2','0','0');
INSERT INTO `yzl_delivery_order` (`delivery_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`agency_id`) VALUES ('5','20090615064331475','2009061503335','17','00906150333512','1245047978','3','城际快递','1','admin','刘先生','海兴大厦','1','2','52','502','','ecshop@ecshop.com','','010-25851234','13986765412','','','等待所有商品备齐后再发','0.00','10.00','1245048189','0','1','0');
INSERT INTO `yzl_delivery_order` (`delivery_id`,`delivery_sn`,`order_sn`,`order_id`,`invoice_no`,`add_time`,`shipping_id`,`shipping_name`,`user_id`,`action_user`,`consignee`,`address`,`country`,`province`,`city`,`district`,`sign_building`,`email`,`zipcode`,`tel`,`mobile`,`best_time`,`postscript`,`how_oos`,`insure_fee`,`shipping_fee`,`update_time`,`suppliers_id`,`status`,`agency_id`) VALUES ('6','20131009153928293','2009051264945','11','','1242144250','3','城际快递','0','admin','林小姐','中关村海兴大厦','1','2','52','500','','linzi@116.com','','135474510','','','','','0.00','10.00','1381275579','2','0','0');
/*!40000 ALTER TABLE `yzl_delivery_order` ENABLE KEYS */;


--
-- Create Table `yzl_email_list`
--

DROP TABLE IF EXISTS `yzl_email_list`;
CREATE TABLE `yzl_email_list` (
  `id` mediumint(8) NOT NULL auto_increment,
  `email` varchar(60) NOT NULL,
  `stat` tinyint(1) NOT NULL default '0',
  `hash` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_email_list`
--

/*!40000 ALTER TABLE `yzl_email_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_email_list` ENABLE KEYS */;


--
-- Create Table `yzl_email_sendlist`
--

DROP TABLE IF EXISTS `yzl_email_sendlist`;
CREATE TABLE `yzl_email_sendlist` (
  `id` mediumint(8) NOT NULL auto_increment,
  `email` varchar(100) NOT NULL,
  `template_id` mediumint(8) NOT NULL,
  `email_content` text NOT NULL,
  `error` tinyint(1) NOT NULL default '0',
  `pri` tinyint(10) NOT NULL,
  `last_send` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_email_sendlist`
--

/*!40000 ALTER TABLE `yzl_email_sendlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_email_sendlist` ENABLE KEYS */;


--
-- Create Table `yzl_error_log`
--

DROP TABLE IF EXISTS `yzl_error_log`;
CREATE TABLE `yzl_error_log` (
  `id` int(10) NOT NULL auto_increment,
  `info` varchar(255) NOT NULL,
  `file` varchar(100) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_error_log`
--

/*!40000 ALTER TABLE `yzl_error_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_error_log` ENABLE KEYS */;


--
-- Create Table `yzl_exchange_goods`
--

DROP TABLE IF EXISTS `yzl_exchange_goods`;
CREATE TABLE `yzl_exchange_goods` (
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `exchange_integral` int(10) unsigned NOT NULL default '0',
  `is_exchange` tinyint(1) unsigned NOT NULL default '0',
  `is_hot` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`goods_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_exchange_goods`
--

/*!40000 ALTER TABLE `yzl_exchange_goods` DISABLE KEYS */;
INSERT INTO `yzl_exchange_goods` (`goods_id`,`exchange_integral`,`is_exchange`,`is_hot`) VALUES ('24','17000','1','0');
INSERT INTO `yzl_exchange_goods` (`goods_id`,`exchange_integral`,`is_exchange`,`is_hot`) VALUES ('19','80000','1','0');
/*!40000 ALTER TABLE `yzl_exchange_goods` ENABLE KEYS */;


--
-- Create Table `yzl_favourable_activity`
--

DROP TABLE IF EXISTS `yzl_favourable_activity`;
CREATE TABLE `yzl_favourable_activity` (
  `act_id` smallint(5) unsigned NOT NULL auto_increment,
  `act_name` varchar(255) NOT NULL,
  `start_time` int(10) unsigned NOT NULL,
  `end_time` int(10) unsigned NOT NULL,
  `user_rank` varchar(255) NOT NULL,
  `act_range` tinyint(3) unsigned NOT NULL,
  `act_range_ext` varchar(255) NOT NULL,
  `min_amount` decimal(10,2) unsigned NOT NULL,
  `max_amount` decimal(10,2) unsigned NOT NULL,
  `act_type` tinyint(3) unsigned NOT NULL,
  `act_type_ext` decimal(10,2) unsigned NOT NULL,
  `gift` text NOT NULL,
  `sort_order` tinyint(3) unsigned NOT NULL default '50',
  PRIMARY KEY  (`act_id`),
  KEY `act_name` (`act_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_favourable_activity`
--

/*!40000 ALTER TABLE `yzl_favourable_activity` DISABLE KEYS */;
INSERT INTO `yzl_favourable_activity` (`act_id`,`act_name`,`start_time`,`end_time`,`user_rank`,`act_range`,`act_range_ext`,`min_amount`,`max_amount`,`act_type`,`act_type_ext`,`gift`,`sort_order`) VALUES ('1','5.1诺基亚优惠活动','1241107200','1253030400','1,2','2','1','500.00','5000.00','2','95.00','a:0:{}','50');
/*!40000 ALTER TABLE `yzl_favourable_activity` ENABLE KEYS */;


--
-- Create Table `yzl_feedback`
--

DROP TABLE IF EXISTS `yzl_feedback`;
CREATE TABLE `yzl_feedback` (
  `msg_id` mediumint(8) unsigned NOT NULL auto_increment,
  `parent_id` mediumint(8) unsigned NOT NULL default '0',
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `user_name` varchar(60) NOT NULL default '',
  `user_email` varchar(60) NOT NULL default '',
  `msg_title` varchar(200) NOT NULL default '',
  `msg_type` tinyint(1) unsigned NOT NULL default '0',
  `msg_status` tinyint(1) unsigned NOT NULL default '0',
  `msg_content` text NOT NULL,
  `msg_time` int(10) unsigned NOT NULL default '0',
  `message_img` varchar(255) NOT NULL default '0',
  `order_id` int(11) unsigned NOT NULL default '0',
  `msg_area` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`msg_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_feedback`
--

/*!40000 ALTER TABLE `yzl_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_feedback` ENABLE KEYS */;


--
-- Create Table `yzl_friend_link`
--

DROP TABLE IF EXISTS `yzl_friend_link`;
CREATE TABLE `yzl_friend_link` (
  `link_id` smallint(5) unsigned NOT NULL auto_increment,
  `link_name` varchar(255) NOT NULL default '',
  `link_url` varchar(255) NOT NULL default '',
  `link_logo` varchar(255) NOT NULL default '',
  `show_order` tinyint(3) unsigned NOT NULL default '50',
  PRIMARY KEY  (`link_id`),
  KEY `show_order` (`show_order`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_friend_link`
--

/*!40000 ALTER TABLE `yzl_friend_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_friend_link` ENABLE KEYS */;


--
-- Create Table `yzl_goods`
--

DROP TABLE IF EXISTS `yzl_goods`;
CREATE TABLE `yzl_goods` (
  `goods_id` mediumint(8) unsigned NOT NULL auto_increment,
  `cat_id` smallint(5) unsigned NOT NULL default '0',
  `goods_sn` varchar(60) NOT NULL default '',
  `goods_name` varchar(120) NOT NULL default '',
  `goods_name_style` varchar(60) NOT NULL default '+',
  `goods_subtitle` varchar(200) NOT NULL COMMENT '副标题',
  `click_count` int(10) unsigned NOT NULL default '0',
  `brand_id` smallint(5) unsigned NOT NULL default '0',
  `provider_name` varchar(100) NOT NULL default '',
  `goods_number` smallint(5) unsigned NOT NULL default '0',
  `goods_weight` decimal(10,3) unsigned NOT NULL default '0.000',
  `market_price` decimal(10,2) unsigned NOT NULL default '0.00',
  `shop_price` decimal(10,2) unsigned NOT NULL default '0.00',
  `promote_price` decimal(10,2) unsigned NOT NULL default '0.00',
  `promote_start_date` int(11) unsigned NOT NULL default '0',
  `promote_end_date` int(11) unsigned NOT NULL default '0',
  `warn_number` tinyint(3) unsigned NOT NULL default '1',
  `keywords` varchar(255) NOT NULL default '',
  `goods_for_skin` varchar(255) NOT NULL COMMENT '推荐肤质',
  `composition` varchar(255) NOT NULL COMMENT '养肤成分',
  `goods_packing` varchar(255) NOT NULL COMMENT '包装规格',
  `goods_brief` varchar(255) NOT NULL default '',
  `goods_desc` text NOT NULL,
  `goods_thumb` varchar(255) NOT NULL default '',
  `goods_img` varchar(255) NOT NULL default '',
  `original_img` varchar(255) NOT NULL default '',
  `is_real` tinyint(3) unsigned NOT NULL default '1',
  `extension_code` varchar(30) NOT NULL default '',
  `is_on_sale` tinyint(1) unsigned NOT NULL default '1',
  `is_alone_sale` tinyint(1) unsigned NOT NULL default '1',
  `is_shipping` tinyint(1) unsigned NOT NULL default '0',
  `integral` int(10) unsigned NOT NULL default '0',
  `add_time` int(10) unsigned NOT NULL default '0',
  `sort_order` smallint(4) unsigned NOT NULL default '100',
  `is_delete` tinyint(1) unsigned NOT NULL default '0',
  `is_best` tinyint(1) unsigned NOT NULL default '0',
  `is_new` tinyint(1) unsigned NOT NULL default '0',
  `is_hot` tinyint(1) unsigned NOT NULL default '0',
  `is_promote` tinyint(1) unsigned NOT NULL default '0',
  `bonus_type_id` tinyint(3) unsigned NOT NULL default '0',
  `last_update` int(10) unsigned NOT NULL default '0',
  `goods_type` smallint(5) unsigned NOT NULL default '0',
  `seller_note` varchar(255) NOT NULL default '',
  `give_integral` int(11) NOT NULL default '-1',
  `rank_integral` int(11) NOT NULL default '-1',
  `suppliers_id` smallint(5) unsigned default NULL,
  `is_check` tinyint(1) unsigned default NULL,
  `define_url` varchar(255) NOT NULL,
  PRIMARY KEY  (`goods_id`),
  KEY `goods_sn` (`goods_sn`),
  KEY `cat_id` (`cat_id`),
  KEY `last_update` (`last_update`),
  KEY `brand_id` (`brand_id`),
  KEY `goods_weight` (`goods_weight`),
  KEY `promote_end_date` (`promote_end_date`),
  KEY `promote_start_date` (`promote_start_date`),
  KEY `goods_number` (`goods_number`),
  KEY `sort_order` (`sort_order`),
  KEY `define_url` (`define_url`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_goods`
--

/*!40000 ALTER TABLE `yzl_goods` DISABLE KEYS */;
INSERT INTO `yzl_goods` (`goods_id`,`cat_id`,`goods_sn`,`goods_name`,`goods_name_style`,`goods_subtitle`,`click_count`,`brand_id`,`provider_name`,`goods_number`,`goods_weight`,`market_price`,`shop_price`,`promote_price`,`promote_start_date`,`promote_end_date`,`warn_number`,`keywords`,`goods_for_skin`,`composition`,`goods_packing`,`goods_brief`,`goods_desc`,`goods_thumb`,`goods_img`,`original_img`,`is_real`,`extension_code`,`is_on_sale`,`is_alone_sale`,`is_shipping`,`integral`,`add_time`,`sort_order`,`is_delete`,`is_best`,`is_new`,`is_hot`,`is_promote`,`bonus_type_id`,`last_update`,`goods_type`,`seller_note`,`give_integral`,`rank_integral`,`suppliers_id`,`is_check`,`define_url`) VALUES ('19','19','36437','牡丹紧致逆颜蚕丝面膜','+','','8','12','','12','0.000','1029.60','858.00','0.00','0','0','1','滑盖 GSM 258 时尚 蓝牙 黑色 金色 白色','','','','从整体来看，三星SGH-F258比较时尚可爱，三围尺寸为94×46×17.5mm，重量为96克，曲线柔和具有玲珑美感\r\n','<p><span style=\"color: rgb(255, 121, 126); font-family: \'Microsoft YaHei\'; line-height: 22px;\">独特的牡丹萃取调理配方，使牡丹精华更易被肌肤吸收，有效促进血液循环改善 黑眼圈、减少黑色的沉积、增加肌肤弹性、抚平细纹令肌肤光滑细致、活肤逆颜 的同时恢复肌肤青春时的娇嫩白皙。</span></p>','images/201310/thumb_img/19_thumb_G_1382884434293.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg','1','','1','1','0','8','1241970139','100','1','1','1','1','0','0','1382884452','8','','-1','-1','0',NULL,'');
INSERT INTO `yzl_goods` (`goods_id`,`cat_id`,`goods_sn`,`goods_name`,`goods_name_style`,`goods_subtitle`,`click_count`,`brand_id`,`provider_name`,`goods_number`,`goods_weight`,`market_price`,`shop_price`,`promote_price`,`promote_start_date`,`promote_end_date`,`warn_number`,`keywords`,`goods_for_skin`,`composition`,`goods_packing`,`goods_brief`,`goods_desc`,`goods_thumb`,`goods_img`,`original_img`,`is_real`,`extension_code`,`is_on_sale`,`is_alone_sale`,`is_shipping`,`integral`,`add_time`,`sort_order`,`is_delete`,`is_best`,`is_new`,`is_hot`,`is_promote`,`bonus_type_id`,`last_update`,`goods_type`,`seller_note`,`give_integral`,`rank_integral`,`suppliers_id`,`is_check`,`define_url`) VALUES ('20','17','64727727','玫瑰美白补水蚕丝面膜','+','','19','12','','12','0.000','336.00','280.00','238.00','1241856000','1251619200','1','','','','','','<p><img alt=\"\" src=\"http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130619/20130619124840_14838.jpg\" style=\"margin: 0px; padding: 0px; list-style: none; border: none; display: block; font-family: \'Microsoft YaHei\'; font-size: medium;\" /><img alt=\"\" src=\"http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130619/20130619124842_60877.jpg\" style=\"margin: 0px; padding: 0px; list-style: none; border: none; display: block; font-family: \'Microsoft YaHei\'; font-size: medium;\" /><img alt=\"\" src=\"http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130619/20130619124845_80051.jpg\" style=\"margin: 0px; padding: 0px; list-style: none; border: none; display: block; font-family: \'Microsoft YaHei\'; font-size: medium;\" /><img alt=\"\" src=\"http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130619/20130619124847_70926.jpg\" style=\"margin: 0px; padding: 0px; list-style: none; border: none; display: block; font-family: \'Microsoft YaHei\'; font-size: medium;\" /><img alt=\"\" src=\"http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130619/20130619124848_86125.jpg\" style=\"margin: 0px; padding: 0px; list-style: none; border: none; display: block; font-family: \'Microsoft YaHei\'; font-size: medium;\" /></p>','images/201310/thumb_img/20_thumb_G_1382884966084.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610160227_36845.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610160227_36845.jpg','1','','1','1','0','2','1241970417','100','1','1','1','1','1','0','1382884966','8','','-1','-1','0',NULL,'');
INSERT INTO `yzl_goods` (`goods_id`,`cat_id`,`goods_sn`,`goods_name`,`goods_name_style`,`goods_subtitle`,`click_count`,`brand_id`,`provider_name`,`goods_number`,`goods_weight`,`market_price`,`shop_price`,`promote_price`,`promote_start_date`,`promote_end_date`,`warn_number`,`keywords`,`goods_for_skin`,`composition`,`goods_packing`,`goods_brief`,`goods_desc`,`goods_thumb`,`goods_img`,`original_img`,`is_real`,`extension_code`,`is_on_sale`,`is_alone_sale`,`is_shipping`,`integral`,`add_time`,`sort_order`,`is_delete`,`is_best`,`is_new`,`is_hot`,`is_promote`,`bonus_type_id`,`last_update`,`goods_type`,`seller_note`,`give_integral`,`rank_integral`,`suppliers_id`,`is_check`,`define_url`) VALUES ('21','18','57888','牡丹紧致逆颜蚕丝面膜','+','','5','12','','40','0.000','2400.00','2000.00','0.00','0','0','1','2008年03月 GSM,900,1800,1900,2100 直板 1600万 240×400 像素 2007年12月 200万摄像头 黑色','','','','','<p><span style=\"color: rgb(255, 121, 126); font-family: \'Microsoft YaHei\'; line-height: 22px;\">独特的牡丹萃取调理配方，使牡丹精华更易被肌肤吸收，有效促进血液循环改善 黑眼圈、减少黑色的沉积、增加肌肤弹性、抚平细纹令肌肤光滑细致、活肤逆颜 的同时恢复肌肤青春时的娇嫩白皙。</span></p>','images/201310/thumb_img/21_thumb_G_1382884598652.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg','1','','1','1','0','20','1241970634','100','1','0','0','0','0','0','1382884598','9','','-1','-1','0',NULL,'');
INSERT INTO `yzl_goods` (`goods_id`,`cat_id`,`goods_sn`,`goods_name`,`goods_name_style`,`goods_subtitle`,`click_count`,`brand_id`,`provider_name`,`goods_number`,`goods_weight`,`market_price`,`shop_price`,`promote_price`,`promote_start_date`,`promote_end_date`,`warn_number`,`keywords`,`goods_for_skin`,`composition`,`goods_packing`,`goods_brief`,`goods_desc`,`goods_thumb`,`goods_img`,`original_img`,`is_real`,`extension_code`,`is_on_sale`,`is_alone_sale`,`is_shipping`,`integral`,`add_time`,`sort_order`,`is_delete`,`is_best`,`is_new`,`is_hot`,`is_promote`,`bonus_type_id`,`last_update`,`goods_type`,`seller_note`,`give_integral`,`rank_integral`,`suppliers_id`,`is_check`,`define_url`) VALUES ('22','17','58685828','百合控油保湿蚕丝面膜','+','','27','0','','1','0.000','7198.80','5999.00','0.00','0','0','1','500万摄像头 蓝牙 手写 GPS 办公应用 语音拨号 2008年12月 黑色 GSM,850,900,1800,1900 直板 B','','','','','<p><span style=\"color: rgb(255, 121, 126); font-family: \'Microsoft YaHei\'; line-height: 22px;\">独特的百合提取物，为肌肤注入活力、击退多种顽固美白问题，改善肤色同时，令肌肤焕发无暇光彩，重获新生般柔滑白嫩。</span></p>','images/201310/thumb_img/22_thumb_G_1382884662375.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610151859_86957.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610151859_86957.jpg','1','','1','1','0','59','1241971076','100','1','1','1','0','0','0','1385040926','8','','-1','-1','0',NULL,'');
INSERT INTO `yzl_goods` (`goods_id`,`cat_id`,`goods_sn`,`goods_name`,`goods_name_style`,`goods_subtitle`,`click_count`,`brand_id`,`provider_name`,`goods_number`,`goods_weight`,`market_price`,`shop_price`,`promote_price`,`promote_start_date`,`promote_end_date`,`warn_number`,`keywords`,`goods_for_skin`,`composition`,`goods_packing`,`goods_brief`,`goods_desc`,`goods_thumb`,`goods_img`,`original_img`,`is_real`,`extension_code`,`is_on_sale`,`is_alone_sale`,`is_shipping`,`integral`,`add_time`,`sort_order`,`is_delete`,`is_best`,`is_new`,`is_hot`,`is_promote`,`bonus_type_id`,`last_update`,`goods_type`,`seller_note`,`give_integral`,`rank_integral`,`suppliers_id`,`is_check`,`define_url`) VALUES ('23','16','68854846846','菩提花塑颜V脸蚕丝面膜','+','','20','12','','7','0.000','4440.00','3700.00','0.00','0','0','1','500万摄像头 microSD 工程塑料 蓝牙 数码相机 内置游戏 滑盖 高档 2008年09月 320×240 像素 黑色','','','','','<p><span style=\"color: rgb(255, 121, 126); font-family: \'Microsoft YaHei\'; line-height: 22px;\">独特的天然蚕丝面膜材质及天然菩提花提取精华，优质小果咖啡精华与天然茉莉精油的绝妙融合，排水、代谢及收紧的同时，定向促进脸部组织新陈代谢，针对脸部多余脂肪及宽型骨骼组织，实现靶向代谢V脸塑形，柔嫩肌肤，提升肌肤紧致度及脸部线条</span></p>','images/200905/thumb_img/23_thumb_G_1241971556399.jpg','images/200905/goods_img/23_G_1241971556855.jpg','images/200905/source_img/23_G_1241971556256.jpg','1','','1','1','0','37','1241971488','100','1','1','1','0','0','0','1382884711','8','','-1','-1','0',NULL,'');
INSERT INTO `yzl_goods` (`goods_id`,`cat_id`,`goods_sn`,`goods_name`,`goods_name_style`,`goods_subtitle`,`click_count`,`brand_id`,`provider_name`,`goods_number`,`goods_weight`,`market_price`,`shop_price`,`promote_price`,`promote_start_date`,`promote_end_date`,`warn_number`,`keywords`,`goods_for_skin`,`composition`,`goods_packing`,`goods_brief`,`goods_desc`,`goods_thumb`,`goods_img`,`original_img`,`is_real`,`extension_code`,`is_on_sale`,`is_alone_sale`,`is_shipping`,`integral`,`add_time`,`sort_order`,`is_delete`,`is_best`,`is_new`,`is_hot`,`is_promote`,`bonus_type_id`,`last_update`,`goods_type`,`seller_note`,`give_integral`,`rank_integral`,`suppliers_id`,`is_check`,`define_url`) VALUES ('24','19','575757','茉莉焕颜柔肤蚕丝面膜','+','','35','12','','100','0.000','2400.00','2000.00','1850.00','1243756800','1277798400','1','','','','','','<div>\r\n<div><span style=\"color: rgb(255, 121, 126); font-family: \'Microsoft YaHei\'; line-height: 22px;\">二次净化肌肤毛孔污垢、软化皮肤老化角质，畅通毛孔同时紧致肌肤收缩毛孔，令亮白成分直达肌肤深层，有效匀净肤色，淡化暗沉，令肌肤由内透出源源白皙。</span></div>\r\n</div>','images/201310/thumb_img/24_thumb_G_1382884781644.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610162142_35823.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610162142_35823.jpg','1','','1','1','0','20','1241971981','100','1','1','1','1','1','0','1382884928','9','','-1','-1','0',NULL,'');
INSERT INTO `yzl_goods` (`goods_id`,`cat_id`,`goods_sn`,`goods_name`,`goods_name_style`,`goods_subtitle`,`click_count`,`brand_id`,`provider_name`,`goods_number`,`goods_weight`,`market_price`,`shop_price`,`promote_price`,`promote_start_date`,`promote_end_date`,`warn_number`,`keywords`,`goods_for_skin`,`composition`,`goods_packing`,`goods_brief`,`goods_desc`,`goods_thumb`,`goods_img`,`original_img`,`is_real`,`extension_code`,`is_on_sale`,`is_alone_sale`,`is_shipping`,`integral`,`add_time`,`sort_order`,`is_delete`,`is_best`,`is_new`,`is_hot`,`is_promote`,`bonus_type_id`,`last_update`,`goods_type`,`seller_note`,`give_integral`,`rank_integral`,`suppliers_id`,`is_check`,`define_url`) VALUES ('31','17','12','牡丹紧致逆颜蚕丝面膜','+','','7','12','','1','0.000','1604.39','1337.00','155.00','1382688000','1540454400','1','直板 A aaaaaaaaaaaaa','','','','','','images/201310/thumb_img/31_thumb_G_1382884344974.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg','1','','0','1','0','13','1242110412','100','1','0','0','0','1','0','1385052878','8','','-1','-1','0',NULL,'');
INSERT INTO `yzl_goods` (`goods_id`,`cat_id`,`goods_sn`,`goods_name`,`goods_name_style`,`goods_subtitle`,`click_count`,`brand_id`,`provider_name`,`goods_number`,`goods_weight`,`market_price`,`shop_price`,`promote_price`,`promote_start_date`,`promote_end_date`,`warn_number`,`keywords`,`goods_for_skin`,`composition`,`goods_packing`,`goods_brief`,`goods_desc`,`goods_thumb`,`goods_img`,`original_img`,`is_real`,`extension_code`,`is_on_sale`,`is_alone_sale`,`is_shipping`,`integral`,`add_time`,`sort_order`,`is_delete`,`is_best`,`is_new`,`is_hot`,`is_promote`,`bonus_type_id`,`last_update`,`goods_type`,`seller_note`,`give_integral`,`rank_integral`,`suppliers_id`,`is_check`,`define_url`) VALUES ('32','16','10','荷花清颜水肌睡眠面膜','+','颜紧致 脱敏修护 补水美白颜紧致 ','36','12','','4','0.000','120.00','100.00','2750.00','1243756800','1417248000','1','','','','','','<p><img alt=\"\" src=\"/static/public/kindeditor-4.1.7/php/../attached/image/20130619/20130619110419_68699.jpg\" /><img alt=\"\" src=\"/static/public/kindeditor-4.1.7/php/../attached/image/20130619/20130619110421_78080.jpg\" /><img alt=\"\" src=\"/static/public/kindeditor-4.1.7/php/../attached/image/20130619/20130619110424_33062.jpg\" /><img alt=\"\" src=\"/static/public/kindeditor-4.1.7/php/../attached/image/20130619/20130619110426_66058.jpg\" /><img alt=\"\" src=\"/static/public/kindeditor-4.1.7/php/../attached/image/20130619/20130619110428_41511.jpg\" /></p>','images/201310/thumb_img/32_thumb_G_1382884235298.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610163511_48073.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610163511_48073.jpg','1','','1','1','0','1','1242110760','100','1','0','1','1','1','0','1385058573','8','','-1','-1','0',NULL,'');
INSERT INTO `yzl_goods` (`goods_id`,`cat_id`,`goods_sn`,`goods_name`,`goods_name_style`,`goods_subtitle`,`click_count`,`brand_id`,`provider_name`,`goods_number`,`goods_weight`,`market_price`,`shop_price`,`promote_price`,`promote_start_date`,`promote_end_date`,`warn_number`,`keywords`,`goods_for_skin`,`composition`,`goods_packing`,`goods_brief`,`goods_desc`,`goods_thumb`,`goods_img`,`original_img`,`is_real`,`extension_code`,`is_on_sale`,`is_alone_sale`,`is_shipping`,`integral`,`add_time`,`sort_order`,`is_delete`,`is_best`,`is_new`,`is_hot`,`is_promote`,`bonus_type_id`,`last_update`,`goods_type`,`seller_note`,`give_integral`,`rank_integral`,`suppliers_id`,`is_check`,`define_url`) VALUES ('33','17','YZL000033','测试商品1','+','测试商品1防范地方地方大幅度反弹','22','12','','150','0.000','93.60','78.00','59.00','1384934400','1389772800','1','','xx推荐肤色不均，浊质明显，油腻不适肌肤适用','vv樱花提取物 当归提取物 光甘草啶 太阳花籽油 仙人掌糖醛 樱花提取物 当归提取物 光甘草啶 太阳花籽油','xx 5片装 25g/片 dd','睡眠舒缓状态下整晚保湿，更持久地为肌肤补充水分。天然净白成分温和润白肌肤，改善肌肤黯黄、淡化黑色素、均匀肤色，令肌肤呈现零负担的清爽舒适。','','images/201311/thumb_img/33_thumb_G_1385063437613.jpg','images/201311/goods_img/33_G_1385063437840.jpg','images/201311/source_img/33_G_1385063437682.jpg','1','','1','1','0','0','1385058423','100','0','0','0','0','1','0','1385063499','8','','-1','-1','0',NULL,'');
/*!40000 ALTER TABLE `yzl_goods` ENABLE KEYS */;


--
-- Create Table `yzl_goods_activity`
--

DROP TABLE IF EXISTS `yzl_goods_activity`;
CREATE TABLE `yzl_goods_activity` (
  `act_id` mediumint(8) unsigned NOT NULL auto_increment,
  `act_name` varchar(255) NOT NULL,
  `act_desc` text NOT NULL,
  `act_type` tinyint(3) unsigned NOT NULL,
  `goods_id` mediumint(8) unsigned NOT NULL,
  `product_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_name` varchar(255) NOT NULL,
  `start_time` int(10) unsigned NOT NULL,
  `end_time` int(10) unsigned NOT NULL,
  `is_finished` tinyint(3) unsigned NOT NULL,
  `ext_info` text NOT NULL,
  PRIMARY KEY  (`act_id`),
  KEY `act_name` (`act_name`,`act_type`,`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_goods_activity`
--

/*!40000 ALTER TABLE `yzl_goods_activity` DISABLE KEYS */;
INSERT INTO `yzl_goods_activity` (`act_id`,`act_name`,`act_desc`,`act_type`,`goods_id`,`product_id`,`goods_name`,`start_time`,`end_time`,`is_finished`,`ext_info`) VALUES ('1','你回复的速度','5665','0','23','3','菩提花塑颜V脸蚕丝面膜','1382766780','1383198780','0','a:4:{s:11:\"start_price\";s:4:\"1.00\";s:9:\"end_price\";s:6:\"800.00\";s:9:\"max_price\";i:0;s:11:\"cost_points\";s:1:\"1\";}');
INSERT INTO `yzl_goods_activity` (`act_id`,`act_name`,`act_desc`,`act_type`,`goods_id`,`product_id`,`goods_name`,`start_time`,`end_time`,`is_finished`,`ext_info`) VALUES ('2','夺宝奇兵之夏新N7','给你打吧','0','21','4','牡丹紧致逆颜蚕丝面膜','1382939820','1383199020','0','a:4:{s:11:\"start_price\";s:4:\"1.00\";s:9:\"end_price\";s:6:\"800.00\";s:9:\"max_price\";i:0;s:11:\"cost_points\";s:1:\"1\";}');
INSERT INTO `yzl_goods_activity` (`act_id`,`act_name`,`act_desc`,`act_type`,`goods_id`,`product_id`,`goods_name`,`start_time`,`end_time`,`is_finished`,`ext_info`) VALUES ('3','P806','本期团购活动——联想新品P806\n团购买的多优惠多','1','24','0','P806','1241971200','1242403200','3','a:4:{s:12:\"price_ladder\";a:3:{i:0;a:2:{s:6:\"amount\";i:10;s:5:\"price\";d:1850;}i:1;a:2:{s:6:\"amount\";i:15;s:5:\"price\";d:1800;}i:2;a:2:{s:6:\"amount\";i:20;s:5:\"price\";d:1780;}}s:15:\"restrict_amount\";i:0;s:13:\"gift_integral\";i:0;s:7:\"deposit\";d:1000;}');
INSERT INTO `yzl_goods_activity` (`act_id`,`act_name`,`act_desc`,`act_type`,`goods_id`,`product_id`,`goods_name`,`start_time`,`end_time`,`is_finished`,`ext_info`) VALUES ('4','拍卖活动——索爱C702c','','2','10','0','索爱C702c','1242144000','1242403200','0','a:5:{s:7:\"deposit\";d:0;s:11:\"start_price\";d:0;s:9:\"end_price\";i:0;s:9:\"amplitude\";d:20;s:6:\"no_top\";i:1;}');
INSERT INTO `yzl_goods_activity` (`act_id`,`act_name`,`act_desc`,`act_type`,`goods_id`,`product_id`,`goods_name`,`start_time`,`end_time`,`is_finished`,`ext_info`) VALUES ('5','摩托罗拉E8 大礼包','礼包大优惠','4','31','0','摩托罗拉E8 ','1242110400','1252046400','0','a:1:{s:13:\"package_price\";s:4:\"1430\";}');
INSERT INTO `yzl_goods_activity` (`act_id`,`act_name`,`act_desc`,`act_type`,`goods_id`,`product_id`,`goods_name`,`start_time`,`end_time`,`is_finished`,`ext_info`) VALUES ('6','诺基亚N85大礼包','诺基亚N85超值大礼包','4','32','0','诺基亚N85','1242110760','1248936360','0','a:1:{s:13:\"package_price\";s:4:\"3150\";}');
INSERT INTO `yzl_goods_activity` (`act_id`,`act_name`,`act_desc`,`act_type`,`goods_id`,`product_id`,`goods_name`,`start_time`,`end_time`,`is_finished`,`ext_info`) VALUES ('8','P806','团购第2期','1','24','0','P806','1242316800','1274803200','0','a:4:{s:12:\"price_ladder\";a:2:{i:0;a:2:{s:6:\"amount\";i:5;s:5:\"price\";d:1910;}i:1;a:2:{s:6:\"amount\";i:10;s:5:\"price\";d:1860;}}s:15:\"restrict_amount\";i:0;s:13:\"gift_integral\";i:0;s:7:\"deposit\";d:1000;}');
/*!40000 ALTER TABLE `yzl_goods_activity` ENABLE KEYS */;


--
-- Create Table `yzl_goods_article`
--

DROP TABLE IF EXISTS `yzl_goods_article`;
CREATE TABLE `yzl_goods_article` (
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `article_id` mediumint(8) unsigned NOT NULL default '0',
  `admin_id` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`goods_id`,`article_id`,`admin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_goods_article`
--

/*!40000 ALTER TABLE `yzl_goods_article` DISABLE KEYS */;
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('1','27','1');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('8','28','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('9','8','1');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('13','29','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('14','29','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('14','31','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('19','85','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('19','88','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('20','85','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('20','88','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('21','85','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('21','88','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('22','85','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('22','88','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('23','8','1');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('23','30','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('23','31','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('23','85','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('23','88','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('24','85','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('24','88','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('31','85','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('31','88','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('32','8','1');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('32','30','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('32','85','0');
INSERT INTO `yzl_goods_article` (`goods_id`,`article_id`,`admin_id`) VALUES ('32','88','0');
/*!40000 ALTER TABLE `yzl_goods_article` ENABLE KEYS */;


--
-- Create Table `yzl_goods_attr`
--

DROP TABLE IF EXISTS `yzl_goods_attr`;
CREATE TABLE `yzl_goods_attr` (
  `goods_attr_id` int(10) unsigned NOT NULL auto_increment,
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `attr_id` smallint(5) unsigned NOT NULL default '0',
  `attr_value` text NOT NULL,
  `attr_price` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`goods_attr_id`),
  KEY `goods_id` (`goods_id`),
  KEY `attr_id` (`attr_id`)
) ENGINE=MyISAM AUTO_INCREMENT=279 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_goods_attr`
--

/*!40000 ALTER TABLE `yzl_goods_attr` DISABLE KEYS */;
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('278','33','167','当归提取物','');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('277','33','167','仙人掌糖醛','');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('276','33','167','太阳花籽油','');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('275','33','167','光甘草啶','');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('273','31','212','玫瑰莹润焕白','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('272','31','171','女性','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('271','31','170','中性','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('269','22','212','玫瑰莹润焕白','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('268','22','211','B','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('270','31','211','aaaaaaaaaaaaa','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('266','32','212','玫瑰莹润焕白','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('274','33','167','樱花提取物','');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('264','20','165','黑金帝国','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('263','24','179','SMS','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('262','24','210','数据线','20');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('261','24','185','灰色','');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('260','24','190','支持','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('259','24','183','支持','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('258','24','172','2008年06月','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('257','23','165','因为任何是否会','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('256','22','165','非官方公布','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('255','21','175','100小时','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('254','21','174','2.5小时','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('253','21','210','线控耳机','50');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('252','21','210','数据线','20');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('249','31','166','等等','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('248','31','165','大大的','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('247','32','171','女性','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('246','32','170','油性','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('245','32','169','脸','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('244','32','168','彩妆','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('243','32','167','大大的','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('242','32','166','发发','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('241','32','165',' 打发打发','0');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('251','21','185','黑色','');
INSERT INTO `yzl_goods_attr` (`goods_attr_id`,`goods_id`,`attr_id`,`attr_value`,`attr_price`) VALUES ('250','21','180','T-Flash','0');
/*!40000 ALTER TABLE `yzl_goods_attr` ENABLE KEYS */;


--
-- Create Table `yzl_goods_cat`
--

DROP TABLE IF EXISTS `yzl_goods_cat`;
CREATE TABLE `yzl_goods_cat` (
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `cat_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`goods_id`,`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_goods_cat`
--

/*!40000 ALTER TABLE `yzl_goods_cat` DISABLE KEYS */;
INSERT INTO `yzl_goods_cat` (`goods_id`,`cat_id`) VALUES ('8','2');
INSERT INTO `yzl_goods_cat` (`goods_id`,`cat_id`) VALUES ('8','5');
INSERT INTO `yzl_goods_cat` (`goods_id`,`cat_id`) VALUES ('16','3');
INSERT INTO `yzl_goods_cat` (`goods_id`,`cat_id`) VALUES ('16','5');
INSERT INTO `yzl_goods_cat` (`goods_id`,`cat_id`) VALUES ('33','17');
INSERT INTO `yzl_goods_cat` (`goods_id`,`cat_id`) VALUES ('33','34');
/*!40000 ALTER TABLE `yzl_goods_cat` ENABLE KEYS */;


--
-- Create Table `yzl_goods_gallery`
--

DROP TABLE IF EXISTS `yzl_goods_gallery`;
CREATE TABLE `yzl_goods_gallery` (
  `img_id` mediumint(8) unsigned NOT NULL auto_increment,
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `img_url` varchar(255) NOT NULL default '',
  `img_desc` varchar(255) NOT NULL default '',
  `thumb_url` varchar(255) NOT NULL default '',
  `img_original` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`img_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_goods_gallery`
--

/*!40000 ALTER TABLE `yzl_goods_gallery` DISABLE KEYS */;
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('1','1','images/200905/goods_img/1_P_1240902890730.gif','','images/200905/thumb_img/1_thumb_P_1240902890139.jpg','images/200905/source_img/1_P_1240902890193.gif');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('2','1','images/200905/goods_img/1_P_1240904370445.jpg','','images/200905/thumb_img/1_thumb_P_1240904370846.jpg','images/200905/source_img/1_P_1240904370647.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('3','1','images/200905/goods_img/1_P_1240904371414.jpg','','images/200905/thumb_img/1_thumb_P_1240904371539.jpg','images/200905/source_img/1_P_1240904371019.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('4','1','images/200905/goods_img/1_P_1240904371355.jpg','','images/200905/thumb_img/1_thumb_P_1240904371335.jpg','images/200905/source_img/1_P_1240904371118.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('5','1','images/200905/goods_img/1_P_1240904371252.jpg','','images/200905/thumb_img/1_thumb_P_1240904371430.jpg','images/200905/source_img/1_P_1240904371758.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('6','3','images/200905/goods_img/3_P_1241422082461.jpg','','images/200905/thumb_img/3_thumb_P_1241422082160.jpg','images/200905/source_img/3_P_1241422082816.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('7','4','images/200905/goods_img/4_P_1241422402169.jpg','','images/200905/thumb_img/4_thumb_P_1241422402909.jpg','images/200905/source_img/4_P_1241422402362.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('8','5','images/200905/goods_img/5_P_1241422518168.jpg','','images/200905/thumb_img/5_thumb_P_1241422518416.jpg','images/200905/source_img/5_P_1241422518314.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('9','7','images/200905/goods_img/7_P_1241422785926.jpg','','images/200905/thumb_img/7_thumb_P_1241422785889.jpg','images/200905/source_img/7_P_1241422785172.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('10','8','images/200905/goods_img/8_P_1241425513388.jpg','','images/200905/thumb_img/8_thumb_P_1241425513834.jpg','images/200905/source_img/8_P_1241425513810.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('11','8','images/200905/goods_img/8_P_1241425891781.JPG','正面','images/200905/thumb_img/8_thumb_P_1241425891460.jpg','images/200905/source_img/8_P_1241425891321.JPG');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('12','8','images/200905/goods_img/8_P_1241425891193.jpg','背面','images/200905/thumb_img/8_thumb_P_1241425892547.jpg','images/200905/source_img/8_P_1241425891588.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('13','8','images/200905/goods_img/8_P_1241425892941.JPG','侧面','images/200905/thumb_img/8_thumb_P_1241425892356.jpg','images/200905/source_img/8_P_1241425892999.JPG');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('14','9','images/200905/goods_img/9_P_1241511871575.jpg','','images/200905/thumb_img/9_thumb_P_1241511871787.jpg','images/200905/source_img/9_P_1241511871749.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('15','12','images/200905/goods_img/12_P_1241965978060.jpg','','images/200905/thumb_img/12_thumb_P_1241965978845.jpg','images/200905/source_img/12_P_1241965978333.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('16','12','images/200905/goods_img/12_P_1241966218046.jpg','','images/200905/thumb_img/12_thumb_P_1241966218835.jpg','images/200905/source_img/12_P_1241966218225.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('17','12','images/200905/goods_img/12_P_1241966218391.jpg','','images/200905/thumb_img/12_thumb_P_1241966218843.jpg','images/200905/source_img/12_P_1241966218859.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('18','13','images/200905/goods_img/13_P_1241967762510.jpg','','images/200905/thumb_img/13_thumb_P_1241967762510.jpg','images/200905/source_img/13_P_1241967762358.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('19','13','images/200905/goods_img/13_P_1241968002659.jpg','','images/200905/thumb_img/13_thumb_P_1241968002193.jpg','images/200905/source_img/13_P_1241968002709.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('20','14','images/200905/goods_img/14_P_1241968492774.jpg','','images/200905/thumb_img/14_thumb_P_1241968492168.jpg','images/200905/source_img/14_P_1241968492973.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('21','14','images/200905/goods_img/14_P_1241968492721.jpg','','images/200905/thumb_img/14_thumb_P_1241968492995.jpg','images/200905/source_img/14_P_1241968492307.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('22','14','images/200905/goods_img/14_P_1241968492279.jpg','','images/200905/thumb_img/14_thumb_P_1241968492674.jpg','images/200905/source_img/14_P_1241968492392.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('23','16','images/200905/goods_img/16_P_1241968949498.jpg','','images/200905/thumb_img/16_thumb_P_1241968949965.jpg','images/200905/source_img/16_P_1241968949069.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('24','17','images/200905/goods_img/17_P_1241969394354.jpg','','images/200905/thumb_img/17_thumb_P_1241969394537.jpg','images/200905/source_img/17_P_1241969394369.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('63','19','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153404_41843.jpg','','images/201310/thumb_img/19_thumb_P_1382884435727.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153404_41843.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('62','19','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg','','images/201310/thumb_img/19_thumb_P_1382884434726.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('69','23','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610161538_72502.jpg','','images/201310/thumb_img/23_thumb_P_1382884712573.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610161538_72502.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('70','24','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610162142_35823.jpg','','images/201310/thumb_img/24_thumb_P_1382884781288.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610162142_35823.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('75','33','images/201311/goods_img/33_P_1385063417191.jpg','','images/201311/thumb_img/33_thumb_P_1385063417817.jpg','images/201311/source_img/33_P_1385063417428.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('32','26','images/200905/goods_img/26_P_1241972789025.jpg','','images/200905/thumb_img/26_thumb_P_1241972789061.jpg','images/200905/source_img/26_P_1241972789731.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('33','27','images/200905/goods_img/27_P_1241972894128.jpg','','images/200905/thumb_img/27_thumb_P_1241972894915.jpg','images/200905/source_img/27_P_1241972894886.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('34','28','images/200905/goods_img/28_P_1241972976099.jpg','','images/200905/thumb_img/28_thumb_P_1241972976277.jpg','images/200905/source_img/28_P_1241972976150.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('35','29','images/200905/goods_img/29_P_1241973022876.jpg','','images/200905/thumb_img/29_thumb_P_1241973022886.jpg','images/200905/source_img/29_P_1241973022880.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('36','30','images/200905/goods_img/30_P_1241973114554.jpg','','images/200905/thumb_img/30_thumb_P_1241973114166.jpg','images/200905/source_img/30_P_1241973114795.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('72','20','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610160227_36845.jpg','','images/201310/thumb_img/20_thumb_P_1382884878430.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610160227_36845.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('65','21','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg','','images/201310/thumb_img/21_thumb_P_1382884598218.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('60','31','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg','','images/201310/thumb_img/31_thumb_P_1382884344116.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153349_25238.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('58','32','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610163511_48073.jpg','','images/201310/thumb_img/32_thumb_P_1382884235447.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610163511_48073.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('42','15','images/200905/goods_img/15_P_1242973362276.jpg','','images/200905/thumb_img/15_thumb_P_1242973362611.jpg','images/200905/source_img/15_P_1242973362172.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('43','10','images/200905/goods_img/10_P_1242973436620.jpg','','images/200905/thumb_img/10_thumb_P_1242973436219.jpg','images/200905/source_img/10_P_1242973436898.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('67','22','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610151859_86957.jpg','','images/201310/thumb_img/22_thumb_P_1382884662160.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610151859_86957.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('68','22','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610151911_60191.jpg','','images/201310/thumb_img/22_thumb_P_1382884663664.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610151911_60191.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('47','48','images/201310/goods_img/48_P_1381738409678.jpg','壁纸1','images/201310/thumb_img/48_thumb_P_1381738409803.jpg','images/201310/source_img/48_P_1381738409906.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('48','48','images/201310/goods_img/48_P_1381738409267.jpg','壁纸二','images/201310/thumb_img/48_thumb_P_1381738409100.jpg','images/201310/source_img/48_P_1381738409994.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('49','49','images/201310/goods_img/49_P_1381738453702.jpg','壁纸1','images/201310/thumb_img/49_thumb_P_1381738453863.jpg','images/201310/source_img/49_P_1381738453836.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('50','49','images/201310/goods_img/49_P_1381738454290.jpg','壁纸二','images/201310/thumb_img/49_thumb_P_1381738454562.jpg','images/201310/source_img/49_P_1381738454460.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('51','50','images/201310/goods_img/50_P_1381738474901.jpg','壁纸1','images/201310/thumb_img/50_thumb_P_1381738474406.jpg','images/201310/source_img/50_P_1381738474435.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('52','50','images/201310/goods_img/50_P_1381738474617.jpg','发发','images/201310/thumb_img/50_thumb_P_1381738474368.jpg','images/201310/source_img/50_P_1381738474850.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('53','51','images/201310/goods_img/51_P_1381738543004.jpg','测试壁纸图片上传111','images/201310/thumb_img/51_thumb_P_1381738543907.jpg','images/201310/source_img/51_P_1381738543412.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('54','51','images/201310/goods_img/51_P_1381738543108.jpg','测试壁纸图片上传2222','images/201310/thumb_img/51_thumb_P_1381738543132.jpg','images/201310/source_img/51_P_1381738543095.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('55','52','images/201310/goods_img/52_P_1381739112048.jpg','测试壁纸图片上传111','images/201310/thumb_img/52_thumb_P_1381739112792.jpg','images/201310/source_img/52_P_1381739112200.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('56','53','images/201310/goods_img/53_P_1381739478838.jpg','测试壁纸图片上传111','images/201310/thumb_img/53_thumb_P_1381739478930.jpg','images/201310/source_img/53_P_1381739478695.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('57','53','images/201310/goods_img/53_P_1381739478345.jpg','打发打发','images/201310/thumb_img/53_thumb_P_1381739478261.jpg','images/201310/source_img/53_P_1381739478590.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('59','32','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610163638_12694.jpg','','images/201310/thumb_img/32_thumb_P_1382884236599.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610163638_12694.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('61','31','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153404_41843.jpg','','images/201310/thumb_img/31_thumb_P_1382884345291.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153404_41843.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('64','19','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153418_56662.jpg','','images/201310/thumb_img/19_thumb_P_1382884435269.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153418_56662.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('66','21','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153404_41843.jpg','','images/201310/thumb_img/21_thumb_P_1382884598650.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610153404_41843.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('71','24','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610162219_64947.jpg','','images/201310/thumb_img/24_thumb_P_1382884782435.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610162219_64947.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('73','20','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610160227_36845.jpg','','images/201310/thumb_img/20_thumb_P_1382884966566.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610160227_36845.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('74','20','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610160240_69453.jpg','','images/201310/thumb_img/20_thumb_P_1382884966552.jpg','http://www.yizhanglian.com/static/public/kindeditor-4.1.7/attached/image/20130610/20130610160240_69453.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('76','33','images/201311/goods_img/33_P_1385063417582.jpg','','images/201311/thumb_img/33_thumb_P_1385063417997.jpg','images/201311/source_img/33_P_1385063417024.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('77','33','images/201311/goods_img/33_P_1385063417056.jpg','','images/201311/thumb_img/33_thumb_P_1385063417992.jpg','images/201311/source_img/33_P_1385063417569.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('78','33','images/201311/goods_img/33_P_1385063418712.jpg','','images/201311/thumb_img/33_thumb_P_1385063418478.jpg','images/201311/source_img/33_P_1385063418203.jpg');
INSERT INTO `yzl_goods_gallery` (`img_id`,`goods_id`,`img_url`,`img_desc`,`thumb_url`,`img_original`) VALUES ('79','33','images/201311/goods_img/33_P_1385063437704.jpg','','images/201311/thumb_img/33_thumb_P_1385063437774.jpg','images/201311/source_img/33_P_1385063437477.jpg');
/*!40000 ALTER TABLE `yzl_goods_gallery` ENABLE KEYS */;


--
-- Create Table `yzl_goods_type`
--

DROP TABLE IF EXISTS `yzl_goods_type`;
CREATE TABLE `yzl_goods_type` (
  `cat_id` smallint(5) unsigned NOT NULL auto_increment,
  `cat_name` varchar(60) NOT NULL default '',
  `enabled` tinyint(1) unsigned NOT NULL default '1',
  `attr_group` varchar(255) NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_goods_type`
--

/*!40000 ALTER TABLE `yzl_goods_type` DISABLE KEYS */;
INSERT INTO `yzl_goods_type` (`cat_id`,`cat_name`,`enabled`,`attr_group`) VALUES ('8','化妆品','1','');
/*!40000 ALTER TABLE `yzl_goods_type` ENABLE KEYS */;


--
-- Create Table `yzl_group_goods`
--

DROP TABLE IF EXISTS `yzl_group_goods`;
CREATE TABLE `yzl_group_goods` (
  `parent_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_price` decimal(10,2) unsigned NOT NULL default '0.00',
  `admin_id` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`parent_id`,`goods_id`,`admin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_group_goods`
--

/*!40000 ALTER TABLE `yzl_group_goods` DISABLE KEYS */;
INSERT INTO `yzl_group_goods` (`parent_id`,`goods_id`,`goods_price`,`admin_id`) VALUES ('9','4','58.00','1');
INSERT INTO `yzl_group_goods` (`parent_id`,`goods_id`,`goods_price`,`admin_id`) VALUES ('9','3','68.00','1');
INSERT INTO `yzl_group_goods` (`parent_id`,`goods_id`,`goods_price`,`admin_id`) VALUES ('9','7','100.00','1');
INSERT INTO `yzl_group_goods` (`parent_id`,`goods_id`,`goods_price`,`admin_id`) VALUES ('14','5','20.00','1');
INSERT INTO `yzl_group_goods` (`parent_id`,`goods_id`,`goods_price`,`admin_id`) VALUES ('14','6','42.00','1');
INSERT INTO `yzl_group_goods` (`parent_id`,`goods_id`,`goods_price`,`admin_id`) VALUES ('14','7','100.00','1');
/*!40000 ALTER TABLE `yzl_group_goods` ENABLE KEYS */;


--
-- Create Table `yzl_keywords`
--

DROP TABLE IF EXISTS `yzl_keywords`;
CREATE TABLE `yzl_keywords` (
  `date` date NOT NULL default '0000-00-00',
  `searchengine` varchar(20) NOT NULL default '',
  `keyword` varchar(90) NOT NULL default '',
  `count` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`date`,`searchengine`,`keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_keywords`
--

/*!40000 ALTER TABLE `yzl_keywords` DISABLE KEYS */;
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-04-21','ecshop','诺基亚','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-04-27','ecshop','智能手机','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-04','ecshop','斤','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-10','ecshop','诺基亚','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-11','ecshop','智能手机','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-11','ecshop','诺基亚','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-12','ecshop','三星','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-12','ecshop','智能手机','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-12','ecshop','p806','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-12','ecshop','诺基亚','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-12','ecshop','夏新','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-18','ecshop','52','2');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2009-05-22','ecshop','p','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-29','ecshop','aa','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-29','ecshop','ff','5');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-29','ecshop','555','2');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-29','ecshop','222','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-29','ecshop','48','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-29','ecshop','8955','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-29','ecshop','44','5');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-29','ecshop','88','20');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-29','ecshop','55','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-30','ecshop','22','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-30','ecshop','12','2');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-30','ecshop','A','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-30','ecshop','P806','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-30','ecshop','4','13');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-30','ecshop','455','4');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-30','ecshop','1','24');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-09-30','ecshop','16499','2');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-10-04','ecshop','55','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-10-08','ecshop','55','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-10-08','ecshop','22','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-10-08','ecshop','w','2');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-10-08','ecshop','d','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-10-11','ecshop','22','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-11-22','ecshop','rtr','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-11-22','ecshop','dfadf','2');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-11-22','ecshop','*','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-11-22','ecshop','ff','4');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-11-22','ecshop','面膜','17');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-11-22','ecshop','f','1');
INSERT INTO `yzl_keywords` (`date`,`searchengine`,`keyword`,`count`) VALUES ('2013-11-22','ecshop','12','1');
/*!40000 ALTER TABLE `yzl_keywords` ENABLE KEYS */;


--
-- Create Table `yzl_link_goods`
--

DROP TABLE IF EXISTS `yzl_link_goods`;
CREATE TABLE `yzl_link_goods` (
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `link_goods_id` mediumint(8) unsigned NOT NULL default '0',
  `is_double` tinyint(1) unsigned NOT NULL default '0',
  `admin_id` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`goods_id`,`link_goods_id`,`admin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_link_goods`
--

/*!40000 ALTER TABLE `yzl_link_goods` DISABLE KEYS */;
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('12','9','0','1');
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('12','10','0','1');
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('12','11','0','1');
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('9','13','1','1');
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('13','9','1','1');
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('14','9','0','1');
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('14','13','0','1');
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('23','9','0','1');
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('13','23','1','1');
INSERT INTO `yzl_link_goods` (`goods_id`,`link_goods_id`,`is_double`,`admin_id`) VALUES ('23','13','1','1');
/*!40000 ALTER TABLE `yzl_link_goods` ENABLE KEYS */;


--
-- Create Table `yzl_mail_templates`
--

DROP TABLE IF EXISTS `yzl_mail_templates`;
CREATE TABLE `yzl_mail_templates` (
  `template_id` tinyint(1) unsigned NOT NULL auto_increment,
  `template_code` varchar(30) NOT NULL default '',
  `is_html` tinyint(1) unsigned NOT NULL default '0',
  `template_subject` varchar(200) NOT NULL default '',
  `template_content` text NOT NULL,
  `last_modify` int(10) unsigned NOT NULL default '0',
  `last_send` int(10) unsigned NOT NULL default '0',
  `type` varchar(10) NOT NULL,
  PRIMARY KEY  (`template_id`),
  UNIQUE KEY `template_code` (`template_code`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_mail_templates`
--

/*!40000 ALTER TABLE `yzl_mail_templates` DISABLE KEYS */;
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('1','send_password','1','密码找回','{$user_name}您好！<br>\n<br>\n您已经进行了密码重置的操作，请点击以下链接(或者复制到您的浏览器):<br>\n<br>\n<a href=\"{$reset_email}\" target=\"_blank\">{$reset_email}</a><br>\n<br>\n以确认您的新密码重置操作！<br>\n<br>\n{$shop_name}<br>\n{$send_date}','1194824789','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('2','order_confirm','0','订单确认通知','亲爱的{$order.consignee}，你好！ \n\n我们已经收到您于 {$order.formated_add_time} 提交的订单，该订单编号为：{$order.order_sn} 请记住这个编号以便日后的查询。\n\n{$shop_name}\n{$sent_date}\n\n\n','1158226370','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('3','deliver_notice','1','发货通知','亲爱的{$order.consignee}。你好！</br></br>\n\n您的订单{$order.order_sn}已于{$send_time}按照您预定的配送方式给您发货了。</br>\n</br>\n{if $order.invoice_no}发货单号是{$order.invoice_no}。</br>{/if}\n</br>\n在您收到货物之后请点击下面的链接确认您已经收到货物：</br>\n<a href=\"{$confirm_url}\" target=\"_blank\">{$confirm_url}</a></br></br>\n如果您还没有收到货物可以点击以下链接给我们留言：</br></br>\n<a href=\"{$send_msg_url}\" target=\"_blank\">{$send_msg_url}</a></br>\n<br>\n再次感谢您对我们的支持。欢迎您的再次光临。 <br>\n<br>\n{$shop_name} </br>\n{$send_date}','1194823291','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('4','order_cancel','0','订单取消','亲爱的{$order.consignee}，你好！ \n\n您的编号为：{$order.order_sn}的订单已取消。\n\n{$shop_name}\n{$send_date}','1156491130','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('5','order_invalid','0','订单无效','亲爱的{$order.consignee}，你好！\n\n您的编号为：{$order.order_sn}的订单无效。\n\n{$shop_name}\n{$send_date}','1156491164','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('6','send_bonus','0','发红包','亲爱的{$user_name}您好！\n\n恭喜您获得了{$count}个红包，金额{if $count > 1}分别{/if}为{$money}\n\n{$shop_name}\n{$send_date}\n','1156491184','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('7','group_buy','1','团购商品','亲爱的{$consignee}，您好！<br>\n<br>\n您于{$order_time}在本店参加团购商品活动，所购买的商品名称为：{$goods_name}，数量：{$goods_number}，订单号为：{$order_sn}，订单金额为：{$order_amount}<br>\n<br>\n此团购商品现在已到结束日期，并达到最低价格，您现在可以对该订单付款。<br>\n<br>\n请点击下面的链接：<br>\n<a href=\"{$shop_url}\" target=\"_blank\">{$shop_url}</a><br>\n<br>\n请尽快登录到用户中心，查看您的订单详情信息。 <br>\n<br>\n{$shop_name} <br>\n<br>\n{$send_date}','1194824668','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('8','register_validate','1','邮件验证','{$user_name}您好！<br><br>\r\n\r\n这封邮件是 {$shop_name} 发送的。你收到这封邮件是为了验证你注册邮件地址是否有效。如果您已经通过验证了，请忽略这封邮件。<br>\r\n请点击以下链接(或者复制到您的浏览器)来验证你的邮件地址:<br>\r\n<a href=\"{$validate_email}\" target=\"_blank\">{$validate_email}</a><br><br>\r\n\r\n{$shop_name}<br>\r\n{$send_date}','1162201031','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('9','virtual_card','0','虚拟卡片','亲爱的{$order.consignee}\r\n你好！您的订单{$order.order_sn}中{$goods.goods_name} 商品的详细信息如下:\r\n{foreach from=$virtual_card item=card}\r\n{if $card.card_sn}卡号：{$card.card_sn}{/if}{if $card.card_password}卡片密码：{$card.card_password}{/if}{if $card.end_date}截至日期：{$card.end_date}{/if}\r\n{/foreach}\r\n再次感谢您对我们的支持。欢迎您的再次光临。\r\n\r\n{$shop_name} \r\n{$send_date}','1162201031','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('10','attention_list','0','关注商品','亲爱的{$user_name}您好~\n\n您关注的商品 : {$goods_name} 最近已经更新,请您查看最新的商品信息\n\n{$goods_url}\r\n\r\n{$shop_name} \r\n{$send_date}','1183851073','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('11','remind_of_new_order','0','新订单通知','亲爱的店长，您好：\n   快来看看吧，又有新订单了。\n    订单号:{$order.order_sn} \n 订单金额:{$order.order_amount}，\n 用户购买商品:{foreach from=$goods_list item=goods_data}{$goods_data.goods_name}(货号:{$goods_data.goods_sn})    {/foreach} \n\n 收货人:{$order.consignee}， \n 收货人地址:{$order.address}，\n 收货人电话:{$order.tel} {$order.mobile}, \n 配送方式:{$order.shipping_name}(费用:{$order.shipping_fee}), \n 付款方式:{$order.pay_name}(费用:{$order.pay_fee})。\n\n               系统提醒\n               {$send_date}','1196239170','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('12','goods_booking','1','缺货回复','亲爱的{$user_name}。你好！</br></br>{$dispose_note}</br></br>您提交的缺货商品链接为</br></br><a href=\"{$goods_link}\" target=\"_blank\">{$goods_name}</a></br><br>{$shop_name} </br>{$send_date}','0','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('13','user_message','1','留言回复','亲爱的{$user_name}。你好！</br></br>对您的留言：</br>{$message_content}</br></br>店主作了如下回复：</br>{$message_note}</br></br>您可以随时回到店中和店主继续沟通。</br>{$shop_name}</br>{$send_date}','0','0','template');
INSERT INTO `yzl_mail_templates` (`template_id`,`template_code`,`is_html`,`template_subject`,`template_content`,`last_modify`,`last_send`,`type`) VALUES ('14','recomment','1','用户评论回复','亲爱的{$user_name}。你好！</br></br>对您的评论：</br>“{$comment}”</br></br>店主作了如下回复：</br>“{$recomment}”</br></br>您可以随时回到店中和店主继续沟通。</br>{$shop_name}</br>{$send_date}','0','0','template');
/*!40000 ALTER TABLE `yzl_mail_templates` ENABLE KEYS */;


--
-- Create Table `yzl_member_price`
--

DROP TABLE IF EXISTS `yzl_member_price`;
CREATE TABLE `yzl_member_price` (
  `price_id` mediumint(8) unsigned NOT NULL auto_increment,
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `user_rank` tinyint(3) NOT NULL default '0',
  `user_price` decimal(10,2) NOT NULL default '0.00',
  PRIMARY KEY  (`price_id`),
  KEY `goods_id` (`goods_id`,`user_rank`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_member_price`
--

/*!40000 ALTER TABLE `yzl_member_price` DISABLE KEYS */;
INSERT INTO `yzl_member_price` (`price_id`,`goods_id`,`user_rank`,`user_price`) VALUES ('1','23','3','3200.00');
INSERT INTO `yzl_member_price` (`price_id`,`goods_id`,`user_rank`,`user_price`) VALUES ('2','23','2','3300.00');
INSERT INTO `yzl_member_price` (`price_id`,`goods_id`,`user_rank`,`user_price`) VALUES ('3','13','3','1100.00');
INSERT INTO `yzl_member_price` (`price_id`,`goods_id`,`user_rank`,`user_price`) VALUES ('4','13','2','1200.00');
/*!40000 ALTER TABLE `yzl_member_price` ENABLE KEYS */;


--
-- Create Table `yzl_nav`
--

DROP TABLE IF EXISTS `yzl_nav`;
CREATE TABLE `yzl_nav` (
  `id` mediumint(8) NOT NULL auto_increment,
  `ctype` varchar(10) default NULL,
  `cid` smallint(5) unsigned default NULL,
  `name` varchar(255) NOT NULL,
  `ifshow` tinyint(1) NOT NULL,
  `vieworder` tinyint(1) NOT NULL,
  `opennew` tinyint(1) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `type` (`type`),
  KEY `ifshow` (`ifshow`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_nav`
--

/*!40000 ALTER TABLE `yzl_nav` DISABLE KEYS */;
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('1',NULL,NULL,'用户中心','1','1','0','#','top');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('2','','0','在线客服','1','2','0','#','top');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('3','','0','花本养肤','1','1','0','page/9','middle');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('4','','0','美颜讲堂','1','2','0','page/myjt','middle');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('5','','0','易颜之法','1','3','0','page/13','middle');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('6','','0','美自天然','1','4','0','page/14','middle');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('7','','0','常见问题','1','1','0','/article.php?id=81','bottom');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('8','','0','联系我们','1','2','0','/article.php?id=82','bottom');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('9','','0','网站地图','1','3','0','/article.php?id=83','bottom');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('10','','0','隐私条款','1','4','0','/article.php?id=84','bottom');
INSERT INTO `yzl_nav` (`id`,`ctype`,`cid`,`name`,`ifshow`,`vieworder`,`opennew`,`url`,`type`) VALUES ('12','a','26','系统帮助','0','8','0','page/26','middle');
/*!40000 ALTER TABLE `yzl_nav` ENABLE KEYS */;


--
-- Create Table `yzl_order_action`
--

DROP TABLE IF EXISTS `yzl_order_action`;
CREATE TABLE `yzl_order_action` (
  `action_id` mediumint(8) unsigned NOT NULL auto_increment,
  `order_id` mediumint(8) unsigned NOT NULL default '0',
  `action_user` varchar(30) NOT NULL default '',
  `order_status` tinyint(1) unsigned NOT NULL default '0',
  `shipping_status` tinyint(1) unsigned NOT NULL default '0',
  `pay_status` tinyint(1) unsigned NOT NULL default '0',
  `action_place` tinyint(1) unsigned NOT NULL default '0',
  `action_note` varchar(255) NOT NULL default '',
  `log_time` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`action_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_order_action`
--

/*!40000 ALTER TABLE `yzl_order_action` DISABLE KEYS */;
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('1','2','admin','1','0','2','0','[售后] 1132','1242142350');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('2','2','admin','1','1','2','0','已经发货，注意接收','1242142389');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('3','1','admin','1','1','2','0','已经发货，注意接收','1242142432');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('4','2','买家','1','2','2','0','','1242142449');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('5','1','买家','1','2','2','0','','1242142451');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('6','3','admin','1','1','2','0','已经发货了，注意接收','1242142589');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('7','3','买家','1','2','2','0','','1242142634');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('8','5','admin','1','3','2','0','','1242142869');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('9','6','admin','3','0','0','0','暂时缺货','1242143337');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('10','7','admin','1','0','0','0','','1242143454');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('11','1','admin','1','2','2','0','[售后] 售后','1242143773');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('12','2','admin','4','0','0','0','质量问题','1242144185');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('13','12','buyer','2','0','0','0','用户取消','1242576313');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('14','13','admin','1','1','0','0','11','1242576445');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('15','14','admin','1','3','2','0','','1242976715');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('16','14','admin','1','1','2','0','已经发货，请接收','1242976740');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('17','15','admin','1','0','0','0','','1245044587');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('18','15','admin','1','0','2','0','已经付款','1245044644');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('19','15','admin','1','4','2','0','','1245044964');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('20','15','admin','1','4','2','0','北京供货商','1245045061');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('21','3','admin','4','0','0','0','不喜欢这个颜色','1245045334');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('22','15','admin','1','1','2','0','','1245045443');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('23','15','admin','4','0','0','0','退货','1245045515');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('24','16','admin','1','4','2','0','上海供货','1245045723');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('25','17','admin','1','1','2','0','','1245048189');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('26','17','admin','4','0','0','0','退货','1245048212');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('27','19','admin','1','1','2','0','','1245384050');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('28','11','admin','1','0','2','0','sd','1381275563');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('29','11','admin','1','3','2','0','','1381275568');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('30','11','admin','5','5','2','0','dddddadad','1381275580');
INSERT INTO `yzl_order_action` (`action_id`,`order_id`,`action_user`,`order_status`,`shipping_status`,`pay_status`,`action_place`,`action_note`,`log_time`) VALUES ('31','11','admin','1','1','2','1','','1381275624');
/*!40000 ALTER TABLE `yzl_order_action` ENABLE KEYS */;


--
-- Create Table `yzl_order_goods`
--

DROP TABLE IF EXISTS `yzl_order_goods`;
CREATE TABLE `yzl_order_goods` (
  `rec_id` mediumint(8) unsigned NOT NULL auto_increment,
  `order_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_name` varchar(120) NOT NULL default '',
  `goods_sn` varchar(60) NOT NULL default '',
  `product_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_number` smallint(5) unsigned NOT NULL default '1',
  `market_price` decimal(10,2) NOT NULL default '0.00',
  `goods_price` decimal(10,2) NOT NULL default '0.00',
  `goods_attr` text NOT NULL,
  `send_number` smallint(5) unsigned NOT NULL default '0',
  `is_real` tinyint(1) unsigned NOT NULL default '0',
  `extension_code` varchar(30) NOT NULL default '',
  `parent_id` mediumint(8) unsigned NOT NULL default '0',
  `is_gift` smallint(5) unsigned NOT NULL default '0',
  `goods_attr_id` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`rec_id`),
  KEY `order_id` (`order_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_order_goods`
--

/*!40000 ALTER TABLE `yzl_order_goods` DISABLE KEYS */;
INSERT INTO `yzl_order_goods` (`rec_id`,`order_id`,`goods_id`,`goods_name`,`goods_sn`,`product_id`,`goods_number`,`market_price`,`goods_price`,`goods_attr`,`send_number`,`is_real`,`extension_code`,`parent_id`,`is_gift`,`goods_attr_id`) VALUES ('13','11','23','诺基亚N96','ECS000023','0','1','4440.00','3800.00','附加配件: 原装电池 [+100]','1','1','','0','0','');
/*!40000 ALTER TABLE `yzl_order_goods` ENABLE KEYS */;


--
-- Create Table `yzl_order_info`
--

DROP TABLE IF EXISTS `yzl_order_info`;
CREATE TABLE `yzl_order_info` (
  `order_id` mediumint(8) unsigned NOT NULL auto_increment,
  `order_sn` varchar(20) NOT NULL default '',
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `order_status` tinyint(1) unsigned NOT NULL default '0',
  `shipping_status` tinyint(1) unsigned NOT NULL default '0',
  `pay_status` tinyint(1) unsigned NOT NULL default '0',
  `consignee` varchar(60) NOT NULL default '',
  `country` smallint(5) unsigned NOT NULL default '0',
  `province` smallint(5) unsigned NOT NULL default '0',
  `city` smallint(5) unsigned NOT NULL default '0',
  `district` smallint(5) unsigned NOT NULL default '0',
  `address` varchar(255) NOT NULL default '',
  `zipcode` varchar(60) NOT NULL default '',
  `tel` varchar(60) NOT NULL default '',
  `mobile` varchar(60) NOT NULL default '',
  `email` varchar(60) NOT NULL default '',
  `best_time` varchar(120) NOT NULL default '',
  `sign_building` varchar(120) NOT NULL default '',
  `postscript` varchar(255) NOT NULL default '',
  `shipping_id` tinyint(3) NOT NULL default '0',
  `shipping_name` varchar(120) NOT NULL default '',
  `pay_id` tinyint(3) NOT NULL default '0',
  `pay_name` varchar(120) NOT NULL default '',
  `how_oos` varchar(120) NOT NULL default '',
  `how_surplus` varchar(120) NOT NULL default '',
  `pack_name` varchar(120) NOT NULL default '',
  `card_name` varchar(120) NOT NULL default '',
  `card_message` varchar(255) NOT NULL default '',
  `inv_payee` varchar(120) NOT NULL default '',
  `inv_content` varchar(120) NOT NULL default '',
  `goods_amount` decimal(10,2) NOT NULL default '0.00',
  `shipping_fee` decimal(10,2) NOT NULL default '0.00',
  `insure_fee` decimal(10,2) NOT NULL default '0.00',
  `pay_fee` decimal(10,2) NOT NULL default '0.00',
  `pack_fee` decimal(10,2) NOT NULL default '0.00',
  `card_fee` decimal(10,2) NOT NULL default '0.00',
  `money_paid` decimal(10,2) NOT NULL default '0.00',
  `surplus` decimal(10,2) NOT NULL default '0.00',
  `integral` int(10) unsigned NOT NULL default '0',
  `integral_money` decimal(10,2) NOT NULL default '0.00',
  `bonus` decimal(10,2) NOT NULL default '0.00',
  `order_amount` decimal(10,2) NOT NULL default '0.00',
  `from_ad` smallint(5) NOT NULL default '0',
  `referer` varchar(255) NOT NULL default '',
  `add_time` int(10) unsigned NOT NULL default '0',
  `confirm_time` int(10) unsigned NOT NULL default '0',
  `pay_time` int(10) unsigned NOT NULL default '0',
  `shipping_time` int(10) unsigned NOT NULL default '0',
  `pack_id` tinyint(3) unsigned NOT NULL default '0',
  `card_id` tinyint(3) unsigned NOT NULL default '0',
  `bonus_id` mediumint(8) unsigned NOT NULL default '0',
  `invoice_no` varchar(255) NOT NULL default '',
  `extension_code` varchar(30) NOT NULL default '',
  `extension_id` mediumint(8) unsigned NOT NULL default '0',
  `to_buyer` varchar(255) NOT NULL default '',
  `pay_note` varchar(255) NOT NULL default '',
  `agency_id` smallint(5) unsigned NOT NULL,
  `inv_type` varchar(60) NOT NULL,
  `tax` decimal(10,2) NOT NULL,
  `is_separate` tinyint(1) NOT NULL default '0',
  `parent_id` mediumint(8) unsigned NOT NULL default '0',
  `discount` decimal(10,2) NOT NULL,
  PRIMARY KEY  (`order_id`),
  UNIQUE KEY `order_sn` (`order_sn`),
  KEY `user_id` (`user_id`),
  KEY `order_status` (`order_status`),
  KEY `shipping_status` (`shipping_status`),
  KEY `pay_status` (`pay_status`),
  KEY `shipping_id` (`shipping_id`),
  KEY `pay_id` (`pay_id`),
  KEY `extension_code` (`extension_code`,`extension_id`),
  KEY `agency_id` (`agency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_order_info`
--

/*!40000 ALTER TABLE `yzl_order_info` DISABLE KEYS */;
INSERT INTO `yzl_order_info` (`order_id`,`order_sn`,`user_id`,`order_status`,`shipping_status`,`pay_status`,`consignee`,`country`,`province`,`city`,`district`,`address`,`zipcode`,`tel`,`mobile`,`email`,`best_time`,`sign_building`,`postscript`,`shipping_id`,`shipping_name`,`pay_id`,`pay_name`,`how_oos`,`how_surplus`,`pack_name`,`card_name`,`card_message`,`inv_payee`,`inv_content`,`goods_amount`,`shipping_fee`,`insure_fee`,`pay_fee`,`pack_fee`,`card_fee`,`money_paid`,`surplus`,`integral`,`integral_money`,`bonus`,`order_amount`,`from_ad`,`referer`,`add_time`,`confirm_time`,`pay_time`,`shipping_time`,`pack_id`,`card_id`,`bonus_id`,`invoice_no`,`extension_code`,`extension_id`,`to_buyer`,`pay_note`,`agency_id`,`inv_type`,`tax`,`is_separate`,`parent_id`,`discount`) VALUES ('11','2009051264945','0','5','1','2','林小姐','1','2','52','500','中关村海兴大厦','','135474510','','linzi@116.com','','','','3','城际快递','2','银行汇款/转帐','','','','','','','','3800.00','10.00','0.00','0.00','0.00','0.00','3810.00','0.00','0','0.00','0.00','0.00','0','管理员添加','1242144250','1242144363','1381275563','1381275624','0','0','0','','','0','','','0','','0.00','0','0','0.00');
/*!40000 ALTER TABLE `yzl_order_info` ENABLE KEYS */;


--
-- Create Table `yzl_pack`
--

DROP TABLE IF EXISTS `yzl_pack`;
CREATE TABLE `yzl_pack` (
  `pack_id` tinyint(3) unsigned NOT NULL auto_increment,
  `pack_name` varchar(120) NOT NULL default '',
  `pack_img` varchar(255) NOT NULL default '',
  `pack_fee` decimal(6,2) unsigned NOT NULL default '0.00',
  `free_money` smallint(5) unsigned NOT NULL default '0',
  `pack_desc` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`pack_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_pack`
--

/*!40000 ALTER TABLE `yzl_pack` DISABLE KEYS */;
INSERT INTO `yzl_pack` (`pack_id`,`pack_name`,`pack_img`,`pack_fee`,`free_money`,`pack_desc`) VALUES ('1','精品包装','1242108360911825791.jpg','5.00','800','精品包装，尽心为您设计一份不一样的礼物');
/*!40000 ALTER TABLE `yzl_pack` ENABLE KEYS */;


--
-- Create Table `yzl_package_goods`
--

DROP TABLE IF EXISTS `yzl_package_goods`;
CREATE TABLE `yzl_package_goods` (
  `package_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `product_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_number` smallint(5) unsigned NOT NULL default '1',
  `admin_id` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`package_id`,`goods_id`,`admin_id`,`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_package_goods`
--

/*!40000 ALTER TABLE `yzl_package_goods` DISABLE KEYS */;
INSERT INTO `yzl_package_goods` (`package_id`,`goods_id`,`product_id`,`goods_number`,`admin_id`) VALUES ('5','6','0','1','1');
INSERT INTO `yzl_package_goods` (`package_id`,`goods_id`,`product_id`,`goods_number`,`admin_id`) VALUES ('5','5','0','1','1');
INSERT INTO `yzl_package_goods` (`package_id`,`goods_id`,`product_id`,`goods_number`,`admin_id`) VALUES ('6','4','0','1','1');
INSERT INTO `yzl_package_goods` (`package_id`,`goods_id`,`product_id`,`goods_number`,`admin_id`) VALUES ('6','7','0','1','1');
INSERT INTO `yzl_package_goods` (`package_id`,`goods_id`,`product_id`,`goods_number`,`admin_id`) VALUES ('6','32','0','1','1');
INSERT INTO `yzl_package_goods` (`package_id`,`goods_id`,`product_id`,`goods_number`,`admin_id`) VALUES ('5','31','0','1','1');
/*!40000 ALTER TABLE `yzl_package_goods` ENABLE KEYS */;


--
-- Create Table `yzl_pay_log`
--

DROP TABLE IF EXISTS `yzl_pay_log`;
CREATE TABLE `yzl_pay_log` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `order_id` mediumint(8) unsigned NOT NULL default '0',
  `order_amount` decimal(10,2) unsigned NOT NULL,
  `order_type` tinyint(1) unsigned NOT NULL default '0',
  `is_paid` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_pay_log`
--

/*!40000 ALTER TABLE `yzl_pay_log` DISABLE KEYS */;
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('1','1','0.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('2','2','0.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('3','3','0.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('4','4','0.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('5','5','0.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('6','6','35.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('7','7','2198.10','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('8','8','638.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('9','9','2015.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('10','10','0.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('11','11','3810.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('12','12','253.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('13','13','975.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('14','14','0.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('15','15','17054.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('16','16','0.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('17','17','0.00','0','0');
INSERT INTO `yzl_pay_log` (`log_id`,`order_id`,`order_amount`,`order_type`,`is_paid`) VALUES ('18','18','0.00','0','0');
/*!40000 ALTER TABLE `yzl_pay_log` ENABLE KEYS */;


--
-- Create Table `yzl_payment`
--

DROP TABLE IF EXISTS `yzl_payment`;
CREATE TABLE `yzl_payment` (
  `pay_id` tinyint(3) unsigned NOT NULL auto_increment,
  `pay_code` varchar(20) NOT NULL default '',
  `pay_name` varchar(120) NOT NULL default '',
  `pay_fee` varchar(10) NOT NULL default '0',
  `pay_desc` text NOT NULL,
  `pay_order` tinyint(3) unsigned NOT NULL default '0',
  `pay_config` text NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL default '0',
  `is_cod` tinyint(1) unsigned NOT NULL default '0',
  `is_online` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`pay_id`),
  UNIQUE KEY `pay_code` (`pay_code`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_payment`
--

/*!40000 ALTER TABLE `yzl_payment` DISABLE KEYS */;
INSERT INTO `yzl_payment` (`pay_id`,`pay_code`,`pay_name`,`pay_fee`,`pay_desc`,`pay_order`,`pay_config`,`enabled`,`is_cod`,`is_online`) VALUES ('1','balance','余额支付','0','使用帐户余额支付。只有会员才能使用，通过设置信用额度，可以透支。','0','a:0:{}','1','0','1');
INSERT INTO `yzl_payment` (`pay_id`,`pay_code`,`pay_name`,`pay_fee`,`pay_desc`,`pay_order`,`pay_config`,`enabled`,`is_cod`,`is_online`) VALUES ('2','bank','银行汇款/转帐','0','银行名称\n收款人信息：全称 ××× ；帐号或地址 ××× ；开户行 ×××。\n注意事项：办理电汇时，请在电汇单“汇款用途”一栏处注明您的订单号。','0','a:0:{}','1','0','0');
INSERT INTO `yzl_payment` (`pay_id`,`pay_code`,`pay_name`,`pay_fee`,`pay_desc`,`pay_order`,`pay_config`,`enabled`,`is_cod`,`is_online`) VALUES ('3','cod','货到付款','0','开通城市：×××\n货到付款区域：×××','0','a:0:{}','1','1','0');
/*!40000 ALTER TABLE `yzl_payment` ENABLE KEYS */;


--
-- Create Table `yzl_plugins`
--

DROP TABLE IF EXISTS `yzl_plugins`;
CREATE TABLE `yzl_plugins` (
  `code` varchar(30) NOT NULL default '',
  `version` varchar(10) NOT NULL default '',
  `library` varchar(255) NOT NULL default '',
  `assign` tinyint(1) unsigned NOT NULL default '0',
  `install_date` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_plugins`
--

/*!40000 ALTER TABLE `yzl_plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_plugins` ENABLE KEYS */;


--
-- Create Table `yzl_products`
--

DROP TABLE IF EXISTS `yzl_products`;
CREATE TABLE `yzl_products` (
  `product_id` mediumint(8) unsigned NOT NULL auto_increment,
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_attr` varchar(50) default NULL,
  `product_sn` varchar(60) default NULL,
  `product_number` smallint(5) unsigned default '0',
  PRIMARY KEY  (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_products`
--

/*!40000 ALTER TABLE `yzl_products` DISABLE KEYS */;
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('1','32','163','','100');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('2','24','167','','100');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('3','23','175','','100');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('4','21','188','','20');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('5','20','194','','13');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('6','17','201','','1');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('7','14','213','','4');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('8','13','217','','8');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('9','10','239','','6');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('10','10','240','','12');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('11','9','227','','12');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('12','9','226','','3');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('13','8','231','','17');
INSERT INTO `yzl_products` (`product_id`,`goods_id`,`goods_attr`,`product_sn`,`product_number`) VALUES ('14','1','237','','1');
/*!40000 ALTER TABLE `yzl_products` ENABLE KEYS */;


--
-- Create Table `yzl_reg_extend_info`
--

DROP TABLE IF EXISTS `yzl_reg_extend_info`;
CREATE TABLE `yzl_reg_extend_info` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `user_id` mediumint(8) unsigned NOT NULL,
  `reg_field_id` int(10) unsigned NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_reg_extend_info`
--

/*!40000 ALTER TABLE `yzl_reg_extend_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_reg_extend_info` ENABLE KEYS */;


--
-- Create Table `yzl_reg_fields`
--

DROP TABLE IF EXISTS `yzl_reg_fields`;
CREATE TABLE `yzl_reg_fields` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `reg_field_name` varchar(60) NOT NULL,
  `dis_order` tinyint(3) unsigned NOT NULL default '100',
  `display` tinyint(1) unsigned NOT NULL default '1',
  `type` tinyint(1) unsigned NOT NULL default '0',
  `is_need` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_reg_fields`
--

/*!40000 ALTER TABLE `yzl_reg_fields` DISABLE KEYS */;
INSERT INTO `yzl_reg_fields` (`id`,`reg_field_name`,`dis_order`,`display`,`type`,`is_need`) VALUES ('1','MSN','0','0','1','0');
INSERT INTO `yzl_reg_fields` (`id`,`reg_field_name`,`dis_order`,`display`,`type`,`is_need`) VALUES ('2','QQ','0','1','1','0');
INSERT INTO `yzl_reg_fields` (`id`,`reg_field_name`,`dis_order`,`display`,`type`,`is_need`) VALUES ('3','办公电话','0','0','1','0');
INSERT INTO `yzl_reg_fields` (`id`,`reg_field_name`,`dis_order`,`display`,`type`,`is_need`) VALUES ('4','家庭电话','0','0','1','0');
INSERT INTO `yzl_reg_fields` (`id`,`reg_field_name`,`dis_order`,`display`,`type`,`is_need`) VALUES ('5','手机','0','1','1','0');
INSERT INTO `yzl_reg_fields` (`id`,`reg_field_name`,`dis_order`,`display`,`type`,`is_need`) VALUES ('6','密码找回问题','0','1','1','0');
INSERT INTO `yzl_reg_fields` (`id`,`reg_field_name`,`dis_order`,`display`,`type`,`is_need`) VALUES ('100','姓名','100','1','0','0');
/*!40000 ALTER TABLE `yzl_reg_fields` ENABLE KEYS */;


--
-- Create Table `yzl_region`
--

DROP TABLE IF EXISTS `yzl_region`;
CREATE TABLE `yzl_region` (
  `region_id` smallint(5) unsigned NOT NULL auto_increment,
  `parent_id` smallint(5) unsigned NOT NULL default '0',
  `region_name` varchar(120) NOT NULL default '',
  `region_type` tinyint(1) NOT NULL default '2',
  `agency_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`region_id`),
  KEY `parent_id` (`parent_id`),
  KEY `region_type` (`region_type`),
  KEY `agency_id` (`agency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3409 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_region`
--

/*!40000 ALTER TABLE `yzl_region` DISABLE KEYS */;
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1','0','中国','0','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2','1','北京','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3','1','安徽','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('4','1','福建','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('5','1','甘肃','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('6','1','广东','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('7','1','广西','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('8','1','贵州','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('9','1','海南','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('10','1','河北','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('11','1','河南','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('12','1','黑龙江','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('13','1','湖北','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('14','1','湖南','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('15','1','吉林','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('16','1','江苏','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('17','1','江西','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('18','1','辽宁','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('19','1','内蒙古','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('20','1','宁夏','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('21','1','青海','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('22','1','山东','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('23','1','山西','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('24','1','陕西','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('25','1','上海','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('26','1','四川','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('27','1','天津','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('28','1','西藏','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('29','1','新疆','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('30','1','云南','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('31','1','浙江','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('32','1','重庆','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('33','1','香港','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('34','1','澳门','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('35','1','台湾','1','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('36','3','安庆','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('37','3','蚌埠','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('38','3','巢湖','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('39','3','池州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('40','3','滁州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('41','3','阜阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('42','3','淮北','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('43','3','淮南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('44','3','黄山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('45','3','六安','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('46','3','马鞍山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('47','3','宿州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('48','3','铜陵','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('49','3','芜湖','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('50','3','宣城','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('51','3','亳州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('52','2','北京','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('53','4','福州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('54','4','龙岩','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('55','4','南平','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('56','4','宁德','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('57','4','莆田','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('58','4','泉州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('59','4','三明','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('60','4','厦门','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('61','4','漳州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('62','5','兰州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('63','5','白银','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('64','5','定西','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('65','5','甘南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('66','5','嘉峪关','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('67','5','金昌','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('68','5','酒泉','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('69','5','临夏','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('70','5','陇南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('71','5','平凉','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('72','5','庆阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('73','5','天水','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('74','5','武威','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('75','5','张掖','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('76','6','广州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('77','6','深圳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('78','6','潮州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('79','6','东莞','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('80','6','佛山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('81','6','河源','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('82','6','惠州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('83','6','江门','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('84','6','揭阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('85','6','茂名','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('86','6','梅州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('87','6','清远','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('88','6','汕头','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('89','6','汕尾','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('90','6','韶关','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('91','6','阳江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('92','6','云浮','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('93','6','湛江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('94','6','肇庆','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('95','6','中山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('96','6','珠海','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('97','7','南宁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('98','7','桂林','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('99','7','百色','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('100','7','北海','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('101','7','崇左','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('102','7','防城港','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('103','7','贵港','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('104','7','河池','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('105','7','贺州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('106','7','来宾','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('107','7','柳州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('108','7','钦州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('109','7','梧州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('110','7','玉林','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('111','8','贵阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('112','8','安顺','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('113','8','毕节','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('114','8','六盘水','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('115','8','黔东南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('116','8','黔南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('117','8','黔西南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('118','8','铜仁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('119','8','遵义','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('120','9','海口','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('121','9','三亚','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('122','9','白沙','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('123','9','保亭','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('124','9','昌江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('125','9','澄迈县','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('126','9','定安县','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('127','9','东方','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('128','9','乐东','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('129','9','临高县','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('130','9','陵水','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('131','9','琼海','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('132','9','琼中','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('133','9','屯昌县','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('134','9','万宁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('135','9','文昌','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('136','9','五指山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('137','9','儋州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('138','10','石家庄','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('139','10','保定','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('140','10','沧州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('141','10','承德','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('142','10','邯郸','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('143','10','衡水','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('144','10','廊坊','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('145','10','秦皇岛','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('146','10','唐山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('147','10','邢台','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('148','10','张家口','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('149','11','郑州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('150','11','洛阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('151','11','开封','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('152','11','安阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('153','11','鹤壁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('154','11','济源','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('155','11','焦作','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('156','11','南阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('157','11','平顶山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('158','11','三门峡','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('159','11','商丘','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('160','11','新乡','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('161','11','信阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('162','11','许昌','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('163','11','周口','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('164','11','驻马店','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('165','11','漯河','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('166','11','濮阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('167','12','哈尔滨','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('168','12','大庆','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('169','12','大兴安岭','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('170','12','鹤岗','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('171','12','黑河','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('172','12','鸡西','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('173','12','佳木斯','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('174','12','牡丹江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('175','12','七台河','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('176','12','齐齐哈尔','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('177','12','双鸭山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('178','12','绥化','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('179','12','伊春','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('180','13','武汉','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('181','13','仙桃','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('182','13','鄂州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('183','13','黄冈','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('184','13','黄石','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('185','13','荆门','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('186','13','荆州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('187','13','潜江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('188','13','神农架林区','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('189','13','十堰','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('190','13','随州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('191','13','天门','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('192','13','咸宁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('193','13','襄樊','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('194','13','孝感','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('195','13','宜昌','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('196','13','恩施','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('197','14','长沙','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('198','14','张家界','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('199','14','常德','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('200','14','郴州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('201','14','衡阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('202','14','怀化','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('203','14','娄底','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('204','14','邵阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('205','14','湘潭','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('206','14','湘西','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('207','14','益阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('208','14','永州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('209','14','岳阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('210','14','株洲','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('211','15','长春','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('212','15','吉林','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('213','15','白城','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('214','15','白山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('215','15','辽源','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('216','15','四平','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('217','15','松原','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('218','15','通化','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('219','15','延边','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('220','16','南京','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('221','16','苏州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('222','16','无锡','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('223','16','常州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('224','16','淮安','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('225','16','连云港','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('226','16','南通','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('227','16','宿迁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('228','16','泰州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('229','16','徐州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('230','16','盐城','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('231','16','扬州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('232','16','镇江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('233','17','南昌','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('234','17','抚州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('235','17','赣州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('236','17','吉安','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('237','17','景德镇','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('238','17','九江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('239','17','萍乡','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('240','17','上饶','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('241','17','新余','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('242','17','宜春','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('243','17','鹰潭','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('244','18','沈阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('245','18','大连','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('246','18','鞍山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('247','18','本溪','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('248','18','朝阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('249','18','丹东','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('250','18','抚顺','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('251','18','阜新','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('252','18','葫芦岛','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('253','18','锦州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('254','18','辽阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('255','18','盘锦','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('256','18','铁岭','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('257','18','营口','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('258','19','呼和浩特','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('259','19','阿拉善盟','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('260','19','巴彦淖尔盟','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('261','19','包头','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('262','19','赤峰','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('263','19','鄂尔多斯','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('264','19','呼伦贝尔','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('265','19','通辽','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('266','19','乌海','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('267','19','乌兰察布市','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('268','19','锡林郭勒盟','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('269','19','兴安盟','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('270','20','银川','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('271','20','固原','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('272','20','石嘴山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('273','20','吴忠','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('274','20','中卫','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('275','21','西宁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('276','21','果洛','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('277','21','海北','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('278','21','海东','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('279','21','海南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('280','21','海西','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('281','21','黄南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('282','21','玉树','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('283','22','济南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('284','22','青岛','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('285','22','滨州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('286','22','德州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('287','22','东营','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('288','22','菏泽','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('289','22','济宁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('290','22','莱芜','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('291','22','聊城','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('292','22','临沂','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('293','22','日照','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('294','22','泰安','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('295','22','威海','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('296','22','潍坊','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('297','22','烟台','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('298','22','枣庄','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('299','22','淄博','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('300','23','太原','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('301','23','长治','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('302','23','大同','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('303','23','晋城','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('304','23','晋中','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('305','23','临汾','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('306','23','吕梁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('307','23','朔州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('308','23','忻州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('309','23','阳泉','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('310','23','运城','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('311','24','西安','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('312','24','安康','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('313','24','宝鸡','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('314','24','汉中','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('315','24','商洛','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('316','24','铜川','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('317','24','渭南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('318','24','咸阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('319','24','延安','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('320','24','榆林','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('321','25','上海','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('322','26','成都','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('323','26','绵阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('324','26','阿坝','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('325','26','巴中','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('326','26','达州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('327','26','德阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('328','26','甘孜','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('329','26','广安','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('330','26','广元','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('331','26','乐山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('332','26','凉山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('333','26','眉山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('334','26','南充','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('335','26','内江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('336','26','攀枝花','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('337','26','遂宁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('338','26','雅安','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('339','26','宜宾','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('340','26','资阳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('341','26','自贡','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('342','26','泸州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('343','27','天津','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('344','28','拉萨','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('345','28','阿里','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('346','28','昌都','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('347','28','林芝','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('348','28','那曲','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('349','28','日喀则','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('350','28','山南','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('351','29','乌鲁木齐','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('352','29','阿克苏','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('353','29','阿拉尔','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('354','29','巴音郭楞','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('355','29','博尔塔拉','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('356','29','昌吉','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('357','29','哈密','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('358','29','和田','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('359','29','喀什','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('360','29','克拉玛依','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('361','29','克孜勒苏','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('362','29','石河子','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('363','29','图木舒克','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('364','29','吐鲁番','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('365','29','五家渠','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('366','29','伊犁','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('367','30','昆明','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('368','30','怒江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('369','30','普洱','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('370','30','丽江','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('371','30','保山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('372','30','楚雄','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('373','30','大理','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('374','30','德宏','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('375','30','迪庆','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('376','30','红河','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('377','30','临沧','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('378','30','曲靖','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('379','30','文山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('380','30','西双版纳','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('381','30','玉溪','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('382','30','昭通','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('383','31','杭州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('384','31','湖州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('385','31','嘉兴','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('386','31','金华','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('387','31','丽水','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('388','31','宁波','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('389','31','绍兴','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('390','31','台州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('391','31','温州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('392','31','舟山','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('393','31','衢州','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('394','32','重庆','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('395','33','香港','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('396','34','澳门','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('397','35','台湾','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('398','36','迎江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('399','36','大观区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('400','36','宜秀区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('401','36','桐城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('402','36','怀宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('403','36','枞阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('404','36','潜山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('405','36','太湖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('406','36','宿松县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('407','36','望江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('408','36','岳西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('409','37','中市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('410','37','东市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('411','37','西市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('412','37','郊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('413','37','怀远县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('414','37','五河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('415','37','固镇县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('416','38','居巢区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('417','38','庐江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('418','38','无为县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('419','38','含山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('420','38','和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('421','39','贵池区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('422','39','东至县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('423','39','石台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('424','39','青阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('425','40','琅琊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('426','40','南谯区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('427','40','天长市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('428','40','明光市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('429','40','来安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('430','40','全椒县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('431','40','定远县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('432','40','凤阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('433','41','蚌山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('434','41','龙子湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('435','41','禹会区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('436','41','淮上区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('437','41','颍州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('438','41','颍东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('439','41','颍泉区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('440','41','界首市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('441','41','临泉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('442','41','太和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('443','41','阜南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('444','41','颖上县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('445','42','相山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('446','42','杜集区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('447','42','烈山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('448','42','濉溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('449','43','田家庵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('450','43','大通区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('451','43','谢家集区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('452','43','八公山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('453','43','潘集区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('454','43','凤台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('455','44','屯溪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('456','44','黄山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('457','44','徽州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('458','44','歙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('459','44','休宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('460','44','黟县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('461','44','祁门县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('462','45','金安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('463','45','裕安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('464','45','寿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('465','45','霍邱县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('466','45','舒城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('467','45','金寨县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('468','45','霍山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('469','46','雨山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('470','46','花山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('471','46','金家庄区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('472','46','当涂县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('473','47','埇桥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('474','47','砀山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('475','47','萧县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('476','47','灵璧县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('477','47','泗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('478','48','铜官山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('479','48','狮子山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('480','48','郊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('481','48','铜陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('482','49','镜湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('483','49','弋江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('484','49','鸠江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('485','49','三山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('486','49','芜湖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('487','49','繁昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('488','49','南陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('489','50','宣州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('490','50','宁国市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('491','50','郎溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('492','50','广德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('493','50','泾县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('494','50','绩溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('495','50','旌德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('496','51','涡阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('497','51','蒙城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('498','51','利辛县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('499','51','谯城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('500','52','东城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('501','52','西城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('502','52','海淀区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('503','52','朝阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('504','52','崇文区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('505','52','宣武区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('506','52','丰台区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('507','52','石景山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('508','52','房山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('509','52','门头沟区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('510','52','通州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('511','52','顺义区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('512','52','昌平区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('513','52','怀柔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('514','52','平谷区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('515','52','大兴区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('516','52','密云县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('517','52','延庆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('518','53','鼓楼区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('519','53','台江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('520','53','仓山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('521','53','马尾区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('522','53','晋安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('523','53','福清市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('524','53','长乐市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('525','53','闽侯县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('526','53','连江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('527','53','罗源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('528','53','闽清县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('529','53','永泰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('530','53','平潭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('531','54','新罗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('532','54','漳平市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('533','54','长汀县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('534','54','永定县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('535','54','上杭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('536','54','武平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('537','54','连城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('538','55','延平区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('539','55','邵武市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('540','55','武夷山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('541','55','建瓯市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('542','55','建阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('543','55','顺昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('544','55','浦城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('545','55','光泽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('546','55','松溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('547','55','政和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('548','56','蕉城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('549','56','福安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('550','56','福鼎市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('551','56','霞浦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('552','56','古田县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('553','56','屏南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('554','56','寿宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('555','56','周宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('556','56','柘荣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('557','57','城厢区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('558','57','涵江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('559','57','荔城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('560','57','秀屿区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('561','57','仙游县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('562','58','鲤城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('563','58','丰泽区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('564','58','洛江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('565','58','清濛开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('566','58','泉港区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('567','58','石狮市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('568','58','晋江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('569','58','南安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('570','58','惠安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('571','58','安溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('572','58','永春县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('573','58','德化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('574','58','金门县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('575','59','梅列区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('576','59','三元区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('577','59','永安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('578','59','明溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('579','59','清流县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('580','59','宁化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('581','59','大田县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('582','59','尤溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('583','59','沙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('584','59','将乐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('585','59','泰宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('586','59','建宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('587','60','思明区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('588','60','海沧区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('589','60','湖里区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('590','60','集美区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('591','60','同安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('592','60','翔安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('593','61','芗城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('594','61','龙文区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('595','61','龙海市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('596','61','云霄县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('597','61','漳浦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('598','61','诏安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('599','61','长泰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('600','61','东山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('601','61','南靖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('602','61','平和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('603','61','华安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('604','62','皋兰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('605','62','城关区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('606','62','七里河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('607','62','西固区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('608','62','安宁区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('609','62','红古区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('610','62','永登县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('611','62','榆中县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('612','63','白银区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('613','63','平川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('614','63','会宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('615','63','景泰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('616','63','靖远县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('617','64','临洮县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('618','64','陇西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('619','64','通渭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('620','64','渭源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('621','64','漳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('622','64','岷县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('623','64','安定区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('624','64','安定区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('625','65','合作市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('626','65','临潭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('627','65','卓尼县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('628','65','舟曲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('629','65','迭部县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('630','65','玛曲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('631','65','碌曲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('632','65','夏河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('633','66','嘉峪关市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('634','67','金川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('635','67','永昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('636','68','肃州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('637','68','玉门市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('638','68','敦煌市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('639','68','金塔县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('640','68','瓜州县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('641','68','肃北','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('642','68','阿克塞','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('643','69','临夏市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('644','69','临夏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('645','69','康乐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('646','69','永靖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('647','69','广河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('648','69','和政县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('649','69','东乡族自治县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('650','69','积石山','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('651','70','成县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('652','70','徽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('653','70','康县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('654','70','礼县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('655','70','两当县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('656','70','文县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('657','70','西和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('658','70','宕昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('659','70','武都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('660','71','崇信县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('661','71','华亭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('662','71','静宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('663','71','灵台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('664','71','崆峒区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('665','71','庄浪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('666','71','泾川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('667','72','合水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('668','72','华池县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('669','72','环县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('670','72','宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('671','72','庆城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('672','72','西峰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('673','72','镇原县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('674','72','正宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('675','73','甘谷县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('676','73','秦安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('677','73','清水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('678','73','秦州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('679','73','麦积区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('680','73','武山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('681','73','张家川','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('682','74','古浪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('683','74','民勤县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('684','74','天祝','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('685','74','凉州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('686','75','高台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('687','75','临泽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('688','75','民乐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('689','75','山丹县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('690','75','肃南','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('691','75','甘州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('692','76','从化市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('693','76','天河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('694','76','东山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('695','76','白云区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('696','76','海珠区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('697','76','荔湾区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('698','76','越秀区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('699','76','黄埔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('700','76','番禺区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('701','76','花都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('702','76','增城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('703','76','从化区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('704','76','市郊','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('705','77','福田区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('706','77','罗湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('707','77','南山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('708','77','宝安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('709','77','龙岗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('710','77','盐田区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('711','78','湘桥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('712','78','潮安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('713','78','饶平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('714','79','南城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('715','79','东城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('716','79','万江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('717','79','莞城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('718','79','石龙镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('719','79','虎门镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('720','79','麻涌镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('721','79','道滘镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('722','79','石碣镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('723','79','沙田镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('724','79','望牛墩镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('725','79','洪梅镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('726','79','茶山镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('727','79','寮步镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('728','79','大岭山镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('729','79','大朗镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('730','79','黄江镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('731','79','樟木头','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('732','79','凤岗镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('733','79','塘厦镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('734','79','谢岗镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('735','79','厚街镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('736','79','清溪镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('737','79','常平镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('738','79','桥头镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('739','79','横沥镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('740','79','东坑镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('741','79','企石镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('742','79','石排镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('743','79','长安镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('744','79','中堂镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('745','79','高埗镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('746','80','禅城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('747','80','南海区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('748','80','顺德区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('749','80','三水区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('750','80','高明区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('751','81','东源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('752','81','和平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('753','81','源城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('754','81','连平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('755','81','龙川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('756','81','紫金县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('757','82','惠阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('758','82','惠城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('759','82','大亚湾','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('760','82','博罗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('761','82','惠东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('762','82','龙门县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('763','83','江海区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('764','83','蓬江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('765','83','新会区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('766','83','台山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('767','83','开平市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('768','83','鹤山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('769','83','恩平市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('770','84','榕城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('771','84','普宁市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('772','84','揭东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('773','84','揭西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('774','84','惠来县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('775','85','茂南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('776','85','茂港区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('777','85','高州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('778','85','化州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('779','85','信宜市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('780','85','电白县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('781','86','梅县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('782','86','梅江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('783','86','兴宁市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('784','86','大埔县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('785','86','丰顺县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('786','86','五华县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('787','86','平远县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('788','86','蕉岭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('789','87','清城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('790','87','英德市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('791','87','连州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('792','87','佛冈县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('793','87','阳山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('794','87','清新县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('795','87','连山','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('796','87','连南','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('797','88','南澳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('798','88','潮阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('799','88','澄海区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('800','88','龙湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('801','88','金平区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('802','88','濠江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('803','88','潮南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('804','89','城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('805','89','陆丰市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('806','89','海丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('807','89','陆河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('808','90','曲江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('809','90','浈江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('810','90','武江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('811','90','曲江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('812','90','乐昌市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('813','90','南雄市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('814','90','始兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('815','90','仁化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('816','90','翁源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('817','90','新丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('818','90','乳源','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('819','91','江城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('820','91','阳春市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('821','91','阳西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('822','91','阳东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('823','92','云城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('824','92','罗定市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('825','92','新兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('826','92','郁南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('827','92','云安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('828','93','赤坎区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('829','93','霞山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('830','93','坡头区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('831','93','麻章区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('832','93','廉江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('833','93','雷州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('834','93','吴川市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('835','93','遂溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('836','93','徐闻县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('837','94','肇庆市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('838','94','高要市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('839','94','四会市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('840','94','广宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('841','94','怀集县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('842','94','封开县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('843','94','德庆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('844','95','石岐街道','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('845','95','东区街道','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('846','95','西区街道','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('847','95','环城街道','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('848','95','中山港街道','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('849','95','五桂山街道','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('850','96','香洲区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('851','96','斗门区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('852','96','金湾区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('853','97','邕宁区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('854','97','青秀区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('855','97','兴宁区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('856','97','良庆区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('857','97','西乡塘区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('858','97','江南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('859','97','武鸣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('860','97','隆安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('861','97','马山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('862','97','上林县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('863','97','宾阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('864','97','横县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('865','98','秀峰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('866','98','叠彩区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('867','98','象山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('868','98','七星区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('869','98','雁山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('870','98','阳朔县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('871','98','临桂县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('872','98','灵川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('873','98','全州县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('874','98','平乐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('875','98','兴安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('876','98','灌阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('877','98','荔浦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('878','98','资源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('879','98','永福县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('880','98','龙胜','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('881','98','恭城','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('882','99','右江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('883','99','凌云县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('884','99','平果县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('885','99','西林县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('886','99','乐业县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('887','99','德保县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('888','99','田林县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('889','99','田阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('890','99','靖西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('891','99','田东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('892','99','那坡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('893','99','隆林','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('894','100','海城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('895','100','银海区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('896','100','铁山港区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('897','100','合浦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('898','101','江州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('899','101','凭祥市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('900','101','宁明县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('901','101','扶绥县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('902','101','龙州县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('903','101','大新县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('904','101','天等县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('905','102','港口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('906','102','防城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('907','102','东兴市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('908','102','上思县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('909','103','港北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('910','103','港南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('911','103','覃塘区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('912','103','桂平市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('913','103','平南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('914','104','金城江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('915','104','宜州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('916','104','天峨县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('917','104','凤山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('918','104','南丹县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('919','104','东兰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('920','104','都安','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('921','104','罗城','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('922','104','巴马','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('923','104','环江','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('924','104','大化','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('925','105','八步区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('926','105','钟山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('927','105','昭平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('928','105','富川','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('929','106','兴宾区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('930','106','合山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('931','106','象州县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('932','106','武宣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('933','106','忻城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('934','106','金秀','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('935','107','城中区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('936','107','鱼峰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('937','107','柳北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('938','107','柳南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('939','107','柳江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('940','107','柳城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('941','107','鹿寨县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('942','107','融安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('943','107','融水','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('944','107','三江','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('945','108','钦南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('946','108','钦北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('947','108','灵山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('948','108','浦北县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('949','109','万秀区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('950','109','蝶山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('951','109','长洲区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('952','109','岑溪市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('953','109','苍梧县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('954','109','藤县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('955','109','蒙山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('956','110','玉州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('957','110','北流市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('958','110','容县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('959','110','陆川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('960','110','博白县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('961','110','兴业县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('962','111','南明区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('963','111','云岩区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('964','111','花溪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('965','111','乌当区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('966','111','白云区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('967','111','小河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('968','111','金阳新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('969','111','新天园区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('970','111','清镇市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('971','111','开阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('972','111','修文县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('973','111','息烽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('974','112','西秀区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('975','112','关岭','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('976','112','镇宁','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('977','112','紫云','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('978','112','平坝县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('979','112','普定县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('980','113','毕节市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('981','113','大方县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('982','113','黔西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('983','113','金沙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('984','113','织金县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('985','113','纳雍县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('986','113','赫章县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('987','113','威宁','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('988','114','钟山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('989','114','六枝特区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('990','114','水城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('991','114','盘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('992','115','凯里市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('993','115','黄平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('994','115','施秉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('995','115','三穗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('996','115','镇远县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('997','115','岑巩县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('998','115','天柱县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('999','115','锦屏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1000','115','剑河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1001','115','台江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1002','115','黎平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1003','115','榕江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1004','115','从江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1005','115','雷山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1006','115','麻江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1007','115','丹寨县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1008','116','都匀市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1009','116','福泉市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1010','116','荔波县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1011','116','贵定县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1012','116','瓮安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1013','116','独山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1014','116','平塘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1015','116','罗甸县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1016','116','长顺县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1017','116','龙里县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1018','116','惠水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1019','116','三都','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1020','117','兴义市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1021','117','兴仁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1022','117','普安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1023','117','晴隆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1024','117','贞丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1025','117','望谟县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1026','117','册亨县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1027','117','安龙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1028','118','铜仁市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1029','118','江口县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1030','118','石阡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1031','118','思南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1032','118','德江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1033','118','玉屏','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1034','118','印江','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1035','118','沿河','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1036','118','松桃','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1037','118','万山特区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1038','119','红花岗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1039','119','务川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1040','119','道真县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1041','119','汇川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1042','119','赤水市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1043','119','仁怀市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1044','119','遵义县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1045','119','桐梓县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1046','119','绥阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1047','119','正安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1048','119','凤冈县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1049','119','湄潭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1050','119','余庆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1051','119','习水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1052','119','道真','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1053','119','务川','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1054','120','秀英区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1055','120','龙华区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1056','120','琼山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1057','120','美兰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1058','137','市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1059','137','洋浦开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1060','137','那大镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1061','137','王五镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1062','137','雅星镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1063','137','大成镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1064','137','中和镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1065','137','峨蔓镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1066','137','南丰镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1067','137','白马井镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1068','137','兰洋镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1069','137','和庆镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1070','137','海头镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1071','137','排浦镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1072','137','东成镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1073','137','光村镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1074','137','木棠镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1075','137','新州镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1076','137','三都镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1077','137','其他','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1078','138','长安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1079','138','桥东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1080','138','桥西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1081','138','新华区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1082','138','裕华区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1083','138','井陉矿区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1084','138','高新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1085','138','辛集市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1086','138','藁城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1087','138','晋州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1088','138','新乐市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1089','138','鹿泉市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1090','138','井陉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1091','138','正定县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1092','138','栾城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1093','138','行唐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1094','138','灵寿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1095','138','高邑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1096','138','深泽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1097','138','赞皇县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1098','138','无极县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1099','138','平山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1100','138','元氏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1101','138','赵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1102','139','新市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1103','139','南市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1104','139','北市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1105','139','涿州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1106','139','定州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1107','139','安国市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1108','139','高碑店市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1109','139','满城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1110','139','清苑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1111','139','涞水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1112','139','阜平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1113','139','徐水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1114','139','定兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1115','139','唐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1116','139','高阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1117','139','容城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1118','139','涞源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1119','139','望都县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1120','139','安新县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1121','139','易县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1122','139','曲阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1123','139','蠡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1124','139','顺平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1125','139','博野县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1126','139','雄县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1127','140','运河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1128','140','新华区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1129','140','泊头市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1130','140','任丘市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1131','140','黄骅市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1132','140','河间市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1133','140','沧县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1134','140','青县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1135','140','东光县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1136','140','海兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1137','140','盐山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1138','140','肃宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1139','140','南皮县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1140','140','吴桥县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1141','140','献县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1142','140','孟村','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1143','141','双桥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1144','141','双滦区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1145','141','鹰手营子矿区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1146','141','承德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1147','141','兴隆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1148','141','平泉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1149','141','滦平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1150','141','隆化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1151','141','丰宁','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1152','141','宽城','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1153','141','围场','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1154','142','从台区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1155','142','复兴区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1156','142','邯山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1157','142','峰峰矿区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1158','142','武安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1159','142','邯郸县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1160','142','临漳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1161','142','成安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1162','142','大名县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1163','142','涉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1164','142','磁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1165','142','肥乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1166','142','永年县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1167','142','邱县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1168','142','鸡泽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1169','142','广平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1170','142','馆陶县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1171','142','魏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1172','142','曲周县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1173','143','桃城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1174','143','冀州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1175','143','深州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1176','143','枣强县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1177','143','武邑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1178','143','武强县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1179','143','饶阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1180','143','安平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1181','143','故城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1182','143','景县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1183','143','阜城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1184','144','安次区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1185','144','广阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1186','144','霸州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1187','144','三河市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1188','144','固安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1189','144','永清县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1190','144','香河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1191','144','大城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1192','144','文安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1193','144','大厂','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1194','145','海港区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1195','145','山海关区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1196','145','北戴河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1197','145','昌黎县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1198','145','抚宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1199','145','卢龙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1200','145','青龙','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1201','146','路北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1202','146','路南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1203','146','古冶区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1204','146','开平区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1205','146','丰南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1206','146','丰润区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1207','146','遵化市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1208','146','迁安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1209','146','滦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1210','146','滦南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1211','146','乐亭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1212','146','迁西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1213','146','玉田县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1214','146','唐海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1215','147','桥东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1216','147','桥西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1217','147','南宫市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1218','147','沙河市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1219','147','邢台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1220','147','临城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1221','147','内丘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1222','147','柏乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1223','147','隆尧县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1224','147','任县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1225','147','南和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1226','147','宁晋县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1227','147','巨鹿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1228','147','新河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1229','147','广宗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1230','147','平乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1231','147','威县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1232','147','清河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1233','147','临西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1234','148','桥西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1235','148','桥东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1236','148','宣化区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1237','148','下花园区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1238','148','宣化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1239','148','张北县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1240','148','康保县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1241','148','沽源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1242','148','尚义县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1243','148','蔚县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1244','148','阳原县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1245','148','怀安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1246','148','万全县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1247','148','怀来县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1248','148','涿鹿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1249','148','赤城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1250','148','崇礼县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1251','149','金水区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1252','149','邙山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1253','149','二七区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1254','149','管城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1255','149','中原区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1256','149','上街区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1257','149','惠济区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1258','149','郑东新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1259','149','经济技术开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1260','149','高新开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1261','149','出口加工区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1262','149','巩义市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1263','149','荥阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1264','149','新密市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1265','149','新郑市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1266','149','登封市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1267','149','中牟县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1268','150','西工区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1269','150','老城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1270','150','涧西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1271','150','瀍河回族区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1272','150','洛龙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1273','150','吉利区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1274','150','偃师市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1275','150','孟津县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1276','150','新安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1277','150','栾川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1278','150','嵩县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1279','150','汝阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1280','150','宜阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1281','150','洛宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1282','150','伊川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1283','151','鼓楼区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1284','151','龙亭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1285','151','顺河回族区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1286','151','金明区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1287','151','禹王台区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1288','151','杞县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1289','151','通许县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1290','151','尉氏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1291','151','开封县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1292','151','兰考县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1293','152','北关区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1294','152','文峰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1295','152','殷都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1296','152','龙安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1297','152','林州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1298','152','安阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1299','152','汤阴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1300','152','滑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1301','152','内黄县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1302','153','淇滨区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1303','153','山城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1304','153','鹤山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1305','153','浚县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1306','153','淇县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1307','154','济源市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1308','155','解放区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1309','155','中站区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1310','155','马村区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1311','155','山阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1312','155','沁阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1313','155','孟州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1314','155','修武县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1315','155','博爱县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1316','155','武陟县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1317','155','温县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1318','156','卧龙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1319','156','宛城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1320','156','邓州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1321','156','南召县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1322','156','方城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1323','156','西峡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1324','156','镇平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1325','156','内乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1326','156','淅川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1327','156','社旗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1328','156','唐河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1329','156','新野县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1330','156','桐柏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1331','157','新华区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1332','157','卫东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1333','157','湛河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1334','157','石龙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1335','157','舞钢市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1336','157','汝州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1337','157','宝丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1338','157','叶县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1339','157','鲁山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1340','157','郏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1341','158','湖滨区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1342','158','义马市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1343','158','灵宝市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1344','158','渑池县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1345','158','陕县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1346','158','卢氏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1347','159','梁园区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1348','159','睢阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1349','159','永城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1350','159','民权县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1351','159','睢县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1352','159','宁陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1353','159','虞城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1354','159','柘城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1355','159','夏邑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1356','160','卫滨区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1357','160','红旗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1358','160','凤泉区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1359','160','牧野区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1360','160','卫辉市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1361','160','辉县市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1362','160','新乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1363','160','获嘉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1364','160','原阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1365','160','延津县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1366','160','封丘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1367','160','长垣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1368','161','浉河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1369','161','平桥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1370','161','罗山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1371','161','光山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1372','161','新县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1373','161','商城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1374','161','固始县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1375','161','潢川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1376','161','淮滨县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1377','161','息县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1378','162','魏都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1379','162','禹州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1380','162','长葛市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1381','162','许昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1382','162','鄢陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1383','162','襄城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1384','163','川汇区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1385','163','项城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1386','163','扶沟县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1387','163','西华县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1388','163','商水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1389','163','沈丘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1390','163','郸城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1391','163','淮阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1392','163','太康县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1393','163','鹿邑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1394','164','驿城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1395','164','西平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1396','164','上蔡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1397','164','平舆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1398','164','正阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1399','164','确山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1400','164','泌阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1401','164','汝南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1402','164','遂平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1403','164','新蔡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1404','165','郾城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1405','165','源汇区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1406','165','召陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1407','165','舞阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1408','165','临颍县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1409','166','华龙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1410','166','清丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1411','166','南乐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1412','166','范县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1413','166','台前县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1414','166','濮阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1415','167','道里区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1416','167','南岗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1417','167','动力区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1418','167','平房区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1419','167','香坊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1420','167','太平区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1421','167','道外区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1422','167','阿城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1423','167','呼兰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1424','167','松北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1425','167','尚志市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1426','167','双城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1427','167','五常市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1428','167','方正县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1429','167','宾县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1430','167','依兰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1431','167','巴彦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1432','167','通河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1433','167','木兰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1434','167','延寿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1435','168','萨尔图区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1436','168','红岗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1437','168','龙凤区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1438','168','让胡路区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1439','168','大同区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1440','168','肇州县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1441','168','肇源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1442','168','林甸县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1443','168','杜尔伯特','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1444','169','呼玛县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1445','169','漠河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1446','169','塔河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1447','170','兴山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1448','170','工农区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1449','170','南山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1450','170','兴安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1451','170','向阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1452','170','东山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1453','170','萝北县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1454','170','绥滨县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1455','171','爱辉区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1456','171','五大连池市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1457','171','北安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1458','171','嫩江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1459','171','逊克县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1460','171','孙吴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1461','172','鸡冠区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1462','172','恒山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1463','172','城子河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1464','172','滴道区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1465','172','梨树区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1466','172','虎林市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1467','172','密山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1468','172','鸡东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1469','173','前进区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1470','173','郊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1471','173','向阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1472','173','东风区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1473','173','同江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1474','173','富锦市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1475','173','桦南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1476','173','桦川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1477','173','汤原县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1478','173','抚远县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1479','174','爱民区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1480','174','东安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1481','174','阳明区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1482','174','西安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1483','174','绥芬河市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1484','174','海林市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1485','174','宁安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1486','174','穆棱市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1487','174','东宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1488','174','林口县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1489','175','桃山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1490','175','新兴区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1491','175','茄子河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1492','175','勃利县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1493','176','龙沙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1494','176','昂昂溪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1495','176','铁峰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1496','176','建华区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1497','176','富拉尔基区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1498','176','碾子山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1499','176','梅里斯达斡尔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1500','176','讷河市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1501','176','龙江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1502','176','依安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1503','176','泰来县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1504','176','甘南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1505','176','富裕县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1506','176','克山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1507','176','克东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1508','176','拜泉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1509','177','尖山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1510','177','岭东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1511','177','四方台区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1512','177','宝山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1513','177','集贤县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1514','177','友谊县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1515','177','宝清县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1516','177','饶河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1517','178','北林区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1518','178','安达市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1519','178','肇东市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1520','178','海伦市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1521','178','望奎县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1522','178','兰西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1523','178','青冈县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1524','178','庆安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1525','178','明水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1526','178','绥棱县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1527','179','伊春区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1528','179','带岭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1529','179','南岔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1530','179','金山屯区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1531','179','西林区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1532','179','美溪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1533','179','乌马河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1534','179','翠峦区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1535','179','友好区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1536','179','上甘岭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1537','179','五营区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1538','179','红星区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1539','179','新青区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1540','179','汤旺河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1541','179','乌伊岭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1542','179','铁力市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1543','179','嘉荫县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1544','180','江岸区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1545','180','武昌区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1546','180','江汉区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1547','180','硚口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1548','180','汉阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1549','180','青山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1550','180','洪山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1551','180','东西湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1552','180','汉南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1553','180','蔡甸区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1554','180','江夏区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1555','180','黄陂区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1556','180','新洲区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1557','180','经济开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1558','181','仙桃市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1559','182','鄂城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1560','182','华容区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1561','182','梁子湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1562','183','黄州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1563','183','麻城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1564','183','武穴市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1565','183','团风县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1566','183','红安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1567','183','罗田县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1568','183','英山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1569','183','浠水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1570','183','蕲春县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1571','183','黄梅县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1572','184','黄石港区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1573','184','西塞山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1574','184','下陆区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1575','184','铁山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1576','184','大冶市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1577','184','阳新县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1578','185','东宝区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1579','185','掇刀区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1580','185','钟祥市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1581','185','京山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1582','185','沙洋县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1583','186','沙市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1584','186','荆州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1585','186','石首市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1586','186','洪湖市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1587','186','松滋市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1588','186','公安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1589','186','监利县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1590','186','江陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1591','187','潜江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1592','188','神农架林区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1593','189','张湾区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1594','189','茅箭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1595','189','丹江口市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1596','189','郧县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1597','189','郧西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1598','189','竹山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1599','189','竹溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1600','189','房县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1601','190','曾都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1602','190','广水市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1603','191','天门市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1604','192','咸安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1605','192','赤壁市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1606','192','嘉鱼县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1607','192','通城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1608','192','崇阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1609','192','通山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1610','193','襄城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1611','193','樊城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1612','193','襄阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1613','193','老河口市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1614','193','枣阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1615','193','宜城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1616','193','南漳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1617','193','谷城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1618','193','保康县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1619','194','孝南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1620','194','应城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1621','194','安陆市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1622','194','汉川市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1623','194','孝昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1624','194','大悟县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1625','194','云梦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1626','195','长阳','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1627','195','五峰','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1628','195','西陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1629','195','伍家岗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1630','195','点军区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1631','195','猇亭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1632','195','夷陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1633','195','宜都市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1634','195','当阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1635','195','枝江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1636','195','远安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1637','195','兴山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1638','195','秭归县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1639','196','恩施市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1640','196','利川市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1641','196','建始县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1642','196','巴东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1643','196','宣恩县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1644','196','咸丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1645','196','来凤县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1646','196','鹤峰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1647','197','岳麓区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1648','197','芙蓉区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1649','197','天心区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1650','197','开福区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1651','197','雨花区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1652','197','开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1653','197','浏阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1654','197','长沙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1655','197','望城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1656','197','宁乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1657','198','永定区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1658','198','武陵源区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1659','198','慈利县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1660','198','桑植县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1661','199','武陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1662','199','鼎城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1663','199','津市市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1664','199','安乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1665','199','汉寿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1666','199','澧县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1667','199','临澧县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1668','199','桃源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1669','199','石门县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1670','200','北湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1671','200','苏仙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1672','200','资兴市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1673','200','桂阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1674','200','宜章县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1675','200','永兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1676','200','嘉禾县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1677','200','临武县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1678','200','汝城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1679','200','桂东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1680','200','安仁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1681','201','雁峰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1682','201','珠晖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1683','201','石鼓区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1684','201','蒸湘区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1685','201','南岳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1686','201','耒阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1687','201','常宁市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1688','201','衡阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1689','201','衡南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1690','201','衡山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1691','201','衡东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1692','201','祁东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1693','202','鹤城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1694','202','靖州','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1695','202','麻阳','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1696','202','通道','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1697','202','新晃','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1698','202','芷江','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1699','202','沅陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1700','202','辰溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1701','202','溆浦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1702','202','中方县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1703','202','会同县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1704','202','洪江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1705','203','娄星区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1706','203','冷水江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1707','203','涟源市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1708','203','双峰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1709','203','新化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1710','204','城步','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1711','204','双清区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1712','204','大祥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1713','204','北塔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1714','204','武冈市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1715','204','邵东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1716','204','新邵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1717','204','邵阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1718','204','隆回县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1719','204','洞口县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1720','204','绥宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1721','204','新宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1722','205','岳塘区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1723','205','雨湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1724','205','湘乡市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1725','205','韶山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1726','205','湘潭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1727','206','吉首市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1728','206','泸溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1729','206','凤凰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1730','206','花垣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1731','206','保靖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1732','206','古丈县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1733','206','永顺县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1734','206','龙山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1735','207','赫山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1736','207','资阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1737','207','沅江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1738','207','南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1739','207','桃江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1740','207','安化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1741','208','江华','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1742','208','冷水滩区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1743','208','零陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1744','208','祁阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1745','208','东安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1746','208','双牌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1747','208','道县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1748','208','江永县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1749','208','宁远县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1750','208','蓝山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1751','208','新田县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1752','209','岳阳楼区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1753','209','君山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1754','209','云溪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1755','209','汨罗市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1756','209','临湘市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1757','209','岳阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1758','209','华容县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1759','209','湘阴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1760','209','平江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1761','210','天元区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1762','210','荷塘区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1763','210','芦淞区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1764','210','石峰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1765','210','醴陵市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1766','210','株洲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1767','210','攸县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1768','210','茶陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1769','210','炎陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1770','211','朝阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1771','211','宽城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1772','211','二道区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1773','211','南关区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1774','211','绿园区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1775','211','双阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1776','211','净月潭开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1777','211','高新技术开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1778','211','经济技术开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1779','211','汽车产业开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1780','211','德惠市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1781','211','九台市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1782','211','榆树市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1783','211','农安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1784','212','船营区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1785','212','昌邑区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1786','212','龙潭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1787','212','丰满区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1788','212','蛟河市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1789','212','桦甸市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1790','212','舒兰市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1791','212','磐石市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1792','212','永吉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1793','213','洮北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1794','213','洮南市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1795','213','大安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1796','213','镇赉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1797','213','通榆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1798','214','江源区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1799','214','八道江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1800','214','长白','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1801','214','临江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1802','214','抚松县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1803','214','靖宇县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1804','215','龙山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1805','215','西安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1806','215','东丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1807','215','东辽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1808','216','铁西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1809','216','铁东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1810','216','伊通','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1811','216','公主岭市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1812','216','双辽市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1813','216','梨树县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1814','217','前郭尔罗斯','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1815','217','宁江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1816','217','长岭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1817','217','乾安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1818','217','扶余县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1819','218','东昌区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1820','218','二道江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1821','218','梅河口市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1822','218','集安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1823','218','通化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1824','218','辉南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1825','218','柳河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1826','219','延吉市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1827','219','图们市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1828','219','敦化市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1829','219','珲春市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1830','219','龙井市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1831','219','和龙市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1832','219','安图县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1833','219','汪清县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1834','220','玄武区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1835','220','鼓楼区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1836','220','白下区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1837','220','建邺区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1838','220','秦淮区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1839','220','雨花台区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1840','220','下关区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1841','220','栖霞区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1842','220','浦口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1843','220','江宁区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1844','220','六合区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1845','220','溧水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1846','220','高淳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1847','221','沧浪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1848','221','金阊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1849','221','平江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1850','221','虎丘区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1851','221','吴中区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1852','221','相城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1853','221','园区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1854','221','新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1855','221','常熟市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1856','221','张家港市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1857','221','玉山镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1858','221','巴城镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1859','221','周市镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1860','221','陆家镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1861','221','花桥镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1862','221','淀山湖镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1863','221','张浦镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1864','221','周庄镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1865','221','千灯镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1866','221','锦溪镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1867','221','开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1868','221','吴江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1869','221','太仓市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1870','222','崇安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1871','222','北塘区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1872','222','南长区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1873','222','锡山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1874','222','惠山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1875','222','滨湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1876','222','新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1877','222','江阴市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1878','222','宜兴市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1879','223','天宁区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1880','223','钟楼区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1881','223','戚墅堰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1882','223','郊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1883','223','新北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1884','223','武进区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1885','223','溧阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1886','223','金坛市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1887','224','清河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1888','224','清浦区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1889','224','楚州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1890','224','淮阴区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1891','224','涟水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1892','224','洪泽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1893','224','盱眙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1894','224','金湖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1895','225','新浦区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1896','225','连云区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1897','225','海州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1898','225','赣榆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1899','225','东海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1900','225','灌云县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1901','225','灌南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1902','226','崇川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1903','226','港闸区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1904','226','经济开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1905','226','启东市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1906','226','如皋市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1907','226','通州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1908','226','海门市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1909','226','海安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1910','226','如东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1911','227','宿城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1912','227','宿豫区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1913','227','宿豫县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1914','227','沭阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1915','227','泗阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1916','227','泗洪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1917','228','海陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1918','228','高港区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1919','228','兴化市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1920','228','靖江市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1921','228','泰兴市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1922','228','姜堰市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1923','229','云龙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1924','229','鼓楼区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1925','229','九里区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1926','229','贾汪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1927','229','泉山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1928','229','新沂市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1929','229','邳州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1930','229','丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1931','229','沛县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1932','229','铜山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1933','229','睢宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1934','230','城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1935','230','亭湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1936','230','盐都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1937','230','盐都县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1938','230','东台市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1939','230','大丰市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1940','230','响水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1941','230','滨海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1942','230','阜宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1943','230','射阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1944','230','建湖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1945','231','广陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1946','231','维扬区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1947','231','邗江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1948','231','仪征市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1949','231','高邮市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1950','231','江都市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1951','231','宝应县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1952','232','京口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1953','232','润州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1954','232','丹徒区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1955','232','丹阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1956','232','扬中市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1957','232','句容市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1958','233','东湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1959','233','西湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1960','233','青云谱区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1961','233','湾里区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1962','233','青山湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1963','233','红谷滩新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1964','233','昌北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1965','233','高新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1966','233','南昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1967','233','新建县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1968','233','安义县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1969','233','进贤县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1970','234','临川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1971','234','南城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1972','234','黎川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1973','234','南丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1974','234','崇仁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1975','234','乐安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1976','234','宜黄县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1977','234','金溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1978','234','资溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1979','234','东乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1980','234','广昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1981','235','章贡区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1982','235','于都县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1983','235','瑞金市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1984','235','南康市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1985','235','赣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1986','235','信丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1987','235','大余县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1988','235','上犹县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1989','235','崇义县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1990','235','安远县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1991','235','龙南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1992','235','定南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1993','235','全南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1994','235','宁都县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1995','235','兴国县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1996','235','会昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1997','235','寻乌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1998','235','石城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('1999','236','安福县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2000','236','吉州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2001','236','青原区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2002','236','井冈山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2003','236','吉安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2004','236','吉水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2005','236','峡江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2006','236','新干县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2007','236','永丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2008','236','泰和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2009','236','遂川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2010','236','万安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2011','236','永新县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2012','237','珠山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2013','237','昌江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2014','237','乐平市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2015','237','浮梁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2016','238','浔阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2017','238','庐山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2018','238','瑞昌市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2019','238','九江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2020','238','武宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2021','238','修水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2022','238','永修县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2023','238','德安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2024','238','星子县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2025','238','都昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2026','238','湖口县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2027','238','彭泽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2028','239','安源区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2029','239','湘东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2030','239','莲花县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2031','239','芦溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2032','239','上栗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2033','240','信州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2034','240','德兴市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2035','240','上饶县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2036','240','广丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2037','240','玉山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2038','240','铅山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2039','240','横峰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2040','240','弋阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2041','240','余干县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2042','240','波阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2043','240','万年县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2044','240','婺源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2045','241','渝水区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2046','241','分宜县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2047','242','袁州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2048','242','丰城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2049','242','樟树市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2050','242','高安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2051','242','奉新县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2052','242','万载县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2053','242','上高县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2054','242','宜丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2055','242','靖安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2056','242','铜鼓县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2057','243','月湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2058','243','贵溪市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2059','243','余江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2060','244','沈河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2061','244','皇姑区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2062','244','和平区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2063','244','大东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2064','244','铁西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2065','244','苏家屯区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2066','244','东陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2067','244','沈北新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2068','244','于洪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2069','244','浑南新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2070','244','新民市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2071','244','辽中县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2072','244','康平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2073','244','法库县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2074','245','西岗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2075','245','中山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2076','245','沙河口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2077','245','甘井子区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2078','245','旅顺口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2079','245','金州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2080','245','开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2081','245','瓦房店市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2082','245','普兰店市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2083','245','庄河市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2084','245','长海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2085','246','铁东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2086','246','铁西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2087','246','立山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2088','246','千山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2089','246','岫岩','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2090','246','海城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2091','246','台安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2092','247','本溪','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2093','247','平山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2094','247','明山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2095','247','溪湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2096','247','南芬区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2097','247','桓仁','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2098','248','双塔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2099','248','龙城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2100','248','喀喇沁左翼蒙古族自治县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2101','248','北票市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2102','248','凌源市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2103','248','朝阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2104','248','建平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2105','249','振兴区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2106','249','元宝区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2107','249','振安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2108','249','宽甸','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2109','249','东港市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2110','249','凤城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2111','250','顺城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2112','250','新抚区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2113','250','东洲区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2114','250','望花区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2115','250','清原','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2116','250','新宾','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2117','250','抚顺县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2118','251','阜新','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2119','251','海州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2120','251','新邱区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2121','251','太平区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2122','251','清河门区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2123','251','细河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2124','251','彰武县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2125','252','龙港区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2126','252','南票区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2127','252','连山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2128','252','兴城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2129','252','绥中县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2130','252','建昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2131','253','太和区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2132','253','古塔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2133','253','凌河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2134','253','凌海市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2135','253','北镇市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2136','253','黑山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2137','253','义县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2138','254','白塔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2139','254','文圣区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2140','254','宏伟区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2141','254','太子河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2142','254','弓长岭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2143','254','灯塔市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2144','254','辽阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2145','255','双台子区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2146','255','兴隆台区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2147','255','大洼县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2148','255','盘山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2149','256','银州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2150','256','清河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2151','256','调兵山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2152','256','开原市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2153','256','铁岭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2154','256','西丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2155','256','昌图县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2156','257','站前区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2157','257','西市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2158','257','鲅鱼圈区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2159','257','老边区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2160','257','盖州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2161','257','大石桥市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2162','258','回民区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2163','258','玉泉区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2164','258','新城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2165','258','赛罕区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2166','258','清水河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2167','258','土默特左旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2168','258','托克托县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2169','258','和林格尔县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2170','258','武川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2171','259','阿拉善左旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2172','259','阿拉善右旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2173','259','额济纳旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2174','260','临河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2175','260','五原县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2176','260','磴口县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2177','260','乌拉特前旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2178','260','乌拉特中旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2179','260','乌拉特后旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2180','260','杭锦后旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2181','261','昆都仑区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2182','261','青山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2183','261','东河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2184','261','九原区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2185','261','石拐区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2186','261','白云矿区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2187','261','土默特右旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2188','261','固阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2189','261','达尔罕茂明安联合旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2190','262','红山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2191','262','元宝山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2192','262','松山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2193','262','阿鲁科尔沁旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2194','262','巴林左旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2195','262','巴林右旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2196','262','林西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2197','262','克什克腾旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2198','262','翁牛特旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2199','262','喀喇沁旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2200','262','宁城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2201','262','敖汉旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2202','263','东胜区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2203','263','达拉特旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2204','263','准格尔旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2205','263','鄂托克前旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2206','263','鄂托克旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2207','263','杭锦旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2208','263','乌审旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2209','263','伊金霍洛旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2210','264','海拉尔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2211','264','莫力达瓦','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2212','264','满洲里市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2213','264','牙克石市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2214','264','扎兰屯市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2215','264','额尔古纳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2216','264','根河市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2217','264','阿荣旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2218','264','鄂伦春自治旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2219','264','鄂温克族自治旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2220','264','陈巴尔虎旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2221','264','新巴尔虎左旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2222','264','新巴尔虎右旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2223','265','科尔沁区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2224','265','霍林郭勒市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2225','265','科尔沁左翼中旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2226','265','科尔沁左翼后旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2227','265','开鲁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2228','265','库伦旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2229','265','奈曼旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2230','265','扎鲁特旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2231','266','海勃湾区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2232','266','乌达区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2233','266','海南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2234','267','化德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2235','267','集宁区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2236','267','丰镇市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2237','267','卓资县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2238','267','商都县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2239','267','兴和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2240','267','凉城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2241','267','察哈尔右翼前旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2242','267','察哈尔右翼中旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2243','267','察哈尔右翼后旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2244','267','四子王旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2245','268','二连浩特市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2246','268','锡林浩特市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2247','268','阿巴嘎旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2248','268','苏尼特左旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2249','268','苏尼特右旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2250','268','东乌珠穆沁旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2251','268','西乌珠穆沁旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2252','268','太仆寺旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2253','268','镶黄旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2254','268','正镶白旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2255','268','正蓝旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2256','268','多伦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2257','269','乌兰浩特市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2258','269','阿尔山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2259','269','科尔沁右翼前旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2260','269','科尔沁右翼中旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2261','269','扎赉特旗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2262','269','突泉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2263','270','西夏区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2264','270','金凤区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2265','270','兴庆区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2266','270','灵武市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2267','270','永宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2268','270','贺兰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2269','271','原州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2270','271','海原县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2271','271','西吉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2272','271','隆德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2273','271','泾源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2274','271','彭阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2275','272','惠农县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2276','272','大武口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2277','272','惠农区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2278','272','陶乐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2279','272','平罗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2280','273','利通区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2281','273','中卫县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2282','273','青铜峡市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2283','273','中宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2284','273','盐池县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2285','273','同心县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2286','274','沙坡头区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2287','274','海原县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2288','274','中宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2289','275','城中区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2290','275','城东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2291','275','城西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2292','275','城北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2293','275','湟中县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2294','275','湟源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2295','275','大通','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2296','276','玛沁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2297','276','班玛县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2298','276','甘德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2299','276','达日县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2300','276','久治县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2301','276','玛多县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2302','277','海晏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2303','277','祁连县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2304','277','刚察县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2305','277','门源','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2306','278','平安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2307','278','乐都县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2308','278','民和','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2309','278','互助','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2310','278','化隆','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2311','278','循化','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2312','279','共和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2313','279','同德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2314','279','贵德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2315','279','兴海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2316','279','贵南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2317','280','德令哈市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2318','280','格尔木市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2319','280','乌兰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2320','280','都兰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2321','280','天峻县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2322','281','同仁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2323','281','尖扎县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2324','281','泽库县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2325','281','河南蒙古族自治县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2326','282','玉树县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2327','282','杂多县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2328','282','称多县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2329','282','治多县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2330','282','囊谦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2331','282','曲麻莱县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2332','283','市中区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2333','283','历下区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2334','283','天桥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2335','283','槐荫区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2336','283','历城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2337','283','长清区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2338','283','章丘市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2339','283','平阴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2340','283','济阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2341','283','商河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2342','284','市南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2343','284','市北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2344','284','城阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2345','284','四方区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2346','284','李沧区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2347','284','黄岛区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2348','284','崂山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2349','284','胶州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2350','284','即墨市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2351','284','平度市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2352','284','胶南市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2353','284','莱西市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2354','285','滨城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2355','285','惠民县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2356','285','阳信县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2357','285','无棣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2358','285','沾化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2359','285','博兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2360','285','邹平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2361','286','德城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2362','286','陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2363','286','乐陵市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2364','286','禹城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2365','286','宁津县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2366','286','庆云县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2367','286','临邑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2368','286','齐河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2369','286','平原县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2370','286','夏津县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2371','286','武城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2372','287','东营区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2373','287','河口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2374','287','垦利县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2375','287','利津县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2376','287','广饶县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2377','288','牡丹区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2378','288','曹县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2379','288','单县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2380','288','成武县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2381','288','巨野县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2382','288','郓城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2383','288','鄄城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2384','288','定陶县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2385','288','东明县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2386','289','市中区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2387','289','任城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2388','289','曲阜市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2389','289','兖州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2390','289','邹城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2391','289','微山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2392','289','鱼台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2393','289','金乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2394','289','嘉祥县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2395','289','汶上县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2396','289','泗水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2397','289','梁山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2398','290','莱城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2399','290','钢城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2400','291','东昌府区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2401','291','临清市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2402','291','阳谷县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2403','291','莘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2404','291','茌平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2405','291','东阿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2406','291','冠县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2407','291','高唐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2408','292','兰山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2409','292','罗庄区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2410','292','河东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2411','292','沂南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2412','292','郯城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2413','292','沂水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2414','292','苍山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2415','292','费县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2416','292','平邑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2417','292','莒南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2418','292','蒙阴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2419','292','临沭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2420','293','东港区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2421','293','岚山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2422','293','五莲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2423','293','莒县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2424','294','泰山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2425','294','岱岳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2426','294','新泰市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2427','294','肥城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2428','294','宁阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2429','294','东平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2430','295','荣成市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2431','295','乳山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2432','295','环翠区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2433','295','文登市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2434','296','潍城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2435','296','寒亭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2436','296','坊子区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2437','296','奎文区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2438','296','青州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2439','296','诸城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2440','296','寿光市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2441','296','安丘市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2442','296','高密市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2443','296','昌邑市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2444','296','临朐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2445','296','昌乐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2446','297','芝罘区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2447','297','福山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2448','297','牟平区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2449','297','莱山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2450','297','开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2451','297','龙口市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2452','297','莱阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2453','297','莱州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2454','297','蓬莱市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2455','297','招远市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2456','297','栖霞市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2457','297','海阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2458','297','长岛县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2459','298','市中区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2460','298','山亭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2461','298','峄城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2462','298','台儿庄区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2463','298','薛城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2464','298','滕州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2465','299','张店区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2466','299','临淄区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2467','299','淄川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2468','299','博山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2469','299','周村区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2470','299','桓台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2471','299','高青县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2472','299','沂源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2473','300','杏花岭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2474','300','小店区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2475','300','迎泽区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2476','300','尖草坪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2477','300','万柏林区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2478','300','晋源区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2479','300','高新开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2480','300','民营经济开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2481','300','经济技术开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2482','300','清徐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2483','300','阳曲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2484','300','娄烦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2485','300','古交市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2486','301','城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2487','301','郊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2488','301','沁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2489','301','潞城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2490','301','长治县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2491','301','襄垣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2492','301','屯留县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2493','301','平顺县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2494','301','黎城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2495','301','壶关县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2496','301','长子县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2497','301','武乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2498','301','沁源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2499','302','城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2500','302','矿区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2501','302','南郊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2502','302','新荣区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2503','302','阳高县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2504','302','天镇县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2505','302','广灵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2506','302','灵丘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2507','302','浑源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2508','302','左云县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2509','302','大同县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2510','303','城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2511','303','高平市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2512','303','沁水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2513','303','阳城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2514','303','陵川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2515','303','泽州县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2516','304','榆次区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2517','304','介休市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2518','304','榆社县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2519','304','左权县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2520','304','和顺县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2521','304','昔阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2522','304','寿阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2523','304','太谷县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2524','304','祁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2525','304','平遥县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2526','304','灵石县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2527','305','尧都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2528','305','侯马市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2529','305','霍州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2530','305','曲沃县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2531','305','翼城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2532','305','襄汾县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2533','305','洪洞县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2534','305','吉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2535','305','安泽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2536','305','浮山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2537','305','古县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2538','305','乡宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2539','305','大宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2540','305','隰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2541','305','永和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2542','305','蒲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2543','305','汾西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2544','306','离石市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2545','306','离石区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2546','306','孝义市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2547','306','汾阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2548','306','文水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2549','306','交城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2550','306','兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2551','306','临县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2552','306','柳林县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2553','306','石楼县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2554','306','岚县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2555','306','方山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2556','306','中阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2557','306','交口县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2558','307','朔城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2559','307','平鲁区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2560','307','山阴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2561','307','应县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2562','307','右玉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2563','307','怀仁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2564','308','忻府区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2565','308','原平市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2566','308','定襄县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2567','308','五台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2568','308','代县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2569','308','繁峙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2570','308','宁武县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2571','308','静乐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2572','308','神池县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2573','308','五寨县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2574','308','岢岚县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2575','308','河曲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2576','308','保德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2577','308','偏关县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2578','309','城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2579','309','矿区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2580','309','郊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2581','309','平定县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2582','309','盂县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2583','310','盐湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2584','310','永济市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2585','310','河津市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2586','310','临猗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2587','310','万荣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2588','310','闻喜县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2589','310','稷山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2590','310','新绛县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2591','310','绛县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2592','310','垣曲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2593','310','夏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2594','310','平陆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2595','310','芮城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2596','311','莲湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2597','311','新城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2598','311','碑林区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2599','311','雁塔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2600','311','灞桥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2601','311','未央区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2602','311','阎良区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2603','311','临潼区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2604','311','长安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2605','311','蓝田县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2606','311','周至县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2607','311','户县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2608','311','高陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2609','312','汉滨区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2610','312','汉阴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2611','312','石泉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2612','312','宁陕县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2613','312','紫阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2614','312','岚皋县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2615','312','平利县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2616','312','镇坪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2617','312','旬阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2618','312','白河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2619','313','陈仓区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2620','313','渭滨区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2621','313','金台区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2622','313','凤翔县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2623','313','岐山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2624','313','扶风县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2625','313','眉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2626','313','陇县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2627','313','千阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2628','313','麟游县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2629','313','凤县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2630','313','太白县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2631','314','汉台区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2632','314','南郑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2633','314','城固县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2634','314','洋县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2635','314','西乡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2636','314','勉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2637','314','宁强县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2638','314','略阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2639','314','镇巴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2640','314','留坝县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2641','314','佛坪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2642','315','商州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2643','315','洛南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2644','315','丹凤县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2645','315','商南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2646','315','山阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2647','315','镇安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2648','315','柞水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2649','316','耀州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2650','316','王益区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2651','316','印台区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2652','316','宜君县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2653','317','临渭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2654','317','韩城市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2655','317','华阴市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2656','317','华县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2657','317','潼关县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2658','317','大荔县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2659','317','合阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2660','317','澄城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2661','317','蒲城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2662','317','白水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2663','317','富平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2664','318','秦都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2665','318','渭城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2666','318','杨陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2667','318','兴平市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2668','318','三原县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2669','318','泾阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2670','318','乾县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2671','318','礼泉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2672','318','永寿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2673','318','彬县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2674','318','长武县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2675','318','旬邑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2676','318','淳化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2677','318','武功县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2678','319','吴起县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2679','319','宝塔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2680','319','延长县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2681','319','延川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2682','319','子长县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2683','319','安塞县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2684','319','志丹县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2685','319','甘泉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2686','319','富县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2687','319','洛川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2688','319','宜川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2689','319','黄龙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2690','319','黄陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2691','320','榆阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2692','320','神木县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2693','320','府谷县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2694','320','横山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2695','320','靖边县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2696','320','定边县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2697','320','绥德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2698','320','米脂县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2699','320','佳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2700','320','吴堡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2701','320','清涧县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2702','320','子洲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2703','321','长宁区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2704','321','闸北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2705','321','闵行区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2706','321','徐汇区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2707','321','浦东新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2708','321','杨浦区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2709','321','普陀区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2710','321','静安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2711','321','卢湾区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2712','321','虹口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2713','321','黄浦区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2714','321','南汇区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2715','321','松江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2716','321','嘉定区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2717','321','宝山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2718','321','青浦区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2719','321','金山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2720','321','奉贤区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2721','321','崇明县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2722','322','青羊区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2723','322','锦江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2724','322','金牛区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2725','322','武侯区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2726','322','成华区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2727','322','龙泉驿区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2728','322','青白江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2729','322','新都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2730','322','温江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2731','322','高新区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2732','322','高新西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2733','322','都江堰市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2734','322','彭州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2735','322','邛崃市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2736','322','崇州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2737','322','金堂县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2738','322','双流县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2739','322','郫县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2740','322','大邑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2741','322','蒲江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2742','322','新津县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2743','322','都江堰市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2744','322','彭州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2745','322','邛崃市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2746','322','崇州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2747','322','金堂县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2748','322','双流县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2749','322','郫县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2750','322','大邑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2751','322','蒲江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2752','322','新津县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2753','323','涪城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2754','323','游仙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2755','323','江油市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2756','323','盐亭县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2757','323','三台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2758','323','平武县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2759','323','安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2760','323','梓潼县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2761','323','北川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2762','324','马尔康县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2763','324','汶川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2764','324','理县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2765','324','茂县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2766','324','松潘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2767','324','九寨沟县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2768','324','金川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2769','324','小金县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2770','324','黑水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2771','324','壤塘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2772','324','阿坝县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2773','324','若尔盖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2774','324','红原县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2775','325','巴州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2776','325','通江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2777','325','南江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2778','325','平昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2779','326','通川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2780','326','万源市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2781','326','达县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2782','326','宣汉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2783','326','开江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2784','326','大竹县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2785','326','渠县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2786','327','旌阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2787','327','广汉市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2788','327','什邡市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2789','327','绵竹市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2790','327','罗江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2791','327','中江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2792','328','康定县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2793','328','丹巴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2794','328','泸定县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2795','328','炉霍县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2796','328','九龙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2797','328','甘孜县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2798','328','雅江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2799','328','新龙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2800','328','道孚县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2801','328','白玉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2802','328','理塘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2803','328','德格县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2804','328','乡城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2805','328','石渠县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2806','328','稻城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2807','328','色达县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2808','328','巴塘县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2809','328','得荣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2810','329','广安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2811','329','华蓥市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2812','329','岳池县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2813','329','武胜县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2814','329','邻水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2815','330','利州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2816','330','元坝区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2817','330','朝天区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2818','330','旺苍县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2819','330','青川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2820','330','剑阁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2821','330','苍溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2822','331','峨眉山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2823','331','乐山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2824','331','犍为县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2825','331','井研县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2826','331','夹江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2827','331','沐川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2828','331','峨边','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2829','331','马边','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2830','332','西昌市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2831','332','盐源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2832','332','德昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2833','332','会理县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2834','332','会东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2835','332','宁南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2836','332','普格县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2837','332','布拖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2838','332','金阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2839','332','昭觉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2840','332','喜德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2841','332','冕宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2842','332','越西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2843','332','甘洛县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2844','332','美姑县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2845','332','雷波县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2846','332','木里','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2847','333','东坡区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2848','333','仁寿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2849','333','彭山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2850','333','洪雅县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2851','333','丹棱县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2852','333','青神县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2853','334','阆中市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2854','334','南部县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2855','334','营山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2856','334','蓬安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2857','334','仪陇县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2858','334','顺庆区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2859','334','高坪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2860','334','嘉陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2861','334','西充县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2862','335','市中区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2863','335','东兴区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2864','335','威远县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2865','335','资中县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2866','335','隆昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2867','336','东  区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2868','336','西  区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2869','336','仁和区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2870','336','米易县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2871','336','盐边县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2872','337','船山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2873','337','安居区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2874','337','蓬溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2875','337','射洪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2876','337','大英县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2877','338','雨城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2878','338','名山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2879','338','荥经县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2880','338','汉源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2881','338','石棉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2882','338','天全县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2883','338','芦山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2884','338','宝兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2885','339','翠屏区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2886','339','宜宾县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2887','339','南溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2888','339','江安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2889','339','长宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2890','339','高县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2891','339','珙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2892','339','筠连县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2893','339','兴文县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2894','339','屏山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2895','340','雁江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2896','340','简阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2897','340','安岳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2898','340','乐至县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2899','341','大安区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2900','341','自流井区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2901','341','贡井区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2902','341','沿滩区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2903','341','荣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2904','341','富顺县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2905','342','江阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2906','342','纳溪区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2907','342','龙马潭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2908','342','泸县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2909','342','合江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2910','342','叙永县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2911','342','古蔺县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2912','343','和平区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2913','343','河西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2914','343','南开区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2915','343','河北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2916','343','河东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2917','343','红桥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2918','343','东丽区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2919','343','津南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2920','343','西青区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2921','343','北辰区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2922','343','塘沽区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2923','343','汉沽区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2924','343','大港区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2925','343','武清区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2926','343','宝坻区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2927','343','经济开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2928','343','宁河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2929','343','静海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2930','343','蓟县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2931','344','城关区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2932','344','林周县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2933','344','当雄县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2934','344','尼木县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2935','344','曲水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2936','344','堆龙德庆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2937','344','达孜县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2938','344','墨竹工卡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2939','345','噶尔县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2940','345','普兰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2941','345','札达县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2942','345','日土县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2943','345','革吉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2944','345','改则县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2945','345','措勤县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2946','346','昌都县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2947','346','江达县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2948','346','贡觉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2949','346','类乌齐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2950','346','丁青县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2951','346','察雅县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2952','346','八宿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2953','346','左贡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2954','346','芒康县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2955','346','洛隆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2956','346','边坝县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2957','347','林芝县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2958','347','工布江达县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2959','347','米林县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2960','347','墨脱县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2961','347','波密县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2962','347','察隅县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2963','347','朗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2964','348','那曲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2965','348','嘉黎县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2966','348','比如县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2967','348','聂荣县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2968','348','安多县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2969','348','申扎县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2970','348','索县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2971','348','班戈县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2972','348','巴青县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2973','348','尼玛县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2974','349','日喀则市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2975','349','南木林县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2976','349','江孜县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2977','349','定日县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2978','349','萨迦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2979','349','拉孜县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2980','349','昂仁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2981','349','谢通门县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2982','349','白朗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2983','349','仁布县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2984','349','康马县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2985','349','定结县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2986','349','仲巴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2987','349','亚东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2988','349','吉隆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2989','349','聂拉木县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2990','349','萨嘎县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2991','349','岗巴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2992','350','乃东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2993','350','扎囊县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2994','350','贡嘎县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2995','350','桑日县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2996','350','琼结县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2997','350','曲松县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2998','350','措美县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('2999','350','洛扎县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3000','350','加查县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3001','350','隆子县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3002','350','错那县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3003','350','浪卡子县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3004','351','天山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3005','351','沙依巴克区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3006','351','新市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3007','351','水磨沟区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3008','351','头屯河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3009','351','达坂城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3010','351','米东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3011','351','乌鲁木齐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3012','352','阿克苏市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3013','352','温宿县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3014','352','库车县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3015','352','沙雅县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3016','352','新和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3017','352','拜城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3018','352','乌什县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3019','352','阿瓦提县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3020','352','柯坪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3021','353','阿拉尔市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3022','354','库尔勒市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3023','354','轮台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3024','354','尉犁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3025','354','若羌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3026','354','且末县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3027','354','焉耆','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3028','354','和静县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3029','354','和硕县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3030','354','博湖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3031','355','博乐市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3032','355','精河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3033','355','温泉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3034','356','呼图壁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3035','356','米泉市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3036','356','昌吉市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3037','356','阜康市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3038','356','玛纳斯县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3039','356','奇台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3040','356','吉木萨尔县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3041','356','木垒','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3042','357','哈密市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3043','357','伊吾县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3044','357','巴里坤','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3045','358','和田市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3046','358','和田县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3047','358','墨玉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3048','358','皮山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3049','358','洛浦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3050','358','策勒县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3051','358','于田县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3052','358','民丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3053','359','喀什市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3054','359','疏附县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3055','359','疏勒县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3056','359','英吉沙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3057','359','泽普县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3058','359','莎车县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3059','359','叶城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3060','359','麦盖提县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3061','359','岳普湖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3062','359','伽师县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3063','359','巴楚县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3064','359','塔什库尔干','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3065','360','克拉玛依市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3066','361','阿图什市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3067','361','阿克陶县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3068','361','阿合奇县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3069','361','乌恰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3070','362','石河子市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3071','363','图木舒克市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3072','364','吐鲁番市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3073','364','鄯善县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3074','364','托克逊县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3075','365','五家渠市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3076','366','阿勒泰市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3077','366','布克赛尔','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3078','366','伊宁市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3079','366','布尔津县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3080','366','奎屯市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3081','366','乌苏市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3082','366','额敏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3083','366','富蕴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3084','366','伊宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3085','366','福海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3086','366','霍城县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3087','366','沙湾县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3088','366','巩留县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3089','366','哈巴河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3090','366','托里县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3091','366','青河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3092','366','新源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3093','366','裕民县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3094','366','和布克赛尔','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3095','366','吉木乃县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3096','366','昭苏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3097','366','特克斯县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3098','366','尼勒克县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3099','366','察布查尔','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3100','367','盘龙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3101','367','五华区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3102','367','官渡区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3103','367','西山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3104','367','东川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3105','367','安宁市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3106','367','呈贡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3107','367','晋宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3108','367','富民县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3109','367','宜良县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3110','367','嵩明县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3111','367','石林县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3112','367','禄劝','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3113','367','寻甸','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3114','368','兰坪','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3115','368','泸水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3116','368','福贡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3117','368','贡山','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3118','369','宁洱','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3119','369','思茅区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3120','369','墨江','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3121','369','景东','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3122','369','景谷','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3123','369','镇沅','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3124','369','江城','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3125','369','孟连','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3126','369','澜沧','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3127','369','西盟','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3128','370','古城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3129','370','宁蒗','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3130','370','玉龙','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3131','370','永胜县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3132','370','华坪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3133','371','隆阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3134','371','施甸县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3135','371','腾冲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3136','371','龙陵县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3137','371','昌宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3138','372','楚雄市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3139','372','双柏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3140','372','牟定县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3141','372','南华县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3142','372','姚安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3143','372','大姚县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3144','372','永仁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3145','372','元谋县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3146','372','武定县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3147','372','禄丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3148','373','大理市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3149','373','祥云县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3150','373','宾川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3151','373','弥渡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3152','373','永平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3153','373','云龙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3154','373','洱源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3155','373','剑川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3156','373','鹤庆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3157','373','漾濞','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3158','373','南涧','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3159','373','巍山','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3160','374','潞西市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3161','374','瑞丽市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3162','374','梁河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3163','374','盈江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3164','374','陇川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3165','375','香格里拉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3166','375','德钦县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3167','375','维西','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3168','376','泸西县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3169','376','蒙自县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3170','376','个旧市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3171','376','开远市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3172','376','绿春县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3173','376','建水县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3174','376','石屏县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3175','376','弥勒县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3176','376','元阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3177','376','红河县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3178','376','金平','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3179','376','河口','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3180','376','屏边','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3181','377','临翔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3182','377','凤庆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3183','377','云县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3184','377','永德县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3185','377','镇康县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3186','377','双江','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3187','377','耿马','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3188','377','沧源','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3189','378','麒麟区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3190','378','宣威市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3191','378','马龙县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3192','378','陆良县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3193','378','师宗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3194','378','罗平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3195','378','富源县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3196','378','会泽县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3197','378','沾益县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3198','379','文山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3199','379','砚山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3200','379','西畴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3201','379','麻栗坡县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3202','379','马关县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3203','379','丘北县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3204','379','广南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3205','379','富宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3206','380','景洪市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3207','380','勐海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3208','380','勐腊县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3209','381','红塔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3210','381','江川县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3211','381','澄江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3212','381','通海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3213','381','华宁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3214','381','易门县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3215','381','峨山','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3216','381','新平','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3217','381','元江','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3218','382','昭阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3219','382','鲁甸县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3220','382','巧家县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3221','382','盐津县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3222','382','大关县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3223','382','永善县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3224','382','绥江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3225','382','镇雄县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3226','382','彝良县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3227','382','威信县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3228','382','水富县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3229','383','西湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3230','383','上城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3231','383','下城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3232','383','拱墅区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3233','383','滨江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3234','383','江干区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3235','383','萧山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3236','383','余杭区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3237','383','市郊','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3238','383','建德市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3239','383','富阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3240','383','临安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3241','383','桐庐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3242','383','淳安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3243','384','吴兴区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3244','384','南浔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3245','384','德清县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3246','384','长兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3247','384','安吉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3248','385','南湖区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3249','385','秀洲区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3250','385','海宁市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3251','385','嘉善县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3252','385','平湖市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3253','385','桐乡市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3254','385','海盐县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3255','386','婺城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3256','386','金东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3257','386','兰溪市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3258','386','市区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3259','386','佛堂镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3260','386','上溪镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3261','386','义亭镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3262','386','大陈镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3263','386','苏溪镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3264','386','赤岸镇','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3265','386','东阳市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3266','386','永康市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3267','386','武义县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3268','386','浦江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3269','386','磐安县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3270','387','莲都区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3271','387','龙泉市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3272','387','青田县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3273','387','缙云县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3274','387','遂昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3275','387','松阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3276','387','云和县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3277','387','庆元县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3278','387','景宁','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3279','388','海曙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3280','388','江东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3281','388','江北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3282','388','镇海区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3283','388','北仑区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3284','388','鄞州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3285','388','余姚市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3286','388','慈溪市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3287','388','奉化市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3288','388','象山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3289','388','宁海县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3290','389','越城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3291','389','上虞市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3292','389','嵊州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3293','389','绍兴县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3294','389','新昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3295','389','诸暨市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3296','390','椒江区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3297','390','黄岩区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3298','390','路桥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3299','390','温岭市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3300','390','临海市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3301','390','玉环县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3302','390','三门县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3303','390','天台县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3304','390','仙居县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3305','391','鹿城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3306','391','龙湾区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3307','391','瓯海区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3308','391','瑞安市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3309','391','乐清市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3310','391','洞头县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3311','391','永嘉县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3312','391','平阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3313','391','苍南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3314','391','文成县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3315','391','泰顺县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3316','392','定海区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3317','392','普陀区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3318','392','岱山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3319','392','嵊泗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3320','393','衢州市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3321','393','江山市','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3322','393','常山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3323','393','开化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3324','393','龙游县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3325','394','合川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3326','394','江津区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3327','394','南川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3328','394','永川区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3329','394','南岸区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3330','394','渝北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3331','394','万盛区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3332','394','大渡口区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3333','394','万州区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3334','394','北碚区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3335','394','沙坪坝区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3336','394','巴南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3337','394','涪陵区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3338','394','江北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3339','394','九龙坡区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3340','394','渝中区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3341','394','黔江开发区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3342','394','长寿区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3343','394','双桥区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3344','394','綦江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3345','394','潼南县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3346','394','铜梁县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3347','394','大足县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3348','394','荣昌县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3349','394','璧山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3350','394','垫江县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3351','394','武隆县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3352','394','丰都县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3353','394','城口县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3354','394','梁平县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3355','394','开县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3356','394','巫溪县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3357','394','巫山县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3358','394','奉节县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3359','394','云阳县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3360','394','忠县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3361','394','石柱','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3362','394','彭水','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3363','394','酉阳','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3364','394','秀山','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3365','395','沙田区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3366','395','东区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3367','395','观塘区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3368','395','黄大仙区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3369','395','九龙城区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3370','395','屯门区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3371','395','葵青区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3372','395','元朗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3373','395','深水埗区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3374','395','西贡区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3375','395','大埔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3376','395','湾仔区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3377','395','油尖旺区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3378','395','北区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3379','395','南区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3380','395','荃湾区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3381','395','中西区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3382','395','离岛区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3383','396','澳门','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3384','397','台北','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3385','397','高雄','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3386','397','基隆','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3387','397','台中','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3388','397','台南','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3389','397','新竹','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3390','397','嘉义','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3391','397','宜兰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3392','397','桃园县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3393','397','苗栗县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3394','397','彰化县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3395','397','南投县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3396','397','云林县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3397','397','屏东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3398','397','台东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3399','397','花莲县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3400','397','澎湖县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3401','3','合肥','2','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3402','3401','庐阳区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3403','3401','瑶海区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3404','3401','蜀山区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3405','3401','包河区','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3406','3401','长丰县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3407','3401','肥东县','3','0');
INSERT INTO `yzl_region` (`region_id`,`parent_id`,`region_name`,`region_type`,`agency_id`) VALUES ('3408','3401','肥西县','3','0');
/*!40000 ALTER TABLE `yzl_region` ENABLE KEYS */;


--
-- Create Table `yzl_role`
--

DROP TABLE IF EXISTS `yzl_role`;
CREATE TABLE `yzl_role` (
  `role_id` smallint(5) unsigned NOT NULL auto_increment,
  `role_name` varchar(60) NOT NULL default '',
  `action_list` text NOT NULL,
  `role_describe` text,
  PRIMARY KEY  (`role_id`),
  KEY `user_name` (`role_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_role`
--

/*!40000 ALTER TABLE `yzl_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_role` ENABLE KEYS */;


--
-- Create Table `yzl_searchengine`
--

DROP TABLE IF EXISTS `yzl_searchengine`;
CREATE TABLE `yzl_searchengine` (
  `date` date NOT NULL default '0000-00-00',
  `searchengine` varchar(20) NOT NULL default '',
  `count` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`date`,`searchengine`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_searchengine`
--

/*!40000 ALTER TABLE `yzl_searchengine` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_searchengine` ENABLE KEYS */;


--
-- Create Table `yzl_sessions`
--

DROP TABLE IF EXISTS `yzl_sessions`;
CREATE TABLE `yzl_sessions` (
  `sesskey` char(32) character set utf8 collate utf8_bin NOT NULL default '',
  `expiry` int(10) unsigned NOT NULL default '0',
  `userid` mediumint(8) unsigned NOT NULL default '0',
  `adminid` mediumint(8) unsigned NOT NULL default '0',
  `ip` char(15) NOT NULL default '',
  `user_name` varchar(60) NOT NULL,
  `user_rank` tinyint(3) NOT NULL,
  `discount` decimal(3,2) NOT NULL,
  `email` varchar(60) NOT NULL,
  `data` char(255) NOT NULL default '',
  PRIMARY KEY  (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_sessions`
--

/*!40000 ALTER TABLE `yzl_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_sessions` ENABLE KEYS */;


--
-- Create Table `yzl_sessions_data`
--

DROP TABLE IF EXISTS `yzl_sessions_data`;
CREATE TABLE `yzl_sessions_data` (
  `sesskey` varchar(32) character set utf8 collate utf8_bin NOT NULL default '',
  `expiry` int(10) unsigned NOT NULL default '0',
  `data` longtext NOT NULL,
  PRIMARY KEY  (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_sessions_data`
--

/*!40000 ALTER TABLE `yzl_sessions_data` DISABLE KEYS */;
INSERT INTO `yzl_sessions_data` (`sesskey`,`expiry`,`data`) VALUES ('e248e5373526d03ffd8b33e21f5634e3','4294967295','a:9:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:12:\"captcha_word\";s:16:\"YTM0YzI2NzBjYg==\";s:14:\"display_search\";s:4:\"grid\";s:9:\"flow_type\";i:0;s:10:\"flow_order\";a:1:{s:14:\"extension_code\";s:0:\"\";}s:9:\"last_time\";s:10:\"1385088988\";s:7:\"last_ip\";s:9:\"127.0.0.1\";}');
INSERT INTO `yzl_sessions_data` (`sesskey`,`expiry`,`data`) VALUES ('aba898b4bc274ad2c335fc81144b67f4','4294967295','a:5:{s:12:\"captcha_word\";s:16:\"YjkwZGU4MzlhMA==\";s:10:\"admin_name\";s:3:\"zqh\";s:11:\"action_list\";s:459:\"goods_manage,remove_back,cat_manage,cat_drop,attr_manage,brand_manage,comment_priv,tag_manage,goods_type,goods_auto,picture_batch,goods_export,goods_batch,gen_goods_script,article_cat,article_manage,shopinfo_manage,shophelp_manage,vote_priv,article_auto,shop_config,ship_manage,payment,shiparea_manage,area_manage,friendlink,flash_manage,navigator,cron,affiliate,affiliate_ck,sitemap,file_priv,file_check,reg_fields,shop_authorized,webcollect_manage,ad_manage\";s:10:\"last_check\";i:1385407306;s:12:\"suppliers_id\";s:1:\"0\";}');
INSERT INTO `yzl_sessions_data` (`sesskey`,`expiry`,`data`) VALUES ('d9596360081438be965955aa1b5895b7','4294967295','a:3:{s:10:\"admin_name\";s:3:\"zqh\";s:11:\"action_list\";s:459:\"goods_manage,remove_back,cat_manage,cat_drop,attr_manage,brand_manage,comment_priv,tag_manage,goods_type,goods_auto,picture_batch,goods_export,goods_batch,gen_goods_script,article_cat,article_manage,shopinfo_manage,shophelp_manage,vote_priv,article_auto,shop_config,ship_manage,payment,shiparea_manage,area_manage,friendlink,flash_manage,navigator,cron,affiliate,affiliate_ck,sitemap,file_priv,file_check,reg_fields,shop_authorized,webcollect_manage,ad_manage\";s:10:\"last_check\";i:1385415894;}');
INSERT INTO `yzl_sessions_data` (`sesskey`,`expiry`,`data`) VALUES ('12e041864a44ef2a64c7d2a3f4c86352','4294967295','a:5:{s:12:\"captcha_word\";s:16:\"OTRkZjE4N2UxNA==\";s:10:\"admin_name\";s:3:\"zqh\";s:11:\"action_list\";s:459:\"goods_manage,remove_back,cat_manage,cat_drop,attr_manage,brand_manage,comment_priv,tag_manage,goods_type,goods_auto,picture_batch,goods_export,goods_batch,gen_goods_script,article_cat,article_manage,shopinfo_manage,shophelp_manage,vote_priv,article_auto,shop_config,ship_manage,payment,shiparea_manage,area_manage,friendlink,flash_manage,navigator,cron,affiliate,affiliate_ck,sitemap,file_priv,file_check,reg_fields,shop_authorized,webcollect_manage,ad_manage\";s:10:\"last_check\";i:1385422733;s:12:\"suppliers_id\";s:1:\"0\";}');
INSERT INTO `yzl_sessions_data` (`sesskey`,`expiry`,`data`) VALUES ('9afbd4c2d01e8a94939dbd6815803300','4294967295','a:5:{s:12:\"captcha_word\";s:16:\"MmI4ZmY4OGZjYQ==\";s:10:\"admin_name\";s:3:\"zqh\";s:11:\"action_list\";s:459:\"goods_manage,remove_back,cat_manage,cat_drop,attr_manage,brand_manage,comment_priv,tag_manage,goods_type,goods_auto,picture_batch,goods_export,goods_batch,gen_goods_script,article_cat,article_manage,shopinfo_manage,shophelp_manage,vote_priv,article_auto,shop_config,ship_manage,payment,shiparea_manage,area_manage,friendlink,flash_manage,navigator,cron,affiliate,affiliate_ck,sitemap,file_priv,file_check,reg_fields,shop_authorized,webcollect_manage,ad_manage\";s:10:\"last_check\";i:1385423493;s:12:\"suppliers_id\";s:1:\"0\";}');
INSERT INTO `yzl_sessions_data` (`sesskey`,`expiry`,`data`) VALUES ('9d62a4a236b41d8fe5a6db1598dd4b4c','4294967295','a:3:{s:10:\"admin_name\";s:3:\"zqh\";s:11:\"action_list\";s:459:\"goods_manage,remove_back,cat_manage,cat_drop,attr_manage,brand_manage,comment_priv,tag_manage,goods_type,goods_auto,picture_batch,goods_export,goods_batch,gen_goods_script,article_cat,article_manage,shopinfo_manage,shophelp_manage,vote_priv,article_auto,shop_config,ship_manage,payment,shiparea_manage,area_manage,friendlink,flash_manage,navigator,cron,affiliate,affiliate_ck,sitemap,file_priv,file_check,reg_fields,shop_authorized,webcollect_manage,ad_manage\";s:10:\"last_check\";i:1385431055;}');
INSERT INTO `yzl_sessions_data` (`sesskey`,`expiry`,`data`) VALUES ('ff238dabb2ff3d71ea84594b227bc0ce','4294967295','a:3:{s:10:\"admin_name\";s:3:\"zqh\";s:11:\"action_list\";s:459:\"goods_manage,remove_back,cat_manage,cat_drop,attr_manage,brand_manage,comment_priv,tag_manage,goods_type,goods_auto,picture_batch,goods_export,goods_batch,gen_goods_script,article_cat,article_manage,shopinfo_manage,shophelp_manage,vote_priv,article_auto,shop_config,ship_manage,payment,shiparea_manage,area_manage,friendlink,flash_manage,navigator,cron,affiliate,affiliate_ck,sitemap,file_priv,file_check,reg_fields,shop_authorized,webcollect_manage,ad_manage\";s:10:\"last_check\";i:1385488184;}');
/*!40000 ALTER TABLE `yzl_sessions_data` ENABLE KEYS */;


--
-- Create Table `yzl_shipping`
--

DROP TABLE IF EXISTS `yzl_shipping`;
CREATE TABLE `yzl_shipping` (
  `shipping_id` tinyint(3) unsigned NOT NULL auto_increment,
  `shipping_code` varchar(20) NOT NULL default '',
  `shipping_name` varchar(120) NOT NULL default '',
  `shipping_desc` varchar(255) NOT NULL default '',
  `insure` varchar(10) NOT NULL default '0',
  `support_cod` tinyint(1) unsigned NOT NULL default '0',
  `enabled` tinyint(1) unsigned NOT NULL default '0',
  `shipping_print` text NOT NULL,
  `print_bg` varchar(255) default NULL,
  `config_lable` text,
  `print_model` tinyint(1) default '0',
  `shipping_order` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`shipping_id`),
  KEY `shipping_code` (`shipping_code`,`enabled`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_shipping`
--

/*!40000 ALTER TABLE `yzl_shipping` DISABLE KEYS */;
INSERT INTO `yzl_shipping` (`shipping_id`,`shipping_code`,`shipping_name`,`shipping_desc`,`insure`,`support_cod`,`enabled`,`shipping_print`,`print_bg`,`config_lable`,`print_model`,`shipping_order`) VALUES ('1','post_express','邮政快递包裹','邮政快递包裹的描述内容。','1%','0','1','',NULL,NULL,'0','0');
INSERT INTO `yzl_shipping` (`shipping_id`,`shipping_code`,`shipping_name`,`shipping_desc`,`insure`,`support_cod`,`enabled`,`shipping_print`,`print_bg`,`config_lable`,`print_model`,`shipping_order`) VALUES ('2','yto','圆通速递','上海圆通物流（速递）有限公司经过多年的网络快速发展，在中国速递行业中一直处于领先地位。为了能更好的发展国际快件市场，加快与国际市场的接轨，强化圆通的整体实力，圆通已在东南亚、欧美、中东、北美洲、非洲等许多城市运作国际快件业务','0','1','1','',NULL,NULL,'0','0');
INSERT INTO `yzl_shipping` (`shipping_id`,`shipping_code`,`shipping_name`,`shipping_desc`,`insure`,`support_cod`,`enabled`,`shipping_print`,`print_bg`,`config_lable`,`print_model`,`shipping_order`) VALUES ('3','city_express','城际快递','配送的运费是固定的','0','1','1','',NULL,NULL,'0','0');
INSERT INTO `yzl_shipping` (`shipping_id`,`shipping_code`,`shipping_name`,`shipping_desc`,`insure`,`support_cod`,`enabled`,`shipping_print`,`print_bg`,`config_lable`,`print_model`,`shipping_order`) VALUES ('4','flat','市内快递','固定运费的配送方式内容','0','1','1','',NULL,NULL,'0','0');
INSERT INTO `yzl_shipping` (`shipping_id`,`shipping_code`,`shipping_name`,`shipping_desc`,`insure`,`support_cod`,`enabled`,`shipping_print`,`print_bg`,`config_lable`,`print_model`,`shipping_order`) VALUES ('5','sto_express','申通快递','江、浙、沪地区首重为15元/KG，其他地区18元/KG， 续重均为5-6元/KG， 云南地区为8元','0','0','1','',NULL,NULL,'0','0');
INSERT INTO `yzl_shipping` (`shipping_id`,`shipping_code`,`shipping_name`,`shipping_desc`,`insure`,`support_cod`,`enabled`,`shipping_print`,`print_bg`,`config_lable`,`print_model`,`shipping_order`) VALUES ('6','post_mail','邮局平邮','邮局平邮的描述内容。','0','0','1','',NULL,NULL,'0','0');
INSERT INTO `yzl_shipping` (`shipping_id`,`shipping_code`,`shipping_name`,`shipping_desc`,`insure`,`support_cod`,`enabled`,`shipping_print`,`print_bg`,`config_lable`,`print_model`,`shipping_order`) VALUES ('7','fpd','运费到付','所购商品到达即付运费','0','0','1','',NULL,NULL,'0','0');
/*!40000 ALTER TABLE `yzl_shipping` ENABLE KEYS */;


--
-- Create Table `yzl_shipping_area`
--

DROP TABLE IF EXISTS `yzl_shipping_area`;
CREATE TABLE `yzl_shipping_area` (
  `shipping_area_id` smallint(5) unsigned NOT NULL auto_increment,
  `shipping_area_name` varchar(150) NOT NULL default '',
  `shipping_id` tinyint(3) unsigned NOT NULL default '0',
  `configure` text NOT NULL,
  PRIMARY KEY  (`shipping_area_id`),
  KEY `shipping_id` (`shipping_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_shipping_area`
--

/*!40000 ALTER TABLE `yzl_shipping_area` DISABLE KEYS */;
INSERT INTO `yzl_shipping_area` (`shipping_area_id`,`shipping_area_name`,`shipping_id`,`configure`) VALUES ('1','申通','5','a:5:{i:0;a:2:{s:4:\"name\";s:8:\"item_fee\";s:5:\"value\";s:2:\"15\";}i:1;a:2:{s:4:\"name\";s:8:\"base_fee\";s:5:\"value\";s:2:\"15\";}i:2;a:2:{s:4:\"name\";s:8:\"step_fee\";s:5:\"value\";s:1:\"5\";}i:3;a:2:{s:4:\"name\";s:10:\"free_money\";s:5:\"value\";s:1:\"0\";}i:4;a:2:{s:4:\"name\";s:16:\"fee_compute_mode\";s:5:\"value\";s:9:\"by_weight\";}}');
INSERT INTO `yzl_shipping_area` (`shipping_area_id`,`shipping_area_name`,`shipping_id`,`configure`) VALUES ('2','1','3','a:4:{i:0;a:2:{s:4:\"name\";s:8:\"base_fee\";s:5:\"value\";s:2:\"10\";}i:1;a:2:{s:4:\"name\";s:10:\"free_money\";s:5:\"value\";s:6:\"100000\";}i:2;a:2:{s:4:\"name\";s:16:\"fee_compute_mode\";s:5:\"value\";N;}i:3;a:2:{s:4:\"name\";s:7:\"pay_fee\";s:5:\"value\";s:1:\"5\";}}');
INSERT INTO `yzl_shipping_area` (`shipping_area_id`,`shipping_area_name`,`shipping_id`,`configure`) VALUES ('3','邮局','6','a:7:{i:0;a:2:{s:4:\"name\";s:8:\"item_fee\";s:5:\"value\";s:1:\"4\";}i:1;a:2:{s:4:\"name\";s:8:\"base_fee\";s:5:\"value\";s:3:\"3.5\";}i:2;a:2:{s:4:\"name\";s:8:\"step_fee\";s:5:\"value\";s:3:\"2.5\";}i:3;a:2:{s:4:\"name\";s:9:\"step_fee1\";s:5:\"value\";N;}i:4;a:2:{s:4:\"name\";s:8:\"pack_fee\";s:5:\"value\";s:1:\"0\";}i:5;a:2:{s:4:\"name\";s:10:\"free_money\";s:5:\"value\";s:5:\"50000\";}i:6;a:2:{s:4:\"name\";s:16:\"fee_compute_mode\";s:5:\"value\";s:9:\"by_weight\";}}');
INSERT INTO `yzl_shipping_area` (`shipping_area_id`,`shipping_area_name`,`shipping_id`,`configure`) VALUES ('4','运费到付','7','a:2:{i:0;a:2:{s:4:\"name\";s:10:\"free_money\";s:5:\"value\";s:5:\"50000\";}i:1;a:2:{s:4:\"name\";s:16:\"fee_compute_mode\";s:5:\"value\";N;}}');
/*!40000 ALTER TABLE `yzl_shipping_area` ENABLE KEYS */;


--
-- Create Table `yzl_shop_config`
--

DROP TABLE IF EXISTS `yzl_shop_config`;
CREATE TABLE `yzl_shop_config` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `parent_id` smallint(5) unsigned NOT NULL default '0',
  `code` varchar(30) NOT NULL default '',
  `type` varchar(10) NOT NULL default '',
  `store_range` varchar(255) NOT NULL default '',
  `store_dir` varchar(255) NOT NULL default '',
  `value` text NOT NULL,
  `sort_order` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=904 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_shop_config`
--

/*!40000 ALTER TABLE `yzl_shop_config` DISABLE KEYS */;
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('1','0','shop_info','group','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('2','0','basic','group','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('3','0','display','group','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('4','0','shopping_flow','group','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('5','0','smtp','group','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('6','0','hidden','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('7','0','goods','group','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('8','0','sms','group','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('9','0','wap','group','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('101','1','shop_name','text','','','易张脸官网','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('102','1','shop_title','text','','','易张脸官网','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('103','1','shop_desc','text','','','易张脸官网','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('104','1','shop_keywords','text','','','易张脸,美容,美肤','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('105','1','shop_country','manual','','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('106','1','shop_province','manual','','','2','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('107','1','shop_city','manual','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('108','1','shop_address','text','','','大山区','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('109','1','qq','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('110','1','ww','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('111','1','skype','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('112','1','ym','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('113','1','msn','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('114','1','service_email','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('115','1','service_phone','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('116','1','shop_closed','select','0,1','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('117','1','close_comment','textarea','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('118','1','shop_logo','file','','../themes/{$template}/images/','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('119','1','licensed','select','0,1','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('120','1','user_notice','textarea','','','用户中心公告！','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('121','1','shop_notice','textarea','','','欢迎光临手机网,我们的宗旨：诚信经营、服务客户！\r\n<MARQUEE onmouseover=this.stop() onmouseout=this.start() \r\nscrollAmount=3><U><FONT color=red>\r\n<P>咨询电话010-10124444  010-21252454 8465544</P></FONT></U></MARQUEE>','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('122','1','shop_reg_closed','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('201','2','lang','manual','','','zh_cn','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('202','2','icp_number','text','','','京工商备案号：8568965398','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('203','2','icp_file','file','','../cert/','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('204','2','watermark','file','','../images/','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('205','2','watermark_place','select','0,1,2,3,4,5','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('206','2','watermark_alpha','text','','','65','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('207','2','use_storage','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('208','2','market_price_rate','text','','','1.2','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('209','2','rewrite','select','0,1,2','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('210','2','integral_name','text','','','积分','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('211','2','integral_scale','text','','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('212','2','integral_percent','text','','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('213','2','sn_prefix','text','','','YZL','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('214','2','comment_check','select','0,1','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('215','2','no_picture','file','','../images/','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('218','2','stats_code','textarea','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('219','2','cache_time','text','','','3600','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('220','2','register_points','text','','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('221','2','enable_gzip','select','0,1','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('222','2','top10_time','select','0,1,2,3,4','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('223','2','timezone','options','-12,-11,-10,-9,-8,-7,-6,-5,-4,-3.5,-3,-2,-1,0,1,2,3,3.5,4,4.5,5,5.5,5.75,6,6.5,7,8,9,9.5,10,11,12','','8','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('224','2','upload_size_limit','options','-1,0,64,128,256,512,1024,2048,4096','','64','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('226','2','cron_method','select','0,1','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('227','2','comment_factor','select','0,1,2,3','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('228','2','enable_order_check','select','0,1','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('229','2','default_storage','text','','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('230','2','bgcolor','text','','','#FFFFFF','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('231','2','visit_stats','select','on,off','','on','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('232','2','send_mail_on','select','on,off','','off','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('233','2','auto_generate_gallery','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('234','2','retain_original_img','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('235','2','member_email_validate','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('236','2','message_board','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('239','2','certificate_id','hidden','','','1033975438','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('240','2','token','hidden','','','3ca326ee6cd17322e6122b1f456eae005cb3c465e96a4f112630a969cd2bbc0d','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('241','2','certi','hidden','','','http://service.shopex.cn/openapi/api.php','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('242','2','send_verify_email','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('243','2','ent_id','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('244','2','ent_ac','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('245','2','ent_sign','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('246','2','ent_email','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('301','3','date_format','hidden','','','Y-m-d','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('302','3','time_format','text','','','Y-m-d H:i:s','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('303','3','currency_format','text','','','￥%s','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('304','3','thumb_width','text','','','100','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('305','3','thumb_height','text','','','100','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('306','3','image_width','text','','','230','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('307','3','image_height','text','','','230','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('312','3','top_number','text','','','10','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('313','3','history_number','text','','','5','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('314','3','comments_number','text','','','5','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('315','3','bought_goods','text','','','3','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('316','3','article_number','text','','','8','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('317','3','goods_name_length','text','','','7','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('318','3','price_format','select','0,1,2,3,4,5','','5','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('319','3','page_size','text','','','8','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('320','3','sort_order_type','select','0,1,2','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('321','3','sort_order_method','select','0,1','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('322','3','show_order_type','select','0,1,2','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('323','3','attr_related_number','text','','','5','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('324','3','goods_gallery_number','text','','','5','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('325','3','article_title_length','text','','','16','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('326','3','name_of_region_1','text','','','国家','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('327','3','name_of_region_2','text','','','省','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('328','3','name_of_region_3','text','','','市','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('329','3','name_of_region_4','text','','','区','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('330','3','search_keywords','text','','','','0');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('332','3','related_goods_number','text','','','4','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('333','3','help_open','select','0,1','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('334','3','article_page_size','text','','','8','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('335','3','page_style','select','0,1','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('336','3','recommend_order','select','0,1','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('337','3','index_ad','hidden','','','sys','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('401','4','can_invoice','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('402','4','use_integral','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('403','4','use_bonus','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('404','4','use_surplus','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('405','4','use_how_oos','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('406','4','send_confirm_email','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('407','4','send_ship_email','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('408','4','send_cancel_email','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('409','4','send_invalid_email','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('410','4','order_pay_note','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('411','4','order_unpay_note','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('412','4','order_ship_note','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('413','4','order_receive_note','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('414','4','order_unship_note','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('415','4','order_return_note','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('416','4','order_invalid_note','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('417','4','order_cancel_note','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('418','4','invoice_content','textarea','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('419','4','anonymous_buy','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('420','4','min_goods_amount','text','','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('421','4','one_step_buy','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('422','4','invoice_type','manual','','','a:2:{s:4:\"type\";a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:0:\"\";}s:4:\"rate\";a:3:{i:0;d:1;i:1;d:1.5;i:2;d:0;}}','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('423','4','stock_dec_time','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('424','4','cart_confirm','options','1,2,3,4','','3','0');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('425','4','send_service_email','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('426','4','show_goods_in_cart','select','1,2,3','','3','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('427','4','show_attr_in_cart','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('501','5','smtp_host','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('502','5','smtp_port','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('503','5','smtp_user','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('504','5','smtp_pass','password','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('505','5','smtp_mail','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('506','5','mail_charset','select','UTF8,GB2312,BIG5','','UTF8','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('507','5','mail_service','select','0,1','','0','0');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('508','5','smtp_ssl','select','0,1','','0','0');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('601','6','integrate_code','hidden','','','ecshop','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('602','6','integrate_config','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('603','6','hash_code','hidden','','','31693422540744c0a6b6da635b7a5a93','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('604','6','template','hidden','','','yzl_v3','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('605','6','install_date','hidden','','','1379926104','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('606','6','ecs_version','hidden','','','v2.7.3','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('607','6','sms_user_name','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('608','6','sms_password','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('609','6','sms_auth_str','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('610','6','sms_domain','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('611','6','sms_count','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('612','6','sms_total_money','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('613','6','sms_balance','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('614','6','sms_last_request','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('616','6','affiliate','hidden','','','a:3:{s:6:\"config\";a:7:{s:6:\"expire\";d:24;s:11:\"expire_unit\";s:4:\"hour\";s:11:\"separate_by\";i:0;s:15:\"level_point_all\";s:2:\"5%\";s:15:\"level_money_all\";s:2:\"1%\";s:18:\"level_register_all\";i:2;s:17:\"level_register_up\";i:60;}s:4:\"item\";a:4:{i:0;a:2:{s:11:\"level_point\";s:3:\"60%\";s:11:\"level_money\";s:3:\"60%\";}i:1;a:2:{s:11:\"level_point\";s:3:\"30%\";s:11:\"level_money\";s:3:\"30%\";}i:2;a:2:{s:11:\"level_point\";s:2:\"7%\";s:11:\"level_money\";s:2:\"7%\";}i:3;a:2:{s:11:\"level_point\";s:2:\"3%\";s:11:\"level_money\";s:2:\"3%\";}}s:2:\"on\";i:1;}','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('617','6','captcha','hidden','','','15','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('618','6','captcha_width','hidden','','','55','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('619','6','captcha_height','hidden','','','25','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('620','6','sitemap','hidden','','','a:6:{s:19:\"homepage_changefreq\";s:6:\"hourly\";s:17:\"homepage_priority\";s:3:\"0.9\";s:19:\"category_changefreq\";s:6:\"hourly\";s:17:\"category_priority\";s:3:\"0.8\";s:18:\"content_changefreq\";s:6:\"weekly\";s:16:\"content_priority\";s:3:\"0.7\";}','0');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('621','6','points_rule','hidden','','','','0');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('622','6','flash_theme','hidden','','','o.slider','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('623','6','stylename','hidden','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('701','7','show_goodssn','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('702','7','show_brand','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('703','7','show_goodsweight','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('704','7','show_goodsnumber','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('705','7','show_addtime','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('706','7','goodsattr_style','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('707','7','show_marketprice','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('801','8','sms_shop_mobile','text','','','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('802','8','sms_order_placed','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('803','8','sms_order_payed','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('804','8','sms_order_shipped','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('901','9','wap_config','select','1,0','','0','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('902','9','wap_logo','file','','../images/','','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('903','2','message_check','select','1,0','','1','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('338','3','thumb_wall_width','text','','','300','1');
INSERT INTO `yzl_shop_config` (`id`,`parent_id`,`code`,`type`,`store_range`,`store_dir`,`value`,`sort_order`) VALUES ('339','3','thumb_wall_height','text','','','197','1');
/*!40000 ALTER TABLE `yzl_shop_config` ENABLE KEYS */;


--
-- Create Table `yzl_snatch_log`
--

DROP TABLE IF EXISTS `yzl_snatch_log`;
CREATE TABLE `yzl_snatch_log` (
  `log_id` mediumint(8) unsigned NOT NULL auto_increment,
  `snatch_id` tinyint(3) unsigned NOT NULL default '0',
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `bid_price` decimal(10,2) NOT NULL default '0.00',
  `bid_time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`log_id`),
  KEY `snatch_id` (`snatch_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_snatch_log`
--

/*!40000 ALTER TABLE `yzl_snatch_log` DISABLE KEYS */;
INSERT INTO `yzl_snatch_log` (`log_id`,`snatch_id`,`user_id`,`bid_price`,`bid_time`) VALUES ('1','2','1','17.00','1242142910');
INSERT INTO `yzl_snatch_log` (`log_id`,`snatch_id`,`user_id`,`bid_price`,`bid_time`) VALUES ('2','1','1','50.00','1242142935');
/*!40000 ALTER TABLE `yzl_snatch_log` ENABLE KEYS */;


--
-- Create Table `yzl_stats`
--

DROP TABLE IF EXISTS `yzl_stats`;
CREATE TABLE `yzl_stats` (
  `access_time` int(10) unsigned NOT NULL default '0',
  `ip_address` varchar(15) NOT NULL default '',
  `visit_times` smallint(5) unsigned NOT NULL default '1',
  `browser` varchar(60) NOT NULL default '',
  `system` varchar(20) NOT NULL default '',
  `language` varchar(20) NOT NULL default '',
  `area` varchar(30) NOT NULL default '',
  `referer_domain` varchar(100) NOT NULL default '',
  `referer_path` varchar(200) NOT NULL default '',
  `access_url` varchar(255) NOT NULL default '',
  KEY `access_time` (`access_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_stats`
--

/*!40000 ALTER TABLE `yzl_stats` DISABLE KEYS */;
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1381642001','127.0.0.1','30','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1381681432','127.0.0.1','31','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1381708787','127.0.0.1','32','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/article.php?act=edit&id=22','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1381714060','127.0.0.1','33','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/article.php?act=edit&id=22','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1381729228','127.0.0.1','34','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1381742134','127.0.0.1','35','Unknow browser','Windows 32','','LAN','http://demo.yizhanglian.com','/admin/article.php?act=list','/article.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1381746813','127.0.0.1','35','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/index.php?act=top','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382286431','127.0.0.1','7','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/exp.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382288653','127.0.0.1','36','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382291313','127.0.0.1','1','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382293233','127.0.0.1','37','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382305105','127.0.0.1','8','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382313630','127.0.0.1','7','Internet Explorer 10.0','Windows NT','zh-Hans-CN,zh-Hans','LAN','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382373791','127.0.0.1','9','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/page/wallpaper','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382382609','127.0.0.1','10','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/article.php?act=list&cat_id=1','/article.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382389678','127.0.0.1','11','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/topic.php?topic_id=2','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382402685','127.0.0.1','12','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382631787','127.0.0.1','38','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382883222','127.0.0.1','13','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382892862','127.0.0.1','14','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/goods.php?act=list','/goods.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382897513','127.0.0.1','15','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382907300','127.0.0.1','39','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382937321','127.0.0.1','40','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1382946097','127.0.0.1','41','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/page/vedio','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1383071869','127.0.0.1','41','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1383096567','127.0.0.1','42','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1383170465','127.0.0.1','43','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384795961','127.0.0.1','1','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384808431','127.0.0.1','2','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384823196','127.0.0.1','3','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384878384','127.0.0.1','4','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384885601','127.0.0.1','44','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384889159','127.0.0.1','5','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/index.php?act=top','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384891490','127.0.0.1','45','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384896546','127.0.0.1','6','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384913739','127.0.0.1','7','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php?act=logout','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384964784','127.0.0.1','8','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384964784','127.0.0.1','8','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php?act=register','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384964787','127.0.0.1','8','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/index.php?act=top','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384970534','127.0.0.1','9','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384973210','127.0.0.1','10','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384976791','127.0.0.1','46','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1384980730','127.0.0.1','8','Internet Explorer 8.0','Windows NT','zh-Hans-CN,zh-Hans','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385000219','127.0.0.1','47','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385009611','127.0.0.1','48','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/article.php?act=list','/article.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385023648','127.0.0.1','49','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/index.php?act=top','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385039134','127.0.0.1','50','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/admin/index.php?act=top','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385051792','127.0.0.1','51','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385082189','127.0.0.1','52','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385267936','127.0.0.1','11','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385268904','127.0.0.1','53','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385276988','127.0.0.1','12','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385314149','127.0.0.1','13','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385325479','127.0.0.1','14','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385359400','127.0.0.1','54','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385368637','127.0.0.1','55','Unknow browser','Windows 32','','LAN','http://demo.yizhanglian.com','/#','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385368925','127.0.0.1','9','Internet Explorer 10.0','Windows NT','zh-Hans-CN,zh-Hans','LAN','','','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385370094','127.0.0.1','55','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385370094','127.0.0.1','56','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php?act=logout','/captcha.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385371546','127.0.0.1','10','Internet Explorer 7.0','Windows NT','zh-Hans-CN,zh-Hans','LAN','http://demo.yizhanglian.com','/user.php?act=register','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385372347','127.0.0.1','57','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385372347','127.0.0.1','58','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php?act=logout','/captcha.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385374838','127.0.0.1','59','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385374838','127.0.0.1','60','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php?act=logout','/captcha.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385375890','127.0.0.1','61','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385375891','127.0.0.1','62','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php?act=logout','/captcha.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385376823','127.0.0.1','63','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385376824','127.0.0.1','64','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php?act=logout','/captcha.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385377127','127.0.0.1','65','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/','/user.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385377127','127.0.0.1','66','Safari 537.36','Windows NT','zh-CN,zh','LAN','http://demo.yizhanglian.com','/user.php?act=logout','/captcha.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385399146','127.0.0.1','15','Safari 537.36','Windows NT','zh-CN,zh','LAN','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385402612','113.204.104.154','7','Safari 537.36','Windows NT','zh-CN,zh','IANA','http://new.yizhanglian.com','/admin/index.php?act=top','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385403421','106.80.62.104','1','Internet Explorer 9.0','Windows NT','zh-CN','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385403553','121.196.43.131','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385403700','121.196.43.130','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385403700','121.196.43.131','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385403707','121.196.43.131','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385403744','113.204.224.110','7','Internet Explorer 10.0','Windows NT','zh-CN','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385403873','121.196.43.130','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385403986','14.17.29.91','1','Unknow browser','Unknown','zh-cn, zh','','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385406179','14.17.29.91','1','Unknow browser','Unknown','zh-cn, zh','','','','/category.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385406185','113.204.224.110','3','Safari 537.36','Windows NT','zh-CN,zh','IANA','','','/category.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385406199','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/category.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385406482','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/index.php/skin_experience .html');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385406984','121.196.43.130','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385407234','113.204.224.110','4','Safari 537.36','Windows XP','zh-CN,zh','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385407445','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385407463','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385407595','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385407622','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385407926','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/article.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385408573','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385408628','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/article.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385408650','183.60.153.106','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','[δ֪IP0801]','','','/article.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385408971','113.204.224.110','5','Safari 537.36','Windows XP','zh-CN,zh','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409035','180.153.163.187','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/captcha.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409063','101.226.33.202','1','Unknow browser','Unknown','zh-cn, zh','IANA','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409066','180.153.163.208','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409070','180.153.201.214','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409073','101.226.66.174','1','Unknow browser','Unknown','zh-cn, zh','IANA','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409091','180.153.206.30','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409097','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409147','180.153.206.24','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409157','180.153.114.197','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/category.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385409230','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/article.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385414732','113.204.224.110','8','Internet Explorer 10.0','Windows NT','zh-CN','IANA','http://new.yizhanglian.com','/goods.php?id=32','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385415947','113.204.224.110','1','Internet Explorer 10.0','Windows NT','zh-CN','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385415998','121.196.43.131','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385416016','121.196.43.130','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385416018','113.204.224.110','1','Internet Explorer 10.0','Windows NT','zh-CN','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385416048','14.17.29.91','1','Unknow browser','Unknown','zh-cn, zh','','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385416059','113.204.224.110','1','Internet Explorer 8.0','Windows XP','zh-cn','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385416120','121.196.43.131','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385416247','220.181.126.47','1','Internet Explorer 8.0','Windows NT','','','http://new.yizhanglian.com','/','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385418245','113.204.224.110','6','Safari 537.36','Windows XP','zh-CN,zh','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385423455','113.204.104.154','8','Safari 537.36','Windows NT','zh-CN,zh','IANA','','','/index.php/_-tools/msd');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385425430','121.196.43.130','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385425434','113.204.224.110','2','Internet Explorer 10.0','Windows NT','zh-CN','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385425478','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385425525','119.147.146.189','1','Internet Explorer 6.0','Windows XP','zh-CN,zh','APNIC','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385428526','113.204.104.154','9','Safari 537.36','Windows NT','zh-CN,zh','IANA','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385434272','113.204.104.154','10','Safari 537.36','Windows NT','zh-CN,zh','IANA','','','/article.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385485285','121.196.43.131','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385485298','113.204.224.110','3','Internet Explorer 10.0','Windows NT','zh-CN','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385485667','14.17.29.92','1','Unknow browser','Unknown','zh-cn, zh','','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385485856','113.204.104.154','8','Safari 537.36','Windows NT','zh-CN,zh','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385486153','113.204.104.154','11','Safari 537.36','Windows NT','zh-CN,zh','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385486290','121.196.43.130','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385487098','180.153.201.217','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385487102','112.64.235.249','1','Unknow browser','Unknown','zh-cn, zh','IANA','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385487110','222.73.77.55','1','Unknow browser','Unknown','zh-cn, zh','','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385487112','180.153.206.17','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385487129','180.153.214.178','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385487245','180.153.161.55','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/index.php/Skin_experience .html');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385487248','180.153.214.192','1','Unknow browser','Unknown','zh-cn, zh','[δ֪IP0801]','','','/index.php/skin_detection.html');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385487304','113.204.224.110','4','Internet Explorer 10.0','Windows NT','zh-CN','IANA','http://new.yizhanglian.com','/skin_detection.html','/article_cat.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385488394','121.196.43.130','1','Unknow browser','Unknown','','','','','/certi.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385488401','113.204.104.154','12','Safari 537.36','Windows NT','zh-CN,zh','IANA','http://new.yizhanglian.com','/admin/goods.php?act=list','/goods.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385488520','113.204.104.154','1','Internet Explorer 10.0','Windows NT','zh-Hans-CN,zh-Hans','IANA','','','/index.php');
INSERT INTO `yzl_stats` (`access_time`,`ip_address`,`visit_times`,`browser`,`system`,`language`,`area`,`referer_domain`,`referer_path`,`access_url`) VALUES ('1385488551','113.204.224.110','7','Safari 537.36','Windows XP','zh-CN,zh','IANA','','','/index.php');
/*!40000 ALTER TABLE `yzl_stats` ENABLE KEYS */;


--
-- Create Table `yzl_suppliers`
--

DROP TABLE IF EXISTS `yzl_suppliers`;
CREATE TABLE `yzl_suppliers` (
  `suppliers_id` smallint(5) unsigned NOT NULL auto_increment,
  `suppliers_name` varchar(255) default NULL,
  `suppliers_desc` mediumtext,
  `is_check` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`suppliers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_suppliers`
--

/*!40000 ALTER TABLE `yzl_suppliers` DISABLE KEYS */;
INSERT INTO `yzl_suppliers` (`suppliers_id`,`suppliers_name`,`suppliers_desc`,`is_check`) VALUES ('1','北京供货商','北京供货商','1');
INSERT INTO `yzl_suppliers` (`suppliers_id`,`suppliers_name`,`suppliers_desc`,`is_check`) VALUES ('2','上海供货商','上海供货商','1');
/*!40000 ALTER TABLE `yzl_suppliers` ENABLE KEYS */;


--
-- Create Table `yzl_tag`
--

DROP TABLE IF EXISTS `yzl_tag`;
CREATE TABLE `yzl_tag` (
  `tag_id` mediumint(8) NOT NULL auto_increment,
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `tag_words` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`tag_id`),
  KEY `user_id` (`user_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_tag`
--

/*!40000 ALTER TABLE `yzl_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_tag` ENABLE KEYS */;


--
-- Create Table `yzl_template`
--

DROP TABLE IF EXISTS `yzl_template`;
CREATE TABLE `yzl_template` (
  `filename` varchar(30) NOT NULL default '',
  `region` varchar(40) NOT NULL default '',
  `library` varchar(40) NOT NULL default '',
  `sort_order` tinyint(1) unsigned NOT NULL default '0',
  `id` smallint(5) unsigned NOT NULL default '0',
  `number` tinyint(1) unsigned NOT NULL default '5',
  `type` tinyint(1) unsigned NOT NULL default '0',
  `theme` varchar(60) NOT NULL default '',
  `remarks` varchar(30) NOT NULL default '',
  KEY `filename` (`filename`,`region`),
  KEY `theme` (`theme`),
  KEY `remarks` (`remarks`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_template`
--

/*!40000 ALTER TABLE `yzl_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_template` ENABLE KEYS */;


--
-- Create Table `yzl_topic`
--

DROP TABLE IF EXISTS `yzl_topic`;
CREATE TABLE `yzl_topic` (
  `topic_id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '''''',
  `intro` text NOT NULL,
  `start_time` int(11) NOT NULL default '0',
  `end_time` int(10) NOT NULL default '0',
  `data` text NOT NULL,
  `template` varchar(255) NOT NULL default '''''',
  `css` text NOT NULL,
  `topic_img` varchar(255) default NULL,
  `title_pic` varchar(255) default NULL,
  `base_style` char(6) default NULL,
  `htmls` mediumtext,
  `keywords` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  KEY `topic_id` (`topic_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_topic`
--

/*!40000 ALTER TABLE `yzl_topic` DISABLE KEYS */;
INSERT INTO `yzl_topic` (`topic_id`,`title`,`intro`,`start_time`,`end_time`,`data`,`template`,`css`,`topic_img`,`title_pic`,`base_style`,`htmls`,`keywords`,`description`) VALUES ('2','皮肤急救中心','<p>&nbsp;发生的发打发打发的说法啊是的V发生的阿斯顿发是</p>','1380528000','1793347200','O:8:\"stdClass\":1:{s:7:\"default\";a:0:{}}','skin_center.dwt','','','','','','皮肤急救中心','皮肤急救中心');
INSERT INTO `yzl_topic` (`topic_id`,`title`,`intro`,`start_time`,`end_time`,`data`,`template`,`css`,`topic_img`,`title_pic`,`base_style`,`htmls`,`keywords`,`description`) VALUES ('3','测试专题哈','<p>&nbsp;这里是专题介绍页面啊 啊啊啊啊啊....</p>','1384934400','1521187200','O:8:\"stdClass\":1:{s:7:\"default\";a:7:{i:0;s:33:\"牡丹紧致逆颜蚕丝面膜|19\";i:1;s:33:\"玫瑰美白补水蚕丝面膜|20\";i:2;s:33:\"牡丹紧致逆颜蚕丝面膜|21\";i:3;s:34:\"菩提花塑颜V脸蚕丝面膜|23\";i:4;s:33:\"茉莉焕颜柔肤蚕丝面膜|24\";i:5;s:33:\"牡丹紧致逆颜蚕丝面膜|31\";i:6;s:33:\"荷花清颜水肌睡眠面膜|32\";}}','','','data/afficheimg/20131121xetmyr.jpg','data/afficheimg/20131121ztinea.jpg','343399','','额发疯','发饿伐');
/*!40000 ALTER TABLE `yzl_topic` ENABLE KEYS */;


--
-- Create Table `yzl_user_account`
--

DROP TABLE IF EXISTS `yzl_user_account`;
CREATE TABLE `yzl_user_account` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `admin_user` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `add_time` int(10) NOT NULL default '0',
  `paid_time` int(10) NOT NULL default '0',
  `admin_note` varchar(255) NOT NULL,
  `user_note` varchar(255) NOT NULL,
  `process_type` tinyint(1) NOT NULL default '0',
  `payment` varchar(90) NOT NULL,
  `is_paid` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`),
  KEY `is_paid` (`is_paid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_user_account`
--

/*!40000 ALTER TABLE `yzl_user_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_user_account` ENABLE KEYS */;


--
-- Create Table `yzl_user_address`
--

DROP TABLE IF EXISTS `yzl_user_address`;
CREATE TABLE `yzl_user_address` (
  `address_id` mediumint(8) unsigned NOT NULL auto_increment,
  `address_name` varchar(50) NOT NULL default '',
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `consignee` varchar(60) NOT NULL default '',
  `email` varchar(60) NOT NULL default '',
  `country` smallint(5) NOT NULL default '0',
  `province` smallint(5) NOT NULL default '0',
  `city` smallint(5) NOT NULL default '0',
  `district` smallint(5) NOT NULL default '0',
  `address` varchar(120) NOT NULL default '',
  `zipcode` varchar(60) NOT NULL default '',
  `tel` varchar(60) NOT NULL default '',
  `mobile` varchar(60) NOT NULL default '',
  `sign_building` varchar(120) NOT NULL default '',
  `best_time` varchar(120) NOT NULL default '',
  PRIMARY KEY  (`address_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_user_address`
--

/*!40000 ALTER TABLE `yzl_user_address` DISABLE KEYS */;
INSERT INTO `yzl_user_address` (`address_id`,`address_name`,`user_id`,`consignee`,`email`,`country`,`province`,`city`,`district`,`address`,`zipcode`,`tel`,`mobile`,`sign_building`,`best_time`) VALUES ('3','','11','fafadfaf','1144042682@qq.com','1','2','52','501','sfafaf','','232423424','','','');
INSERT INTO `yzl_user_address` (`address_id`,`address_name`,`user_id`,`consignee`,`email`,`country`,`province`,`city`,`district`,`address`,`zipcode`,`tel`,`mobile`,`sign_building`,`best_time`) VALUES ('4','','11','addfd','1144042682@qq.com','1','32','394','3330','adafaf','','23234242','','','');
/*!40000 ALTER TABLE `yzl_user_address` ENABLE KEYS */;


--
-- Create Table `yzl_user_bonus`
--

DROP TABLE IF EXISTS `yzl_user_bonus`;
CREATE TABLE `yzl_user_bonus` (
  `bonus_id` mediumint(8) unsigned NOT NULL auto_increment,
  `bonus_type_id` tinyint(3) unsigned NOT NULL default '0',
  `bonus_sn` bigint(20) unsigned NOT NULL default '0',
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `used_time` int(10) unsigned NOT NULL default '0',
  `order_id` mediumint(8) unsigned NOT NULL default '0',
  `emailed` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`bonus_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_user_bonus`
--

/*!40000 ALTER TABLE `yzl_user_bonus` DISABLE KEYS */;
INSERT INTO `yzl_user_bonus` (`bonus_id`,`bonus_type_id`,`bonus_sn`,`user_id`,`used_time`,`order_id`,`emailed`) VALUES ('3','4','1000018450','0','0','0','0');
INSERT INTO `yzl_user_bonus` (`bonus_id`,`bonus_type_id`,`bonus_sn`,`user_id`,`used_time`,`order_id`,`emailed`) VALUES ('4','4','1000023774','0','0','0','0');
INSERT INTO `yzl_user_bonus` (`bonus_id`,`bonus_type_id`,`bonus_sn`,`user_id`,`used_time`,`order_id`,`emailed`) VALUES ('5','4','1000039394','0','0','0','0');
INSERT INTO `yzl_user_bonus` (`bonus_id`,`bonus_type_id`,`bonus_sn`,`user_id`,`used_time`,`order_id`,`emailed`) VALUES ('6','4','1000049305','0','0','0','0');
INSERT INTO `yzl_user_bonus` (`bonus_id`,`bonus_type_id`,`bonus_sn`,`user_id`,`used_time`,`order_id`,`emailed`) VALUES ('7','4','1000052248','0','0','0','0');
INSERT INTO `yzl_user_bonus` (`bonus_id`,`bonus_type_id`,`bonus_sn`,`user_id`,`used_time`,`order_id`,`emailed`) VALUES ('8','4','1000061542','0','0','0','0');
INSERT INTO `yzl_user_bonus` (`bonus_id`,`bonus_type_id`,`bonus_sn`,`user_id`,`used_time`,`order_id`,`emailed`) VALUES ('9','4','1000070278','0','0','0','0');
INSERT INTO `yzl_user_bonus` (`bonus_id`,`bonus_type_id`,`bonus_sn`,`user_id`,`used_time`,`order_id`,`emailed`) VALUES ('10','4','1000080588','0','0','0','0');
INSERT INTO `yzl_user_bonus` (`bonus_id`,`bonus_type_id`,`bonus_sn`,`user_id`,`used_time`,`order_id`,`emailed`) VALUES ('11','4','1000091405','0','0','0','0');
/*!40000 ALTER TABLE `yzl_user_bonus` ENABLE KEYS */;


--
-- Create Table `yzl_user_feed`
--

DROP TABLE IF EXISTS `yzl_user_feed`;
CREATE TABLE `yzl_user_feed` (
  `feed_id` mediumint(8) unsigned NOT NULL auto_increment,
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  `value_id` mediumint(8) unsigned NOT NULL default '0',
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `feed_type` tinyint(1) unsigned NOT NULL default '0',
  `is_feed` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`feed_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_user_feed`
--

/*!40000 ALTER TABLE `yzl_user_feed` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_user_feed` ENABLE KEYS */;


--
-- Create Table `yzl_user_rank`
--

DROP TABLE IF EXISTS `yzl_user_rank`;
CREATE TABLE `yzl_user_rank` (
  `rank_id` tinyint(3) unsigned NOT NULL auto_increment,
  `rank_name` varchar(30) NOT NULL default '',
  `min_points` int(10) unsigned NOT NULL default '0',
  `max_points` int(10) unsigned NOT NULL default '0',
  `discount` tinyint(3) unsigned NOT NULL default '0',
  `show_price` tinyint(1) unsigned NOT NULL default '1',
  `special_rank` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`rank_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_user_rank`
--

/*!40000 ALTER TABLE `yzl_user_rank` DISABLE KEYS */;
INSERT INTO `yzl_user_rank` (`rank_id`,`rank_name`,`min_points`,`max_points`,`discount`,`show_price`,`special_rank`) VALUES ('1','注册用户','0','10000','100','1','0');
INSERT INTO `yzl_user_rank` (`rank_id`,`rank_name`,`min_points`,`max_points`,`discount`,`show_price`,`special_rank`) VALUES ('2','vip','10000','10000000','95','1','0');
INSERT INTO `yzl_user_rank` (`rank_id`,`rank_name`,`min_points`,`max_points`,`discount`,`show_price`,`special_rank`) VALUES ('3','代销用户','0','0','90','0','1');
/*!40000 ALTER TABLE `yzl_user_rank` ENABLE KEYS */;


--
-- Create Table `yzl_users`
--

DROP TABLE IF EXISTS `yzl_users`;
CREATE TABLE `yzl_users` (
  `user_id` mediumint(8) unsigned NOT NULL auto_increment,
  `email` varchar(60) NOT NULL default '',
  `user_name` varchar(60) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `question` varchar(255) NOT NULL default '',
  `answer` varchar(255) NOT NULL default '',
  `sex` tinyint(1) unsigned NOT NULL default '0',
  `birthday` date NOT NULL default '0000-00-00',
  `user_money` decimal(10,2) NOT NULL default '0.00',
  `frozen_money` decimal(10,2) NOT NULL default '0.00',
  `pay_points` int(10) unsigned NOT NULL default '0',
  `rank_points` int(10) unsigned NOT NULL default '0',
  `address_id` mediumint(8) unsigned NOT NULL default '0',
  `reg_time` int(10) unsigned NOT NULL default '0',
  `last_login` int(11) unsigned NOT NULL default '0',
  `last_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_ip` varchar(15) NOT NULL default '',
  `visit_count` smallint(5) unsigned NOT NULL default '0',
  `user_rank` tinyint(3) unsigned NOT NULL default '0',
  `is_special` tinyint(3) unsigned NOT NULL default '0',
  `ec_salt` varchar(10) default NULL,
  `salt` varchar(10) NOT NULL default '0',
  `parent_id` mediumint(9) NOT NULL default '0',
  `flag` tinyint(3) unsigned NOT NULL default '0',
  `alias` varchar(60) NOT NULL,
  `msn` varchar(60) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `office_phone` varchar(20) NOT NULL,
  `home_phone` varchar(20) NOT NULL,
  `mobile_phone` varchar(20) NOT NULL,
  `is_validated` tinyint(3) unsigned NOT NULL default '0',
  `credit_line` decimal(10,2) unsigned NOT NULL,
  `passwd_question` varchar(50) default NULL,
  `passwd_answer` varchar(255) default NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  KEY `email` (`email`),
  KEY `parent_id` (`parent_id`),
  KEY `flag` (`flag`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_users`
--

/*!40000 ALTER TABLE `yzl_users` DISABLE KEYS */;
INSERT INTO `yzl_users` (`user_id`,`email`,`user_name`,`password`,`question`,`answer`,`sex`,`birthday`,`user_money`,`frozen_money`,`pay_points`,`rank_points`,`address_id`,`reg_time`,`last_login`,`last_time`,`last_ip`,`visit_count`,`user_rank`,`is_special`,`ec_salt`,`salt`,`parent_id`,`flag`,`alias`,`msn`,`qq`,`office_phone`,`home_phone`,`mobile_phone`,`is_validated`,`credit_line`,`passwd_question`,`passwd_answer`) VALUES ('11','1144042682@qq.com','1144042682','dd43a8756de335fa16622c6362dec639','','','0','0000-00-00','0.00','0.00','0','0','0','1381276221','1385377121','0000-00-00 00:00:00','127.0.0.1','313','0','0','8410','0','0','0','','','','','','','0','0.00',NULL,NULL);
INSERT INTO `yzl_users` (`user_id`,`email`,`user_name`,`password`,`question`,`answer`,`sex`,`birthday`,`user_money`,`frozen_money`,`pay_points`,`rank_points`,`address_id`,`reg_time`,`last_login`,`last_time`,`last_ip`,`visit_count`,`user_rank`,`is_special`,`ec_salt`,`salt`,`parent_id`,`flag`,`alias`,`msn`,`qq`,`office_phone`,`home_phone`,`mobile_phone`,`is_validated`,`credit_line`,`passwd_question`,`passwd_answer`) VALUES ('12','11440426821@qq.com','11440426821','dfa075352e225947cde1a59ce65a72b5','','','0','0000-00-00','0.00','0.00','0','0','0','1381361367','1381361367','0000-00-00 00:00:00','127.0.0.1','1','0','0',NULL,'0','0','0','','','','','','','0','0.00',NULL,NULL);
INSERT INTO `yzl_users` (`user_id`,`email`,`user_name`,`password`,`question`,`answer`,`sex`,`birthday`,`user_money`,`frozen_money`,`pay_points`,`rank_points`,`address_id`,`reg_time`,`last_login`,`last_time`,`last_ip`,`visit_count`,`user_rank`,`is_special`,`ec_salt`,`salt`,`parent_id`,`flag`,`alias`,`msn`,`qq`,`office_phone`,`home_phone`,`mobile_phone`,`is_validated`,`credit_line`,`passwd_question`,`passwd_answer`) VALUES ('13','test12@qq.com','test12','60474c9c10d7142b7508ce7a50acf414','','','0','0000-00-00','0.00','0.00','0','0','0','1384902097','1384902098','0000-00-00 00:00:00','127.0.0.1','1','0','0',NULL,'0','0','0','','','','','','','0','0.00',NULL,NULL);
INSERT INTO `yzl_users` (`user_id`,`email`,`user_name`,`password`,`question`,`answer`,`sex`,`birthday`,`user_money`,`frozen_money`,`pay_points`,`rank_points`,`address_id`,`reg_time`,`last_login`,`last_time`,`last_ip`,`visit_count`,`user_rank`,`is_special`,`ec_salt`,`salt`,`parent_id`,`flag`,`alias`,`msn`,`qq`,`office_phone`,`home_phone`,`mobile_phone`,`is_validated`,`credit_line`,`passwd_question`,`passwd_answer`) VALUES ('14','test123@12.cc','test123','cc03e747a6afbbcbf8be7668acfebee5','','','0','0000-00-00','0.00','0.00','0','0','0','1384909526','1384909526','0000-00-00 00:00:00','127.0.0.1','1','0','0',NULL,'0','0','0','','','','','','','0','0.00',NULL,NULL);
INSERT INTO `yzl_users` (`user_id`,`email`,`user_name`,`password`,`question`,`answer`,`sex`,`birthday`,`user_money`,`frozen_money`,`pay_points`,`rank_points`,`address_id`,`reg_time`,`last_login`,`last_time`,`last_ip`,`visit_count`,`user_rank`,`is_special`,`ec_salt`,`salt`,`parent_id`,`flag`,`alias`,`msn`,`qq`,`office_phone`,`home_phone`,`mobile_phone`,`is_validated`,`credit_line`,`passwd_question`,`passwd_answer`) VALUES ('15','testyy@qq.com','testyy','9f7ae7aba258566353d4fa47fc22f798','','','0','0000-00-00','0.00','0.00','0','0','0','1384910577','1384910577','0000-00-00 00:00:00','127.0.0.1','1','0','0',NULL,'0','0','0','','','','','','','0','0.00',NULL,NULL);
INSERT INTO `yzl_users` (`user_id`,`email`,`user_name`,`password`,`question`,`answer`,`sex`,`birthday`,`user_money`,`frozen_money`,`pay_points`,`rank_points`,`address_id`,`reg_time`,`last_login`,`last_time`,`last_ip`,`visit_count`,`user_rank`,`is_special`,`ec_salt`,`salt`,`parent_id`,`flag`,`alias`,`msn`,`qq`,`office_phone`,`home_phone`,`mobile_phone`,`is_validated`,`credit_line`,`passwd_question`,`passwd_answer`) VALUES ('16','fadfa@www.cc','asdfgasdf','88bece6af3ad7ac8228ebac0a65da244','','','0','0000-00-00','0.00','0.00','0','0','0','1384911976','1384911976','0000-00-00 00:00:00','127.0.0.1','1','0','0',NULL,'0','0','0','','','','','','','0','0.00',NULL,NULL);
INSERT INTO `yzl_users` (`user_id`,`email`,`user_name`,`password`,`question`,`answer`,`sex`,`birthday`,`user_money`,`frozen_money`,`pay_points`,`rank_points`,`address_id`,`reg_time`,`last_login`,`last_time`,`last_ip`,`visit_count`,`user_rank`,`is_special`,`ec_salt`,`salt`,`parent_id`,`flag`,`alias`,`msn`,`qq`,`office_phone`,`home_phone`,`mobile_phone`,`is_validated`,`credit_line`,`passwd_question`,`passwd_answer`) VALUES ('17','dfasdfasdf@11.vv','fefefeaf','d9bbf826f1d27fe1fc759d3e2ce69ac5','','','0','0000-00-00','0.00','0.00','0','0','0','1384912043','1384912043','0000-00-00 00:00:00','127.0.0.1','1','0','0',NULL,'0','0','0','','','','','','','0','0.00',NULL,NULL);
INSERT INTO `yzl_users` (`user_id`,`email`,`user_name`,`password`,`question`,`answer`,`sex`,`birthday`,`user_money`,`frozen_money`,`pay_points`,`rank_points`,`address_id`,`reg_time`,`last_login`,`last_time`,`last_ip`,`visit_count`,`user_rank`,`is_special`,`ec_salt`,`salt`,`parent_id`,`flag`,`alias`,`msn`,`qq`,`office_phone`,`home_phone`,`mobile_phone`,`is_validated`,`credit_line`,`passwd_question`,`passwd_answer`) VALUES ('18','testteeee@qq.vv','testteeee','585063a772529a5e7d8513adf52ec6fc','','','0','0000-00-00','0.00','0.00','0','0','0','1384912135','1384912135','0000-00-00 00:00:00','127.0.0.1','1','0','0',NULL,'0','0','0','','','','','','','0','0.00',NULL,NULL);
INSERT INTO `yzl_users` (`user_id`,`email`,`user_name`,`password`,`question`,`answer`,`sex`,`birthday`,`user_money`,`frozen_money`,`pay_points`,`rank_points`,`address_id`,`reg_time`,`last_login`,`last_time`,`last_ip`,`visit_count`,`user_rank`,`is_special`,`ec_salt`,`salt`,`parent_id`,`flag`,`alias`,`msn`,`qq`,`office_phone`,`home_phone`,`mobile_phone`,`is_validated`,`credit_line`,`passwd_question`,`passwd_answer`) VALUES ('19','tets12122@qq.bb','tets12122','35b066b8117b2e00465744763a2629c1','','','0','0000-00-00','0.00','0.00','0','0','0','1384913340','1384913340','0000-00-00 00:00:00','127.0.0.1','1','0','0',NULL,'0','0','0','','','','','','','0','0.00',NULL,NULL);
/*!40000 ALTER TABLE `yzl_users` ENABLE KEYS */;


--
-- Create Table `yzl_virtual_card`
--

DROP TABLE IF EXISTS `yzl_virtual_card`;
CREATE TABLE `yzl_virtual_card` (
  `card_id` mediumint(8) NOT NULL auto_increment,
  `goods_id` mediumint(8) unsigned NOT NULL default '0',
  `card_sn` varchar(60) NOT NULL default '',
  `card_password` varchar(60) NOT NULL default '',
  `add_date` int(11) NOT NULL default '0',
  `end_date` int(11) NOT NULL default '0',
  `is_saled` tinyint(1) NOT NULL default '0',
  `order_sn` varchar(20) NOT NULL default '',
  `crc32` varchar(12) NOT NULL default '0',
  PRIMARY KEY  (`card_id`),
  KEY `goods_id` (`goods_id`),
  KEY `car_sn` (`card_sn`),
  KEY `is_saled` (`is_saled`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_virtual_card`
--

/*!40000 ALTER TABLE `yzl_virtual_card` DISABLE KEYS */;
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('3','26','RVlYQhFYQg','RVlYQhFYQg','1241972801','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('4','26','RVlYQhFYQhFQEVo','RVlYQhFYQhFQEVo','1241972811','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('5','27','RlpbQRI','RlpbQRJbQQ','1241972903','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('6','27','RlpbQRJbQg','RVpbQBJaQRE','1241972911','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('7','30','RVtbQBJYQBJQE1lU','R1pYRxJaQhRTEVhXSEdaWA','1241973121','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('8','30','R1pYRxJYRxNTFV9S','TF5cQBVdQA','1241973127','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('9','30','Q15cSxZeRhhWFg','TV9fSxdfSxdXGFxTQUI','1241973134','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('10','30','QVxaRhRaRhRSF11d','TFBeRRheRRhWFlJdSU1Q','1241973146','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('11','30','R1xaRxNcRw','QF1dRRVdRBY','1241973157','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('12','30','RlpbQRNdQBJU','R1xaQRRaQRVSEg','1241973164','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('13','30','RltdQBRaQQ','Rl1dRRheRRhYF10','1241973170','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('14','30','RltdQBVeRhg','RlxaQRZeRhVV','1241973178','1273449600','0','','-1958172277');
INSERT INTO `yzl_virtual_card` (`card_id`,`goods_id`,`card_sn`,`card_password`,`add_date`,`end_date`,`is_saled`,`order_sn`,`crc32`) VALUES ('15','30','QFtbRhRaQRZVEw','Rl1aQRRaQRZUElg','1241973185','1273449600','0','','-1958172277');
/*!40000 ALTER TABLE `yzl_virtual_card` ENABLE KEYS */;


--
-- Create Table `yzl_volume_price`
--

DROP TABLE IF EXISTS `yzl_volume_price`;
CREATE TABLE `yzl_volume_price` (
  `price_type` tinyint(1) unsigned NOT NULL,
  `goods_id` mediumint(8) unsigned NOT NULL,
  `volume_number` smallint(5) unsigned NOT NULL default '0',
  `volume_price` decimal(10,2) NOT NULL default '0.00',
  PRIMARY KEY  (`price_type`,`goods_id`,`volume_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_volume_price`
--

/*!40000 ALTER TABLE `yzl_volume_price` DISABLE KEYS */;
INSERT INTO `yzl_volume_price` (`price_type`,`goods_id`,`volume_number`,`volume_price`) VALUES ('1','1','5','1366.00');
INSERT INTO `yzl_volume_price` (`price_type`,`goods_id`,`volume_number`,`volume_price`) VALUES ('1','9','3','2200.00');
INSERT INTO `yzl_volume_price` (`price_type`,`goods_id`,`volume_number`,`volume_price`) VALUES ('1','9','5','2100.00');
INSERT INTO `yzl_volume_price` (`price_type`,`goods_id`,`volume_number`,`volume_price`) VALUES ('1','13','3','1200.00');
INSERT INTO `yzl_volume_price` (`price_type`,`goods_id`,`volume_number`,`volume_price`) VALUES ('1','13','5','1150.00');
/*!40000 ALTER TABLE `yzl_volume_price` ENABLE KEYS */;


--
-- Create Table `yzl_vote`
--

DROP TABLE IF EXISTS `yzl_vote`;
CREATE TABLE `yzl_vote` (
  `vote_id` smallint(5) unsigned NOT NULL auto_increment,
  `vote_name` varchar(250) NOT NULL default '',
  `start_time` int(11) unsigned NOT NULL default '0',
  `end_time` int(11) unsigned NOT NULL default '0',
  `can_multi` tinyint(1) unsigned NOT NULL default '0',
  `vote_count` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`vote_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_vote`
--

/*!40000 ALTER TABLE `yzl_vote` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_vote` ENABLE KEYS */;


--
-- Create Table `yzl_vote_log`
--

DROP TABLE IF EXISTS `yzl_vote_log`;
CREATE TABLE `yzl_vote_log` (
  `log_id` mediumint(8) unsigned NOT NULL auto_increment,
  `vote_id` smallint(5) unsigned NOT NULL default '0',
  `ip_address` varchar(15) NOT NULL default '',
  `vote_time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`log_id`),
  KEY `vote_id` (`vote_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_vote_log`
--

/*!40000 ALTER TABLE `yzl_vote_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_vote_log` ENABLE KEYS */;


--
-- Create Table `yzl_vote_option`
--

DROP TABLE IF EXISTS `yzl_vote_option`;
CREATE TABLE `yzl_vote_option` (
  `option_id` smallint(5) unsigned NOT NULL auto_increment,
  `vote_id` smallint(5) unsigned NOT NULL default '0',
  `option_name` varchar(250) NOT NULL default '',
  `option_count` int(8) unsigned NOT NULL default '0',
  `option_order` tinyint(3) unsigned NOT NULL default '100',
  PRIMARY KEY  (`option_id`),
  KEY `vote_id` (`vote_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_vote_option`
--

/*!40000 ALTER TABLE `yzl_vote_option` DISABLE KEYS */;
INSERT INTO `yzl_vote_option` (`option_id`,`vote_id`,`option_name`,`option_count`,`option_order`) VALUES ('1','1','论坛','0','100');
INSERT INTO `yzl_vote_option` (`option_id`,`vote_id`,`option_name`,`option_count`,`option_order`) VALUES ('2','1','朋友','0','100');
INSERT INTO `yzl_vote_option` (`option_id`,`vote_id`,`option_name`,`option_count`,`option_order`) VALUES ('3','1','友情链接','0','100');
/*!40000 ALTER TABLE `yzl_vote_option` ENABLE KEYS */;


--
-- Create Table `yzl_wholesale`
--

DROP TABLE IF EXISTS `yzl_wholesale`;
CREATE TABLE `yzl_wholesale` (
  `act_id` mediumint(8) unsigned NOT NULL auto_increment,
  `goods_id` mediumint(8) unsigned NOT NULL,
  `goods_name` varchar(255) NOT NULL,
  `rank_ids` varchar(255) NOT NULL,
  `prices` text NOT NULL,
  `enabled` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  (`act_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `yzl_wholesale`
--

/*!40000 ALTER TABLE `yzl_wholesale` DISABLE KEYS */;
/*!40000 ALTER TABLE `yzl_wholesale` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

